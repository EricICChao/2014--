﻿namespace Central_management
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.分店帳戶管理 = new System.Windows.Forms.ToolStripButton();
            this.分店資訊 = new System.Windows.Forms.ToolStripButton();
            this.活動資訊 = new System.Windows.Forms.ToolStripButton();
            this.商品資訊 = new System.Windows.Forms.ToolStripButton();
            this.圖片管理 = new System.Windows.Forms.ToolStripButton();
            this.擷取報表資訊 = new System.Windows.Forms.ToolStripButton();
            this.關閉編輯器 = new System.Windows.Forms.ToolStripButton();
            this.客戶端編輯器 = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.分店帳戶管理,
            this.分店資訊,
            this.活動資訊,
            this.商品資訊,
            this.圖片管理,
            this.擷取報表資訊,
            this.客戶端編輯器,
            this.關閉編輯器});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(818, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // 分店帳戶管理
            // 
            this.分店帳戶管理.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.分店帳戶管理.Image = ((System.Drawing.Image)(resources.GetObject("分店帳戶管理.Image")));
            this.分店帳戶管理.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.分店帳戶管理.Name = "分店帳戶管理";
            this.分店帳戶管理.Size = new System.Drawing.Size(84, 22);
            this.分店帳戶管理.Text = "分店帳戶管理";
            this.分店帳戶管理.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // 分店資訊
            // 
            this.分店資訊.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.分店資訊.Image = ((System.Drawing.Image)(resources.GetObject("分店資訊.Image")));
            this.分店資訊.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.分店資訊.Name = "分店資訊";
            this.分店資訊.Size = new System.Drawing.Size(60, 22);
            this.分店資訊.Text = "分店資訊";
            this.分店資訊.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // 活動資訊
            // 
            this.活動資訊.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.活動資訊.Image = ((System.Drawing.Image)(resources.GetObject("活動資訊.Image")));
            this.活動資訊.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.活動資訊.Name = "活動資訊";
            this.活動資訊.Size = new System.Drawing.Size(60, 22);
            this.活動資訊.Text = "活動資訊";
            this.活動資訊.Click += new System.EventHandler(this.活動資訊_Click);
            // 
            // 商品資訊
            // 
            this.商品資訊.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.商品資訊.Image = ((System.Drawing.Image)(resources.GetObject("商品資訊.Image")));
            this.商品資訊.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.商品資訊.Name = "商品資訊";
            this.商品資訊.Size = new System.Drawing.Size(60, 22);
            this.商品資訊.Text = "商品資訊";
            this.商品資訊.Click += new System.EventHandler(this.商品資訊_Click);
            // 
            // 圖片管理
            // 
            this.圖片管理.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.圖片管理.Image = ((System.Drawing.Image)(resources.GetObject("圖片管理.Image")));
            this.圖片管理.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.圖片管理.Name = "圖片管理";
            this.圖片管理.Size = new System.Drawing.Size(60, 22);
            this.圖片管理.Text = "圖片管理";
            this.圖片管理.Click += new System.EventHandler(this.圖片管理_Click);
            // 
            // 擷取報表資訊
            // 
            this.擷取報表資訊.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.擷取報表資訊.Image = ((System.Drawing.Image)(resources.GetObject("擷取報表資訊.Image")));
            this.擷取報表資訊.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.擷取報表資訊.Name = "擷取報表資訊";
            this.擷取報表資訊.Size = new System.Drawing.Size(84, 22);
            this.擷取報表資訊.Text = "擷取報表資訊";
            this.擷取報表資訊.Click += new System.EventHandler(this.擷取報表資訊_Click);
            // 
            // 關閉編輯器
            // 
            this.關閉編輯器.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.關閉編輯器.Image = ((System.Drawing.Image)(resources.GetObject("關閉編輯器.Image")));
            this.關閉編輯器.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.關閉編輯器.Name = "關閉編輯器";
            this.關閉編輯器.Size = new System.Drawing.Size(72, 22);
            this.關閉編輯器.Text = "關閉編輯器";
            this.關閉編輯器.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // 客戶端編輯器
            // 
            this.客戶端編輯器.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.客戶端編輯器.Image = ((System.Drawing.Image)(resources.GetObject("客戶端編輯器.Image")));
            this.客戶端編輯器.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.客戶端編輯器.Name = "客戶端編輯器";
            this.客戶端編輯器.Size = new System.Drawing.Size(84, 22);
            this.客戶端編輯器.Text = "客戶端編輯器";
            this.客戶端編輯器.Click += new System.EventHandler(this.客戶端編輯器_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 457);
            this.Controls.Add(this.toolStrip1);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.Text = "中央管理器_主畫面";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton 分店帳戶管理;
        private System.Windows.Forms.ToolStripButton 分店資訊;
        private System.Windows.Forms.ToolStripButton 活動資訊;
        private System.Windows.Forms.ToolStripButton 商品資訊;
        private System.Windows.Forms.ToolStripButton 圖片管理;
        private System.Windows.Forms.ToolStripButton 擷取報表資訊;
        private System.Windows.Forms.ToolStripButton 關閉編輯器;
        private System.Windows.Forms.ToolStripButton 客戶端編輯器;


    }
}

