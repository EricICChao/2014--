﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Central_management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            /*本程式為多表單應用程式，也就是可以開啟多個畫面的應用程式。
             * 指定Form表單為父表單。
             * 已在屬性表單那裡做設定，所以不用這邊寫程式進行設定。(屬性名稱: IsMdiContainer)
             */
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            分店資訊 f2 = new 分店資訊();
            f2.MdiParent = this;
            f2.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            分店帳戶管理 f1 = new 分店帳戶管理();
            f1.MdiParent = this;
            f1.Show();
        }

        private void toolStripButton7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void 活動資訊_Click(object sender, EventArgs e)
        {
            活動資訊 f3 = new 活動資訊();
            f3.MdiParent = this;
            f3.Show();
        }

        private void 商品資訊_Click(object sender, EventArgs e)
        {
            商品資訊 f4 = new 商品資訊();
            f4.MdiParent = this;
            f4.Show();
        }

        private void 圖片管理_Click(object sender, EventArgs e)
        {
            圖片管理 f5 = new 圖片管理();
            f5.MdiParent = this;
            f5.Show();
        }

        private void 擷取報表資訊_Click(object sender, EventArgs e)
        {
            擷取報表資訊 f6 = new 擷取報表資訊();
            f6.MdiParent = this;
            f6.Show();
        }

        private void 客戶端編輯器_Click(object sender, EventArgs e)
        {
            客戶端編輯器 f7 = new 客戶端編輯器();
            f7.MdiParent = this;
            f7.Show();
        }

        



    }
}
