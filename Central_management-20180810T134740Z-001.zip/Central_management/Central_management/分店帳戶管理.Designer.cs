﻿namespace Central_management
{
    partial class 分店帳戶管理
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.exit = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.資料編號DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.分店名稱DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.分店帳號DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.密碼DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.負責人DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.電話DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.身分證字號DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.各分店權限BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.飲料店DataSet = new Central_management.飲料店DataSet();
            this.各分店權限TableAdapter = new Central_management.飲料店DataSetTableAdapters.各分店權限TableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.add_new_data = new System.Windows.Forms.Button();
            this.previou_one = new System.Windows.Forms.Button();
            this.next_one = new System.Windows.Forms.Button();
            this.remove_one = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.各分店權限BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.飲料店DataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(611, 358);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(148, 52);
            this.exit.TabIndex = 0;
            this.exit.Text = "離開 \"分店帳戶管理\"";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // update
            // 
            this.update.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.update.Location = new System.Drawing.Point(455, 357);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(79, 52);
            this.update.TabIndex = 2;
            this.update.Text = "更新";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.資料編號DataGridViewTextBoxColumn,
            this.分店名稱DataGridViewTextBoxColumn,
            this.分店帳號DataGridViewTextBoxColumn,
            this.密碼DataGridViewTextBoxColumn,
            this.負責人DataGridViewTextBoxColumn,
            this.電話DataGridViewTextBoxColumn,
            this.身分證字號DataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.各分店權限BindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(744, 150);
            this.dataGridView1.TabIndex = 3;
            // 
            // 資料編號DataGridViewTextBoxColumn
            // 
            this.資料編號DataGridViewTextBoxColumn.DataPropertyName = "資料編號";
            this.資料編號DataGridViewTextBoxColumn.HeaderText = "資料編號";
            this.資料編號DataGridViewTextBoxColumn.Name = "資料編號DataGridViewTextBoxColumn";
            // 
            // 分店名稱DataGridViewTextBoxColumn
            // 
            this.分店名稱DataGridViewTextBoxColumn.DataPropertyName = "分店名稱";
            this.分店名稱DataGridViewTextBoxColumn.HeaderText = "分店名稱";
            this.分店名稱DataGridViewTextBoxColumn.Name = "分店名稱DataGridViewTextBoxColumn";
            // 
            // 分店帳號DataGridViewTextBoxColumn
            // 
            this.分店帳號DataGridViewTextBoxColumn.DataPropertyName = "分店帳號";
            this.分店帳號DataGridViewTextBoxColumn.HeaderText = "分店帳號";
            this.分店帳號DataGridViewTextBoxColumn.Name = "分店帳號DataGridViewTextBoxColumn";
            // 
            // 密碼DataGridViewTextBoxColumn
            // 
            this.密碼DataGridViewTextBoxColumn.DataPropertyName = "密碼";
            this.密碼DataGridViewTextBoxColumn.HeaderText = "密碼";
            this.密碼DataGridViewTextBoxColumn.Name = "密碼DataGridViewTextBoxColumn";
            // 
            // 負責人DataGridViewTextBoxColumn
            // 
            this.負責人DataGridViewTextBoxColumn.DataPropertyName = "負責人";
            this.負責人DataGridViewTextBoxColumn.HeaderText = "負責人";
            this.負責人DataGridViewTextBoxColumn.Name = "負責人DataGridViewTextBoxColumn";
            // 
            // 電話DataGridViewTextBoxColumn
            // 
            this.電話DataGridViewTextBoxColumn.DataPropertyName = "電話";
            this.電話DataGridViewTextBoxColumn.HeaderText = "電話";
            this.電話DataGridViewTextBoxColumn.Name = "電話DataGridViewTextBoxColumn";
            // 
            // 身分證字號DataGridViewTextBoxColumn
            // 
            this.身分證字號DataGridViewTextBoxColumn.DataPropertyName = "身分證字號";
            this.身分證字號DataGridViewTextBoxColumn.HeaderText = "身分證字號";
            this.身分證字號DataGridViewTextBoxColumn.Name = "身分證字號DataGridViewTextBoxColumn";
            // 
            // 各分店權限BindingSource
            // 
            this.各分店權限BindingSource.DataMember = "各分店權限";
            this.各分店權限BindingSource.DataSource = this.bindingSource1;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this.飲料店DataSet;
            this.bindingSource1.Position = 0;
            // 
            // 飲料店DataSet
            // 
            this.飲料店DataSet.DataSetName = "飲料店DataSet";
            this.飲料店DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // 各分店權限TableAdapter
            // 
            this.各分店權限TableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(12, 233);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "分店名稱:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(383, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "身分證字號:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(383, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "電話:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(383, 188);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "負責人:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(12, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "密碼:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(12, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "分店帳號:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(12, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "資料編號:";
            // 
            // add_new_data
            // 
            this.add_new_data.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.add_new_data.Location = new System.Drawing.Point(15, 358);
            this.add_new_data.Name = "add_new_data";
            this.add_new_data.Size = new System.Drawing.Size(83, 52);
            this.add_new_data.TabIndex = 11;
            this.add_new_data.Text = "新增";
            this.add_new_data.UseVisualStyleBackColor = true;
            this.add_new_data.Click += new System.EventHandler(this.add_new_data_Click);
            // 
            // previou_one
            // 
            this.previou_one.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.previou_one.Location = new System.Drawing.Point(233, 358);
            this.previou_one.Name = "previou_one";
            this.previou_one.Size = new System.Drawing.Size(83, 52);
            this.previou_one.TabIndex = 12;
            this.previou_one.Text = "上一筆";
            this.previou_one.UseVisualStyleBackColor = true;
            this.previou_one.Click += new System.EventHandler(this.previou_one_Click);
            // 
            // next_one
            // 
            this.next_one.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.next_one.Location = new System.Drawing.Point(346, 358);
            this.next_one.Name = "next_one";
            this.next_one.Size = new System.Drawing.Size(83, 52);
            this.next_one.TabIndex = 13;
            this.next_one.Text = "下一筆";
            this.next_one.UseVisualStyleBackColor = true;
            this.next_one.Click += new System.EventHandler(this.next_one_Click);
            // 
            // remove_one
            // 
            this.remove_one.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.remove_one.Location = new System.Drawing.Point(123, 357);
            this.remove_one.Name = "remove_one";
            this.remove_one.Size = new System.Drawing.Size(79, 52);
            this.remove_one.TabIndex = 14;
            this.remove_one.Text = "刪除";
            this.remove_one.UseVisualStyleBackColor = true;
            this.remove_one.Click += new System.EventHandler(this.remove_one_Click);
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "資料編號", true));
            this.textBox1.Location = new System.Drawing.Point(94, 182);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(152, 22);
            this.textBox1.TabIndex = 15;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "分店名稱", true));
            this.textBox2.Location = new System.Drawing.Point(94, 227);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(152, 22);
            this.textBox2.TabIndex = 16;
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "分店帳號", true));
            this.textBox3.Location = new System.Drawing.Point(94, 269);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(274, 22);
            this.textBox3.TabIndex = 17;
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "密碼", true));
            this.textBox4.Location = new System.Drawing.Point(94, 311);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(274, 22);
            this.textBox4.TabIndex = 18;
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "負責人", true));
            this.textBox5.Location = new System.Drawing.Point(449, 182);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(152, 22);
            this.textBox5.TabIndex = 19;
            // 
            // textBox6
            // 
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "電話", true));
            this.textBox6.Location = new System.Drawing.Point(449, 233);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(152, 22);
            this.textBox6.TabIndex = 20;
            // 
            // textBox7
            // 
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "身分證字號", true));
            this.textBox7.Location = new System.Drawing.Point(481, 269);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(274, 22);
            this.textBox7.TabIndex = 21;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(383, 311);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(108, 16);
            this.label8.TabIndex = 22;
            this.label8.Text = "目前資料筆數:";
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.各分店權限BindingSource, "資料編號", true));
            this.textBox8.Location = new System.Drawing.Point(497, 311);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(152, 22);
            this.textBox8.TabIndex = 23;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // 分店帳戶管理
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 434);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.remove_one);
            this.Controls.Add(this.next_one);
            this.Controls.Add(this.previou_one);
            this.Controls.Add(this.add_new_data);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.update);
            this.Controls.Add(this.exit);
            this.Name = "分店帳戶管理";
            this.Text = "分店帳戶管理";
            this.Load += new System.EventHandler(this.分店帳戶管理_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.各分店權限BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.飲料店DataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.BindingSource bindingSource1;
        private 飲料店DataSet 飲料店DataSet;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource 各分店權限BindingSource;
        private 飲料店DataSetTableAdapters.各分店權限TableAdapter 各分店權限TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn 資料編號DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 分店名稱DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 分店帳號DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 密碼DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 負責人DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 電話DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 身分證字號DataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button add_new_data;
        private System.Windows.Forms.Button previou_one;
        private System.Windows.Forms.Button next_one;
        private System.Windows.Forms.Button remove_one;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox8;

    }
}