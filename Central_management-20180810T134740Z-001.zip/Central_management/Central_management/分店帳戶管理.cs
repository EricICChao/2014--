﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Central_management
{
    public partial class 分店帳戶管理 : Form
    {
        public 分店帳戶管理()
        {
            InitializeComponent();
        }

        /*目前設計構想如下:
         * 每新增一筆要編輯的資料，datagridview資料編號的地方就會自動顯示新增的那一筆的編號
         * 每新增一筆要自動加上和整理全部的編號
         * 每刪除一筆要自動減回和整理全部的編號
         * 每選到那一筆資料，其它欄位的資料也要秀在textbox上
         * 
         */
                
        private void 分店帳戶管理_Load(object sender, EventArgs e)
        {
          
            // TODO: 這行程式碼會將資料載入 '飲料店DataSet.各分店權限' 資料表。您可以視需要進行移動或移除。
            this.各分店權限TableAdapter.Fill(this.飲料店DataSet.各分店權限);
            
            
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void update_Click(object sender, EventArgs e)
        {
            try
            {
                各分店權限BindingSource.EndEdit();
                各分店權限TableAdapter.Update(飲料店DataSet.各分店權限);
                MessageBox.Show("更新完成");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }

        private void previou_one_Click(object sender, EventArgs e)
        {
            //直到第一筆資料
            各分店權限BindingSource.MovePrevious();
        }

        private void next_one_Click(object sender, EventArgs e)
        {
            //直到最後一筆
            各分店權限BindingSource.MoveNext();
        }

        private void remove_one_Click(object sender, EventArgs e)
        {
            //刪除當前選到的資料項的position的位置
            各分店權限BindingSource.RemoveCurrent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e){}

        private void add_new_data_Click(object sender, EventArgs e)
        {
            //新增一筆空資料
            try
            {
                各分店權限BindingSource.AddNew();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            textBox8.Text = (各分店權限BindingSource.Position + 1).ToString() + "/" + 各分店權限BindingSource.Count.ToString();
        }
    }
}
