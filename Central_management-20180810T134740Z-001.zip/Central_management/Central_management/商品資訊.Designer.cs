﻿namespace Central_management
{
    partial class 商品資訊
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.add_item = new System.Windows.Forms.Label();
            this.price_big = new System.Windows.Forms.Label();
            this.price_small = new System.Windows.Forms.Label();
            this.price_medium = new System.Windows.Forms.Label();
            this.products_information = new System.Windows.Forms.Label();
            this.select_picture = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // add_item
            // 
            this.add_item.AutoSize = true;
            this.add_item.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.add_item.Location = new System.Drawing.Point(12, 9);
            this.add_item.Name = "add_item";
            this.add_item.Size = new System.Drawing.Size(166, 16);
            this.add_item.TabIndex = 0;
            this.add_item.Text = "輸入要新增品項名稱:";
            this.add_item.Click += new System.EventHandler(this.add_item_Click);
            // 
            // price_big
            // 
            this.price_big.AutoSize = true;
            this.price_big.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.price_big.Location = new System.Drawing.Point(12, 95);
            this.price_big.Name = "price_big";
            this.price_big.Size = new System.Drawing.Size(76, 16);
            this.price_big.TabIndex = 1;
            this.price_big.Text = "價格(大):";
            // 
            // price_small
            // 
            this.price_small.AutoSize = true;
            this.price_small.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.price_small.Location = new System.Drawing.Point(12, 198);
            this.price_small.Name = "price_small";
            this.price_small.Size = new System.Drawing.Size(76, 16);
            this.price_small.TabIndex = 2;
            this.price_small.Text = "價格(小):";
            // 
            // price_medium
            // 
            this.price_medium.AutoSize = true;
            this.price_medium.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.price_medium.Location = new System.Drawing.Point(12, 148);
            this.price_medium.Name = "price_medium";
            this.price_medium.Size = new System.Drawing.Size(76, 16);
            this.price_medium.TabIndex = 3;
            this.price_medium.Text = "價格(中):";
            this.price_medium.Click += new System.EventHandler(this.label2_Click);
            // 
            // products_information
            // 
            this.products_information.AutoSize = true;
            this.products_information.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.products_information.Location = new System.Drawing.Point(2, 351);
            this.products_information.Name = "products_information";
            this.products_information.Size = new System.Drawing.Size(115, 16);
            this.products_information.TabIndex = 4;
            this.products_information.Text = "商品內容描述:";
            // 
            // select_picture
            // 
            this.select_picture.AutoSize = true;
            this.select_picture.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.select_picture.Location = new System.Drawing.Point(12, 50);
            this.select_picture.Name = "select_picture";
            this.select_picture.Size = new System.Drawing.Size(115, 16);
            this.select_picture.TabIndex = 5;
            this.select_picture.Text = "選擇商品圖片:";
            this.select_picture.Click += new System.EventHandler(this.select_picture_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("新細明體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox1.Location = new System.Drawing.Point(260, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(210, 21);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("新細明體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox2.Location = new System.Drawing.Point(123, 352);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(210, 22);
            this.textBox2.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("新細明體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox3.Location = new System.Drawing.Point(260, 95);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(210, 21);
            this.textBox3.TabIndex = 8;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("新細明體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox4.Location = new System.Drawing.Point(260, 151);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(210, 21);
            this.textBox4.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("新細明體", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textBox5.Location = new System.Drawing.Point(260, 201);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(210, 21);
            this.textBox5.TabIndex = 10;
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(676, 455);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(157, 53);
            this.exit.TabIndex = 11;
            this.exit.Text = "離開 \"商品資訊\"";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // 商品資訊
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 536);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.select_picture);
            this.Controls.Add(this.products_information);
            this.Controls.Add(this.price_medium);
            this.Controls.Add(this.price_small);
            this.Controls.Add(this.price_big);
            this.Controls.Add(this.add_item);
            this.Name = "商品資訊";
            this.Text = "商品資訊編輯";
            this.Load += new System.EventHandler(this.商品資訊_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label add_item;
        private System.Windows.Forms.Label price_big;
        private System.Windows.Forms.Label price_small;
        private System.Windows.Forms.Label price_medium;
        private System.Windows.Forms.Label products_information;
        private System.Windows.Forms.Label select_picture;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button exit;
    }
}