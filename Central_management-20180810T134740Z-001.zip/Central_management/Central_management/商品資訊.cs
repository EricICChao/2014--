﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Central_management
{
    public partial class 商品資訊 : Form
    {
        public 商品資訊()
        {
            InitializeComponent();
        }

        private void add_item_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void select_picture_Click(object sender, EventArgs e)
        {

        }

        private void 商品資訊_Load(object sender, EventArgs e)
        {

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
