__author__ = 'Eric'


指定哪一個資料庫要被Delete
指定哪一個pickle要被Delete