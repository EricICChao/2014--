__author__ = 'Eric'


"""
引入旗標概念進行功能選項的操作

資料分析
創建新的資料庫
引入外部資料 : csv, txt, others


"""