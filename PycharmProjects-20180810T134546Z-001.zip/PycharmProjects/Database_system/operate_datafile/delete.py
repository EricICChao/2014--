__author__ = 'Eric'



指定第幾個資料要被Delete
指定範圍內的資料要被Delete
指定哪些資料要被Delete
指定哪個資料檔案要被刪除
