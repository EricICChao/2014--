__author__ = 'Eric'
#資料連續輸入，並匯出到新的檔案中
import re,sys,io

def text_data_input_in_new_file():
    data_set = []
    i = 1
    a = input("請設定要輸入的資料項有幾項: ")
    while i < int(a):
        text_data = input("請輸入資料: ")
        data_set.append(text_data)
        next_step = input("接下來要繼續的動作為: (1)輸入下一筆資料 ；(2)繼續修改原本資料； (3)結束應用程式")
        if next_step is '1':
            i += 1
            b = str(i)
            text_data_next = input("請輸入第"+ b + "筆資料: ")
            data_set.append(text_data_next)
        elif next_step is '2':
            continue
        elif next_step is '3':
            sys.exit()
    new_file_name = input("請輸入檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'xt', encoding= "utf8", newline = '') as f:
        for x in data_set:
        #將資料從set中一筆一筆寫入檔案裡
            with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'at', encoding= "utf8", newline = '') as f:
                f.write(x)
#=======================================================================================================================
#符合條件之檔案一次讀取功能

def reading_search_data():
    key_word = input("請輸入要查詢的關鍵字:")
    #指定查詢資特定料夾內目錄list
    folder_path = input("指定要搜尋的資料夾位址，目錄的路徑表示方法:  C://Users//Eric//Desktop//information literacy相關//，請輸入:")
    file_names_list = os.listdir(folder_path)
    new_file_name = input("請輸入要儲存搜尋到的資料檔案的檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space///"+new_file_name, 'xt', encoding= "utf8") as f:
        for x in file_names_list:
            #with open("C://Users//Eric//PycharmProjects//test_text//"+x, encoding= "utf8") as f2:
            with open(folder_path + x,'rt', encoding="utf8") as f2:
                text_data = f2.read()
                #比對英文
                search_english_key_word = re.search(r"\b + key_word + \b", text_data)
                #比對中文.
                search_chinese_key_word = re.search(r"(?u)\b + key_word + \b", text_data)
                if search_english_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)
                elif search_chinese_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)