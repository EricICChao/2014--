__author__ = 'Eric'

import os
#連接可以下載到單機上的google雲端硬碟或是MS的Onedrive的資料夾路徑
#指定檔案路徑的方法:
#C://Users//Eric//PycharmProjects//data searching//save_space//
#請記得用 "// " 而不是 " \ "
def google_drive_list():
    file_list = os.listdir("C://Users//Eric//Google 雲端硬碟")
    for x in file_list:
        print(x)
#檔案陸境設定請轉為字串
def cloud_storage_list(path,cloud_folder):
    file_list = os.listdir(path + "//" + cloud_folder)
    for x in file_list:
        print(x)
#開啟檔案時請記得連檔案格式都輸入，例如: eric.txt
def open_file(path,file_list):
    data_list = []
    for x in file_list:
        with open(path+"//"+x,'rt', encoding= 'utf8') as f:
            data = f.read()
            data_list.append(data)
    return data_list
#將資料新增至現有檔案
def write_file(path,file_name):
    data = open(path +"//"+file_name, 'at', encoding= 'utf8')
    text_data = input("請輸入資料: ")
    data.write(text_data)
    data.close()
#將資料新增至新檔案
def write_new_file(path,file_name):
    data = open(path +"//"+file_name, 'xt', encoding= 'utf8')
    text_data = input("請輸入資料: ")
    data.write(text_data)
    data.close()