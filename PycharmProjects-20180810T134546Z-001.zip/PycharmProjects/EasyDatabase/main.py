__author__ = 'Eric'


import sys,cloud_storage

"""
可用功能:
文字資料探勘、資料探勘
知識分享、雲端化

資料庫能耐:
儲存空間取決於硬體規格
多檔案格式
"""

#操作區
#1---檢視要操作的檔案
    #要先輸入指定的資料夾路徑，列出所有的檔案
    #或者是開啟某一份文檔，列出所有檔案相關資料和連結路徑

a = cloud_storage.google_drive_list()

#開啟檔案時請記得連檔案格式都輸入，例如: eric.txt
file_list=["一些探討科技工具在教學應用的文獻.txt"]
b = cloud_storage.open_file("C://Users//Eric//Google 雲端硬碟",file_list)


path = "C://Users//Eric//PycharmProjects//EasyDatabase//txt_data_storage"
file_name ="1.txt"
file_name2 ="2.txt"
#將資料新增至現有檔案
c = cloud_storage.write_file(path,file_name)

#將資料新增至新檔案
d =cloud_storage.write_new_file(path,file_name2)








#2---進行資料操作





