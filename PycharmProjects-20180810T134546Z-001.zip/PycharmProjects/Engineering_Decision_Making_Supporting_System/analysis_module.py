__author__ = 'Eric'

import math, data_facilities, heapq

#===================現金流===================
#單利
def Simple_interest():
    capital = input("請輸入本金總額: ")
    interest = input("請輸入利息: ")
    period_n = input("請輸入期數: ")
    c = float(capital)
    i = float(interest)
    p = float(period_n)
    total_I = c*i*p
    total = c*(1+i*p)
    a = str(total_I)
    b = str(total)
    print("單利利息下需支付的利息總額: " + a)
    print("單利利息下需支付的本金+利息總額: " + b)

#複利
def Compounding():
    capital = input("請輸入本金總額: ")
    interest = input("請輸入利息: ")
    period_n = input("請輸入期數: ")
    c = float(capital)
    i = float(interest)
    p = float(period_n)
    px = 0
    while px<p:
        total = c*pow((1+i),px)
        total_I = total - c
        a = str(total_I)
        b = str(total)
        pxstr = str(px)
        print("第" + pxstr + "期:")
        print("複利利息下需支付的利息總額: " + a)
        print("複利利息下需支付的本金+利息總額: " + b)
        px = px+1
#複利---計算單一期
def Compounding_single_period():
    capital = input("請輸入本金總額: ")
    interest = input("請輸入利息: ")
    period_n = input("請輸入期數: ")
    c = float(capital)
    i = float(interest)
    p = float(period_n)
    total = c*pow((1+i),p)
    total_I = total - c
    a = str(total_I)
    b = str(total)
    print("第" + period_n + "期:")
    print("複利利息下需支付的利息總額: " + a)
    print("複利利息下需支付的本金+利息總額: " + b)

#名目利率轉實際利率
def NIR_to_RIR():
    period_n = input("請輸入複利週期: ")
    nir = input("請輸入名目利率: ")
    n = float(nir)
    p = float(period_n)
    ans = n/p
    a = str(ans)
    print("每一期的實際利率為: " + a)

#實際利率轉名目利率
def RIR_to_NIR():
    period_n = input("請輸入複利週期: ")
    rir = input("請輸入實際利率: ")
    r = float(rir)
    p = float(period_n)
    ans = r*p
    a = str(ans)
    print("名目利率為: " + a)

#實際利率換算---貸款成本或是投資收益的計算
def RIR():
    period_n = input("請輸入複利週期: ")
    nir = ("請輸入名目利率: ")
    p = float(period_n)
    n = float(nir)
    m = n/p
    rir = pow((1+m),p) -1
    return rir

#連續性複利計算
def Compounding_Continue():
    a = input("請輸入名目週期的比例:")
    b = input("請輸入名目利率:")
    a_float = float(a)
    b_float = float(b)
    i = pow(math.e,a_float*b_float) -1
    i_str = str(i)
    print("連續性複利的情況下之複利為:"+ i_str)


#通貨膨脹
def inflation(data_file_path, var_name_PI, var_name_years):
    years_set = data_facilities.data_import(data_file_path, var_name_years)
    PI_set = data_facilities.data_import(data_file_path, var_name_PI)
    #object_1 = input("請輸入要衡量的目標名稱:")
    years_set_length = len(years_set) -1
    PI_set_length = len(PI_set) -1
    purchasing_cost_grow = float(PI_set[PI_set_length]) / float(PI_set[0])
    purchasing_power = float(PI_set[0]) / float(PI_set[PI_set_length])
    strpcg = str(purchasing_cost_grow)
    strpp = str(purchasing_power)
    print("在" + years_set[years_set_length] + "年要花上" + strpcg + "倍的成本才能得到和" + years_set[0] + "同樣多的品項或服務")
    print(years_set[years_set_length] + "的購買力是" + years_set[0] + "的" + strpp + "倍")
    inflation_period = int(years_set[years_set_length]) - int(years_set[0])
    f = pow(purchasing_cost_grow,1 / inflation_period) - 1
    strf = str(f)
    if f >= 0:
        print("從" + years_set[0] + "年~" + years_set[years_set_length] +"年，這段期間的平均通貨膨脹率為" + strf)
    elif f < 0:
        print("從" + years_set[0] + "年~" + years_set[years_set_length] +"年，這段期間的平均通貨緊縮率為" + strf)

#實質貨幣計算---current_dollars是 "現在" 的流通貨幣; f 是通貨膨脹率 ; period是設定期間長度
def real_dollars(current_dollars, f, period):
    result = current_dollars / pow(1+f,period)
    return result

#流通貨幣計算---real_dollars是  "扣除通膨影響" 的實質貨幣; f 是通貨膨脹率 ; period是設定期間長度
def current_dollars(real_dollars,f, period):
    result = real_dollars*pow(1+f,period)
    return result

#將市場利率轉換為無通膨利率(扣除無加入通貨膨脹率進行計算的真實名目利率)
def no_inflation_interest(market_interest, f):
    result = (1+market_interest) / (1+f) -1
    return result

#進行匯率轉換後的金額(target_dollars是目標貨幣金額, exchange_rate是匯率，target_currency_percent是將目標貨幣轉換為本國貨幣的匯兌)
def currency_converter(target_dollars, exchnge_rate,target_currency_percent,period):
    result = target_dollars / pow((1+exchnge_rate),period)*target_currency_percent
    return result

#===================現金流===================

#===================利息===================

#單筆款項複利總額分析(single-payment compound amount analysis)
def spca_func(cash_flow, interest, period):
    future_cash_flow = cash_flow*pow((1+interest),period)
    return future_cash_flow

#等額多次付款系列複利總額分析(equal-payment series compound amount analysis)
def epsca_func(annual_cash_flow, interest, period):
    i = 0
    factor = 0
    while i < period:
        factor_n = pow((1+interest),i)
        factor = factor + factor_n
        i = i+1
    future_cash_flow = annual_cash_flow*factor
    return future_cash_flow

#等差變額系列複利總額分析(arithmetical-progression-payment series compound amount analysis)
def appsca_func(general_cash_flow, interest, period):
    factor = (pow((1+interest),period) - period*interest - 1) / pow(interest,2)
    future_cash_flow = general_cash_flow*factor
    return future_cash_flow

#等比變額系列複利總額分析(geometric-progression-payment series compound amount analysis)
def appsca_func(cash_flow, interest, period, cash_flow_grow_interest):
    if interest != cash_flow_grow_interest:
        factor = (pow((1+interest),period) - pow((1+cash_flow_grow_interest),period)) / (interest - cash_flow_grow_interest)
    else:
        factor = period*pow((1+interest),(period-1))
    future_cash_flow = cash_flow*factor
    return future_cash_flow






#不規則現金流與利率的複利總額因子(no-rule-payment series compound amount factor)



a = appsca_func(130,0.08,5)
print(a)







#===================利息===================