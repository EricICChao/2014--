__author__ = 'Eric'

import csv


"""
with open('C://Users//Eric//Desktop//test.csv') as f2:
    f_2 = csv.DictReader(f2)
    for y in f_2:
        print(y)
        e = y.get('人口')
        print(e)
        f = float(e)
        ee = f +1000
        print(ee)



"""



#資料來源模組: csv格式，取得檔案路徑
def csv_data_file_path():
    a = input ("欲分析資料的檔案名稱(建議用MS EXCEL轉.csv，再放電腦桌面): ")
    b = "C://Users//Eric//Desktop//" +a + ".csv"
    return b

#資料分析變數數量設定與名稱選擇模組
def analysis_var_choices():
    a = input("您要分析的資料變數項目有幾個: ")
    a_int = int(a)
    i = 0
    b = []
    while i< a_int:
        c = input("請輸入欲分析的變數名稱:")
        b.append(c)
        i = i+1
    return b

#個別變數資料匯入模組，沒經過特別設定，跑出來的資料皆為字串格式，必須再自行轉型
def data_import(data_file_path, var_name):
    a = []
    with open(data_file_path) as f:
        f_1 = csv.DictReader(f)
        for y in f_1:
            e = y.get(var_name)
            a.append(e)
    return a





#分析結果儲存模組
#這邊的資料記得儲存完結果後要關起來

"""
test_a = csv_data_file_path()
print(test_a)
test_b = analysis_var_choices()
print(test_b)
test_c = data_import(test_a, '人口')
print(test_c)
"""
