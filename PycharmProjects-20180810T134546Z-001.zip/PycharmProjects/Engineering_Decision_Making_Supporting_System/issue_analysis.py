__author__ = 'Eric'

import math, data_facilities, analysis_module

#=====================================
#每一個議題的類別都要有一個data_file_path!!!!



#=====================================


class interest_issue:
    def __init__(self, data_file_path):
        capital = input("請輸入本金總額: ")
        interest = input("請輸入名目利率或利息: ")
        period_n = input("請輸入期數: ")
        NI_percent = input("請輸入名目週期的比例:")
        c = float(capital)
        i = float(interest)
        p = float(period_n)
        nip = float(NI_percent)
        self.c = c
        self.i = i
        self.p = p
        self.nip = nip
    def interest_issue(self):
    #單利
        total_Single = self.c*(1+self.i*self.p)
        total_Single_r = self.c*self.i*self.p
        a = str(total_Single)
        b = str(total_Single_r)
        print("如利息為單利，需支付的利息總額: " + b)
        print("需支付的本金+利息總額: " + a)
        print("=======================================")
    #複利
        px = 0
        print("如利息為複利")
        while px<self.p:
            total_Com = self.c*pow((1+self.i),px)
            total_Com_r = total_Com - self.c
            d = str(total_Com)
            f = str(total_Com_r)
            pxstr = str(px)
            print("第" + pxstr + "期:")
            print("複利利息下需支付的利息總額: " + f)
            print("複利利息下需支付的本金+利息總額: " + d)
            px = px+1
        print("=======================================")
    #名目利率轉實際利率
        print("如果是名目利率轉實際利率")
        ans = self.i/self.p
        ansstr = str(ans)
        print("每一期的實際利率為: " + ansstr)
        print("=======================================")
    #實際利率換算---貸款成本或是投資收益的計算
        print("實際利率")
        m = self.i/self.p
        rir = pow((1+m),self.p) -1
        rirstr = str(rir)
        print("有效的實際利率為: "+ rirstr)
    #連續性複利計算
    def Compound_Continue_interest_issue(self):
        cc = pow(math.e,self.it*self.nip) -1
        cc_str = str(cc)
        print("連續性複利的情況下之複利為:"+ cc_str)
    #將市場利率轉換為無通膨利率(扣除無加入通貨膨脹率進行計算的真實名目利率)
    def no_inflation_interest(self):
        inflation = input("請輸入通貨膨脹率: ")
        floinf = float(inflation)
        result = analysis_module.no_inflation_interest(self.i,floinf)
        strresult = str(result)
        print("無通膨影響的真實名目利率為: " + strresult)

#現金流或通貨膨脹衡量議題
class cash_flow_and_purchasing_power_issue:
    def __init__(self, data_file_path):
        var_name_times = input("請輸入指定的時間項目的變數名稱")
        object_1 = input("請輸入要衡量的議題名稱:")
        object_2 = input("請輸入時間單位")
        print("請問您所需要的衡量期間為: ")
        period_start = input("從  ")
        print(object_2)
        period_end = input("到  ")
        print(object_2)
        times_set = data_facilities.data_import(data_file_path, var_name_times)
        a = times_set.index(period_start) #指定的時間資料在set的位置(開始)
        b = times_set.index(period_end)   #指定的時間資料在set的位置(結束)
        intps = int(period_start)
        intpe = int(period_end)
        self.data_file_path = data_file_path
        self.var_name_times = var_name_times
        self.object_1 = object_1
        self.object_2 = object_2
        self.period_start = period_start   #字串格式
        self.period_end = period_end       #字串格式
        self.intps = intps                 #int格式
        self.intpe = intpe                 #int格式
        self.times_set = times_set
        self.a = a
        self.b = b
    #單一項目的通膨
    def Single_item_inflation(self):
        var_name_PI = input("請輸入指定的物價指數(PI)的變數名稱")
        PI_set = data_facilities.data_import(self.data_file_path, var_name_PI)
        #取得所在list位址的方法
        purchasing_cost_grow = float(PI_set[self.b]) / float(PI_set[self.a])
        purchasing_power = float(PI_set[self.a]) / float(PI_set[self.b])
        strpcg = str(purchasing_cost_grow)
        strpp = str(purchasing_power)
        print("在" + self.times_set[self.b] + self.object_2 + "要花上" + strpcg + "倍的成本才能得到和" + self.times_set[self.a] + self.object_2 + "同樣多的品項或服務")
        print(self.times_set[self.b] + "的購買力是" + self.times_set[self.a] + "的" + strpp + "倍")
        inflation_period = int(self.times_set[self.b]) - int(self.times_set[self.a])
        f = pow(purchasing_cost_grow,1 / inflation_period) - 1
        strf = str(f)
        if f >= 0:
            print("從" + self.times_set[self.a] + self.object_2 + self.times_set[self.b] + self.object_2 + "，這段期間的平均通貨膨脹率為" + strf)
        elif f < 0:
            print("從" + self.times_set[self.a] + self.object_2 + self.times_set[self.b] + self.object_2 + "，這段期間的平均通貨緊縮率為" + strf)
    #還原無通膨情形下貨幣現金流
    def real_dollars_issue(self):
        period = self.intpe-self.intps+1
        i = 0
        a = self.a
        var_name = input("請輸入指定計算的現金流的變數名稱(他們每一年的金額(包含增長率等等)請先計算好!!)")
        var_name_inflation = input("請輸入指定計算的通貨膨脹率的變數名稱")
        cash_flow_set = data_facilities.data_import(self.data_file_path, var_name)
        inflation_set = data_facilities.data_import(self.data_file_path, var_name_inflation)
        while i < period:
            floinf = float(inflation_set[a])
            flocash= float(cash_flow_set[a])
            result = analysis_module.real_dollars(flocash,floinf,period)
            strresult =str(result)
            times = self.times_set[a]
            print(times + self.object_2 + "的實質貨幣現金流為" +strresult)
            i = i+1
            a = a+1
    #考慮通膨情形下的貨幣現金流
    def current_dollars_issue(self):
        period = self.intpe-self.intps+1
        i = 0
        a = self.a
        var_name = input("請輸入指定計算的無通膨情形現金流的變數名稱(他們每一年的金額(包含增長率等等)請先計算好!!)")
        var_name_inflation = input("請輸入指定計算的通貨膨脹率的變數名稱")
        cash_flow_set = data_facilities.data_import(self.data_file_path, var_name)
        inflation_set = data_facilities.data_import(self.data_file_path, var_name_inflation)
        while i < period:
            floinf = float(inflation_set[a])
            flocash= float(cash_flow_set[a])
            result = analysis_module.current_dollars(flocash,floinf,period)
            strresult =str(result)
            times = self.times_set[a]
            print(times + self.object_2 + "的流通貨幣現金流為" +strresult)
            i = i+1
            a = a+1
    #匯兌轉換後的現金流
    def currency_converter_cash_flow(self):
        period = self.intpe-self.intps+1
        i = 0
        a = self.a
        var_name = input("請輸入指定計算的目標貨幣的現金流的變數名稱(他們每一年的金額(包含增長率等等)請先計算好!!)")
        var_name_exchange_rate = input("請輸入指定計算的匯率的變數名稱")
        var_name_target_currency_percent = input("請輸入指定計算的匯兌的變數名稱")
        cash_flow_set = data_facilities.data_import(self.data_file_path, var_name)
        exchange_rate_set = data_facilities.data_import(self.data_file_path, var_name_exchange_rate)
        target_currency_percent_set = data_facilities.data_import(self.data_file_path, var_name_target_currency_percent)
        while i < period:
            floexc = float(exchange_rate_set[a])
            flocash= float(cash_flow_set[a])
            flotcp = float(target_currency_percent_set[a])
            result = analysis_module.currency_converter(flocash,floexc,flotcp,period)
            strresult =str(result)
            times = self.times_set[a]
            print(times +"將目標貨幣轉換為"+ self.object_2 + "的現金流為" +strresult)
            i = i+1
            a = a+1




a = interest_issue("C://Users//Eric//Desktop//test.csv")
#a.Single_item_inflation()
a.no_inflation_interest()


