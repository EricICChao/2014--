__author__ = 'Eric'

import sys, data_facilities


#================================前置區====================================================
first_stage_control_analysis = '1'
first_stage_control_exit = '2'
result_file_name = input("請輸入記錄的檔案名稱(請擺放在電腦的桌面位置): ")
result_file = open("C://Users//Eric//Desktop///"+ result_file_name + ".txt", 'xt', encoding= "utf8", newline = '')

first_stage = input("你想執行的動作: (1)執行分析 (2)離開系統")
while first_stage != '1' and '2':                      #沒有選擇兩種選項的下場
    print("請重新選擇!!!!!!")
    first_stage = input("你想執行的動作: (1)執行分析 (2)離開系統    the")
    if first_stage == first_stage_control_exit:       #選擇離開系統
        result_file.close()
        sys.exit()
    else:
        continue
if first_stage == first_stage_control_exit:           #選擇離開系統
    result_file.close()
    sys.exit()
#================================前置區====================================================







#================================分析區====================================================
while first_stage == first_stage_control_analysis:    #選擇執行分析
    analysis_module_code = []                         #分析模組的代號，給second_stage用

    """分析模組代號

分析模組的代號，給second_stage用


      分析模組代號"""
    second_stage = input("請輸入你要執行的分析項目:")
    third_stage = data_facilities.csv_data_file_path()




    original_stage = input("你想執行的動作: (1)執行分析 (2)離開系統  original")
    if original_stage =='2':
        result_file.close()
        sys.exit()
    while original_stage != '1' and '2':
        print("請重新選擇!!!!!")
        original_stage = input("你想執行的動作: (1)執行分析 (2)離開系統  original_2")
        if original_stage == '2':                        #選擇離開系統
            result_file.close()
            sys.exit()
    if original_stage == '1':
        continue

#================================分析區====================================================




