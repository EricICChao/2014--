__author__ = 'Eric'

#資料夾型操作的資料庫
#雲端版本所有節點最好保存在相同路徑(可以先紀錄要加入的節點的使用者名稱和IP host，惠較好搜尋和分配資料存放空間)
#雲端版的話，各節點的資料夾是相同名稱，但最後面繪被標上編號(1),(2)(3),(4),(5).......
#實現無線網路間的節點資料傳輸與操作

"""
資料庫基礎功能:
    創造儲存空間與檔案
    資料寫入指定的空間檔案
    指定的檔案空間的資料讀出
    編輯資料檔
    搜尋資料

資料的儲存方式:
    csv為主要資料儲存格
    txt存放大型文字資料
    影片, 圖片, 未知類型檔案存放

運用路徑操作與搜尋所有資料檔案
創建後的資料夾內放文字檔，紀錄路徑以供操作時路徑讀取使用
所有資料庫檔案預設存放地點為 D://
暫存檔案和目錄的操作

"""

import os, csv
from sys import*

#創建新的資料庫
def create_database():
    dir_name = input("請輸入創建的資料庫名稱: ")
    path = "D://"+dir_name
    os.mkdir(path)
    return path  #創建完成回傳path

#查詢檔案列表用
def get_list(file_name):
    list_table = os.listdir("D://" + file_name)
    print(list_table)


#指定要操作的目標對像，先設定路徑
def operator_object(path):
    dir_object = input()
    object_path = path + dir_object
    return object_path

#檔案的各種open操作--> (Ver 2.0後導入)
def file_operation(path, mode, encode, f, choice, something):
    with open(path, mode, encode)as f:
        if choice == "w":
            f.write(something)
        elif choice =="r":
            f.read()
        else:
            print("沒有這種操作，請重新設定: ")
            exit()

#判讀模組，減查是否已經指定好要操作的資料庫或是檔案--> (Ver 2.0後導入)
def file_path_exist(path):
    if path == "":
        print("沒有指定的相關檔案或是資料庫!!!!!")
        exit()

"""===================================
以下未測試!!!!!!!
"""
#資料來源模組: csv格式，取得檔案路徑
def csv_data_file_path():
    a = input ("欲分析資料的檔案名稱(建議用MS EXCEL轉.csv，再放電腦桌面): ")
    b = "C://Users//Eric//Desktop//" +a + ".csv"
    return b

#資料分析變數數量設定與名稱選擇模組
def analysis_var_choices():
    a = input("您要分析的資料變數項目有幾個: ")
    a_int = int(a)
    i = 0
    b = []
    while i< a_int:
        c = input("請輸入欲分析的變數名稱:")
        b.append(c)
        i = i+1
    return b

#個別變數資料匯入模組，沒經過特別設定，跑出來的資料皆為字串格式，必須再自行轉型
def data_import(data_file_path, var_name):
    a = []
    with open(data_file_path) as f:
        f_1 = csv.DictReader(f)
        for y in f_1:
            e = y.get(var_name)
            a.append(e)
    return a

















