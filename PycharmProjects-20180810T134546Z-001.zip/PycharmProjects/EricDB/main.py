__author__ = 'Eric'

"""
EricDB概念:
    硬碟資料庫化
    不想學SQL
    不進入系統也可以直接操作檔案資料
    只用能理解和電腦能直接開啟使用的檔案
    電腦硬體多大，資料存放多大
    資料庫業務項目流程打包(不用再做額外設定)
"""

from core_func import*
from shutil import*
import sys, os

dir_operation_database = ""                 #指定目前要操作的資料庫
dir_operation_database_file = ""            #指定目前要操作的資料庫的檔案
dir_operation_file = ""                     #指定目前要操作的檔案(非隸屬於任何資料庫的檔案)

#顯示所有功能的資訊
def system_guide():
    print("操作功能資訊: \n"
          "*****資料創建*****\n"
          "cdb: 創建資料庫\n"                   #已完成
          "cdbf: 創建檔案(.csv, .txt)\n"          #已完成
          "*****資料查詢*****\n"
          "rdb: 查詢所有的資料庫的清單\n"             #已完成
          "rdbf: 查詢指定的資料庫檔案的清單\n"              #已完成
          "rdbfd: 查詢檔案內的資料\n"
          "*****資料寫讀*****\n"
          "vdata: 檢視資料，列出資料的筆項編號\n"
          "wdata: 修改或key資料到指定的檔案\n "
          "*****資料刪除*****\n"
          "ddb: 刪除資料庫\n"                            #已完成
          "ddbf: 刪除指定的資料庫檔案\n"                #已完成
          "*****系統操作*****\n"
          "e: 結束操作\n"                                                                                                         #已完成
          "dirdb: 指定要操作的資料庫\n"      #設一變數存放指定資料庫的路徑                                                                                                               #已完成
          "dirf: 指定要操作的檔案\n"            #設一變數存放指定檔案的名稱                                                                                                               #已完成
          "dirdbf: 指定要操作的資料庫的檔案\n" #設一變數存放指定檔案的名稱，和上面的路徑結合坐各種指定的資料庫的檔案的操作應用       #已完成
          "edb: 退出指定要操作的資料庫\n"   #將這個變數存放的指定資料庫的路徑" "
          "edbf: 退出指定要操作的檔案\n"    #將這個變數存放的檔案名稱擺入" "
          )

"""
1.旗標對應要開啟的操作功能的函式
2.旗標對應要開啟的作業流程的功能
3.旗標對應要開啟的分析功能的函式
"""
system_guide()
flag = input("請選擇欲執行的工作:  ")

#將所有功能一個一個插進 if 和 elif迴圈裡，這樣的設計方便擴充
#記得操作完成後還能再回來繼續選flag(只要沒選'e'就可以繼續下去)
while flag != 'e':
    try:
        if flag == 'cdb':
            #創造一個新的資料庫(資料夾)，檔案路徑加入database_path_list.txt檔案的最後面一行，供後續查詢操作用
            stage_a = create_database()
            with open('database_path_list.txt', 'at', encoding= 'utf-8') as database_list:
                database_list.write(stage_a + "\n")
        elif flag == 'rdb':
            #將database_path_list.txt打開，所有的資料庫和路徑在此
            with open('database_path_list.txt', 'rt', encoding= 'utf-8') as f:
                database_list = f.read()
                print(database_list)
        elif flag == 'rdbf':
            #用Python提供的函式開啟指定資料庫(資料夾)，列出裡面有的檔案清單
            dir_database_name = input("請輸入欲查詢的資料庫的名稱: ")
            get_list(dir_database_name)
        elif flag == 'cdbf':
            choice_your_file_format = input("請選擇要新增的檔案格式: (1).csv (2).txt")
            #創造CSV或txt 檔案，先在資料庫存放txt和csv的原始檔，之後每創造一個就複製道指定的資料庫。
            if dir_operation_database == "":
                print("沒有此種操作方式!!")
                break
            else:
                create_file_name = input("請輸入欲創建檔案名稱: ")
                if choice_your_file_format == "1":
                    copy("C://Users//Eric//PycharmProjects//EricDB//file_src//csv_src.csv", dir_operation_database)             #shutil模組複製指定的檔案(路徑)到指定的空間(路徑)
                    os.renames(dir_operation_database+"//csv_src.csv",dir_operation_database+"//"+create_file_name+".csv")    #把舊檔名改成新檔名
                elif choice_your_file_format == "2":
                    copy("C://Users//Eric//PycharmProjects//EricDB//file_src//txt_src", dir_operation_database)
                    os.renames(dir_operation_database+"//txt_src",dir_operation_database+"//"+create_file_name)
                else:
                    print("沒有此種操作方式!!")
                    break
        elif flag == 'dirdb':
            print("輸入要操作的資料庫的名稱: ")
            dir_operation_database = operator_object("D://")
        elif flag == 'dirdbf':
            print("輸入要操作的資料庫的名稱: ")
            dir_operation_database = operator_object("D://")
            print("輸入要操作的檔案的名稱: ")
            dir_operation_database_file = operator_object(dir_operation_database+"//")
        elif flag == 'dirf':
            path = ""
            path_choice = input("請指出檔案位置: (1)C槽, (2)D槽, (3)其他")
            if path_choice == "1":
                path = "C://"
            elif path_choice == "2":
                path = "D://"
            elif path_choice == "3":
                path = input("請輸入路徑: ")
            else:
                print("沒有此種操作方式!!")
                continue
            print("輸入要操作的檔案的名稱: ")
            dir_operation_file = operator_object(path)
        elif flag == 'ddb':
            print("請先確認資料庫已經沒檔案了，否則刪除失敗\n")       #(Ver 2.0後導入可以自動刪除資料夾內所有檔案的功能)
            delete_database = input("請輸入欲刪除的資料庫路徑: ")
            os.rmdir(delete_database)              #刪除資料夾，前提是裡面已清空
        elif flag == 'ddbf':
            delete_database_file = input("請輸入欲刪除的資料庫檔案路徑: ")
            os.remove(delete_database_file)

    except Exception:
        print("本系統無此操作方法!!!!")
        sys.exit()
    except:
        sys.exit()
    flag = input("繼續選擇要執行的工作: ")

#以下為測試:
print(dir_operation_database)
print(dir_operation_database_file)
print(dir_operation_file)