__author__ = 'Eric'

"""
假設有x,y兩個整數變數，界於0~10之間。
模糊蘊涵(fuzzy implication):
蘊涵法則(邏輯表示)
給予條件: x屬於[1~3]--->y屬於[7~8]
               x = 5
推論結果: y is unknown (y屬於[0~10])


模糊對應(fuzzy mapping):  前件變數(antecedent variables)和後件變數(consequent variables)的模糊關係(FuzzyOperations和fuzzy_dict屬之)
對應法則(程序表示)
陳述(statement): if x 屬於[1~3], then y 屬於[7~8]
variable value: x = 5
執行結果: no action

模糊蘊涵的關係:
(x is A)---> (y is B)
A和B分別是某兩個更大的集合U和V的子集合(卡式乘積的概念)
模糊蘊涵表示的是 "事件的程度"，一個蘊涵關係R的定義:
R(x,y) = 可能性分佈大PI((x = xi)-->(y = yi))
可能性分佈(possibility distribution)在模糊邏輯中，是建構成說明蘊涵的真假值。

EX:
一個真假值的命題t
大PI((x = xi)-->(y = yi)) = t((xi is A)-->(yi is B))
以ai,bj代表t(xi is A)和t(yj is B)較方便後續說明
蘊涵t的真假值以函數I表示: t((xi is A)-->(yj is B)) = I(ai, bj)
函數I是一個蘊涵函數(implication function)



"""