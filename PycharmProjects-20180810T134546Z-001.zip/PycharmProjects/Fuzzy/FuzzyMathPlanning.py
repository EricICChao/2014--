__author__ = 'Eric'

import FuzzyOperations
import fuzzy_dict

"""
對稱式模型: 同等對待目標函數及限制式的模型。
意義為: (1)目標函式和限制式均為模糊狀態、故同表為模糊形式。
            (2)最佳解為同時滿足目標函數及限制式至最高程度者。
"""

#模糊單目標線性規畫模型
#函數對稱型(1OK)
def fuzzyMathPlanning_1ok():
