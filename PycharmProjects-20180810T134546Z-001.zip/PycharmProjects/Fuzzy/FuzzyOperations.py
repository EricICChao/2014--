__author__ = 'Eric'

#函式命名規則:   5s1i1c = 五次方程式，其中一次方項目有一個，常數項有一個
import math

"""
模糊集合基本運算:
三條線的等號 : 定義
兩組集合: A, B


模糊集合的補集(complement):
ua(x) 屬於[0,1]
x 屬於U
complement A= 1 - ua(x)

模糊集合的交集(intersection):
ua and b(x) = min[ua(x), ub(x)]  定義為ua(x)和ub(x)的最小相同值(最小運算)
x 屬於U，
Intersection (A,B) 的內容要同時屬於A和B的論域中的元素(意即ua(x)和ub(x)用的U是同一套)，且以歸屬度最小值為主

模糊集合的聯集(Union):
ua or b(x) = max[ua(x), ub(x)]  定義為ua(x)或ub(x)擁有的最大值或是最大共同值(最大運算)
x 屬於U，
Union (A,B) 為A屬於Union A,B 和 B屬於Union A,B   (ua(x)和ub(x)用的U是同一套)

模糊集合的相等(Equality): 確認兩集合的相等程度(degree of  equality)
使用相似評量(similarity measue):
E(A,B) 定義為 degree(A = B) = | Intersection A,B | / | Union A,B |
if A = B --> E(A,B) = 1;  | Intersection A,B | = 0 --> E(A,B) = 0。
0 =< E(A,B) =< 1

模糊集合的子集合(Subset):
A是B的子集合，A屬於B，ua(x) =< ub(x)，x屬於U。
為描述其程度關係，使用子集評量(subsethood measure):
S(A,B) 定義為 degree(A屬於B) =  | Intersection A,B | / | A |

狄摩根定律(De Morgan's Law):
complement (Union A,B) = Intersection(complement A , complement B)
complement (Intersection A,B) = Union(complement A , complement B)
"""

#set型態可以直接做集合運算，但是字典(dict)型態必須轉成檢視表才可做集合運算，請見: 精通Python 3程式設計 (第二版) p.129
#歸屬度函數ua(x)，要寫成一組數學公式


#模糊補集(fuzzy_complement): 1-func_ans
def fuzzy_complement_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
           fuzzy_attr.append(1-func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    return xx

#PI函數專用模糊補集(fuzzy_complement): 1-func_ans
def fuzzy_PI_complement(a,b,r,u_set):
    zero_x = []
    a2b_x = []
    a2b_attr = []
    b2r_x = []
    b2r_attr = []
    one_x = []
    for x in u_set:
        c = (x-a) / (r-a)
        d = (x-r) / (r-a)
        e = 2*pow(d,2)
        func_a2b = 2*pow(c,2)
        func_b2r = 1-e
        if a <= x <= b and 0 < func_a2b < 1:
            a2b_attr.append(1-func_a2b)
            a2b_x.append(x)
        elif b <= x <= r and 0 < func_b2r < 1:
            b2r_attr.append(1-func_b2r)
            b2r_x.append(x)
        elif x <= a and func_a2b == 1:
            zero_x.append(x)
        elif x >= r and func_b2r == 0:
            one_x.append(x)
    a2b_dict = dict(zip((a2b_x),(a2b_attr)))
    b2r_dict = dict(zip((b2r_x),(b2r_attr)))
    return a2b_dict, b2r_dict, one_x, zero_x

#模糊交集(intersection)
def fuzzy_intersection_5s1i1c(a,b,c,d,e,con,a_b,b_b,c_b,d_b,e_b,con_b,a_set,b_set):
   value_set = []
   abu_set = []
   for x in a_set & b_set:
       a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
       b_ans = a_b*pow(x,5)+b_b*pow(x,4)+c_b*pow(x,3)+d_b*pow(x,2)+e_b*pow(x,1)+con_b
       if a_ans < b_ans and 0 <= a_ans <= 1:
           value_set.append(a_ans)
           abu_set.append(x)
       elif b_ans < a_ans and 0 <= b_ans <= 1:
           value_set.append(b_ans)
           abu_set.append(x)
   xx = dict(zip((abu_set),(value_set)))
   return xx

#模糊聯集(Union)
def fuzzy_union_5s1i1c(a,b,c,d,e,con,a_b,b_b,c_b,d_b,e_b,con_b,a_set,b_set):
    value_set = []
    abu_set = []
    for x in a_set | b_set:
        a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        b_ans = a_b*pow(x,5)+b_b*pow(x,4)+c_b*pow(x,3)+d_b*pow(x,2)+e_b*pow(x,1)+con_b
        if a_ans > b_ans and 0 <= a_ans <= 1:
            value_set.append(a_ans)
            abu_set.append(x)
        elif b_ans > a_ans and 0 <= b_ans <= 1:
            value_set.append(b_ans)
            abu_set.append(x)
    xx = dict(zip((abu_set),(value_set)))
    return xx

#相似評量法(similarity_measure): 模糊集合的相等(Equality): 確認兩集合的相等程度(degree of  equality)
def fuzzy_similarity_measure_5s1i1c(a,b,c,d,e,con,a_b,b_b,c_b,d_b,e_b,con_b,a_set,b_set):
   value_set = []
   value_set2 = []
   for x in a_set & b_set:
       a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
       b_ans = a_b*pow(x,5)+b_b*pow(x,4)+c_b*pow(x,3)+d_b*pow(x,2)+e_b*pow(x,1)+con_b
       if a_ans < b_ans and 0 <= a_ans <= 1:
           value_set.append(a_ans)
       elif b_ans < a_ans and 0 <= b_ans <= 1:
           value_set.append(b_ans)
   xx = sum(value_set)
   math.fabs(xx)
   for x in a_set | b_set:
        a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        b_ans = a_b*pow(x,5)+b_b*pow(x,4)+c_b*pow(x,3)+d_b*pow(x,2)+e_b*pow(x,1)+con_b
        if a_ans > b_ans and 0 <= a_ans <= 1:
            value_set2.append(a_ans)
        elif b_ans > a_ans and 0 <= b_ans <= 1:
            value_set2.append(b_ans)
   xx_2 = sum(value_set2)
   math.fabs(xx_2)
   return xx / xx_2

#子集評量法(subset_measure): 當A是B的子集時，為確認其程度的關係
def fuzzy_subset_measure_5s1i1c(a,b,c,d,e,con,a_b,b_b,c_b,d_b,e_b,con_b,a_set,b_set):
   value_set = []
   value_set2 = []
   for x in a_set & b_set:
       a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
       b_ans = a_b*pow(x,5)+b_b*pow(x,4)+c_b*pow(x,3)+d_b*pow(x,2)+e_b*pow(x,1)+con_b
       if a_ans < b_ans and 0 <= a_ans <= 1:
           value_set.append(a_ans)
       elif b_ans < a_ans and 0 <= b_ans <= 1:
           value_set.append(b_ans)
   xx = sum(value_set)
   math.fabs(xx)
   for x in a_set:
        a_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= a_ans <= 1:
            value_set2.append(a_ans)
   xx_2 = sum(value_set2)
   math.fabs(xx_2)
   return xx / xx_2

"""
#分解定理(resolution principle):
#代表定裡(representation principle):
#取得各個截集的元素
#將各截集中相同元素的值進行比較
#將最大的值取出
#對應到所屬的元素x
#組成


擴張定裡: X為值域(universe)之卡式乘積(X(1).....X(r))，A(1)....A(r)為卡式乘積上r個模糊集合，
f是從X到值域Y的mapping，擴張定理允許我們去定義一個在Y中的模糊集合B:
Ｂ = {(y, uｂ(y)) | y= f(x1.....xr), x1.....xr屬於卡式乘積 }
ub(y)
((x1.....xr)屬於不定積分f^(-1)(y))sup   min{ua1(x1).......uar(xr)},  if不定積分f^(-1)(y) 不等於 phi



模糊數 ~M(fuzzy number): 在一條實數線R上為一凸狀(convex)正規化(normalized)的模糊集合~M使得:

1.恰好存在一個x0屬於R且um(x0) = 1
2.um(x0)為片段連續
1.模糊數為正定，um(x)=0，所有x <0
2.模糊數為負定，um(x)=0，所有x >0
1.一個二元運算子(binary operation)*，稱為遞增(遞減)，
for x1 > x2  &  y1 > y2
x1*x2 > y1*y2 (x1*x2 < y1*y2

模糊數單一運算(uniary operation):
f: X--->Y，X=X1，所有模糊數~M 屬於F(R)
uf(~m)(z)= x屬於不定積分f^(-1)(z) sup u~m(x)

模糊數擴充加法(extended addition)
f(~M, ~N) = ~M + ~N，為一模糊數，~M, ~N屬於F(R)，~M+~N屬於F(R)
~M+0 = ~M，所有~M屬於F(R)

模糊數擴充乘積(extended product)
R+的乘法是遞增運算子，R-的乘法是遞減運算子。
正定模糊數的乘積(或負定)會導致為正定模糊數。

模糊數擴充減法(extended subtraction):
u(z) = (z =x-y) sup min(um(x), un(y)) = (z =x+y) sup min(um(x), un(-y))   取歸屬度最小值者

模糊數擴充除法(extended division):
if ~M, ~N為嚴格正定的模糊數(um(x) = 0, un(x) = 0, 所有x <= 0)
u(z) = (z =x/y) sup min(um(x), un(y)) = (z =xy) sup min(um(x), un(1/y))   取歸屬度最小值者



模糊集合的左右延展表示(LR-Presentation Fuzzy set)
一個模糊數是LR-type:
if 存在參考函數L(for left), R(for right)，且純量 alpha >0, beta >0:
um(x)= L:(m-x / alpha)  for x < m；R:(x-m / beta)  for x > m
m為中間值(mean)且為實數，~M = (m, alpha, beta)LR，
一個模糊區間~M是LR-type:
if m不是實數而是為區間(!m, m!)，則~M不是模糊數，而是模糊區間(fuzzy interval)
if 存在參考函數L, R且有4個參數: (!m, m!)屬於R^2或是{-lim, +lim}， alpha, beta，則~M的歸屬度函數為:
um(x)= L:(!m-x / alpha)  for x < !m；1 for !m <= x <= m!；R:(x-m! / beta)  for x > m!
模糊區間~M = (!m, m!, alpha, beta)LR
if~M是明確實數--> ~M= (m,m,0,0)LR，屬於L, 屬於R
if~M是明確區間--> ~M= (a,b,0,0)LR，屬於L, 屬於R
if~M是梯形模糊數--> L(x) = R(x) = (0, 1-x)

LR-type運算:
~M = (m, a, b)LR, ~N = (n, c, d)LR
(m, a, b)LR+(n, c, d)LR = (m+n, a+c, b+d)LR
-(m, a, b)LR = (-m, a, b)LR
(m, a, b)LR-(n, c, d)LR = (m-n, a+d, b+c)LR

if~M, ~N為模糊數且皆為正定:
(m, a, b)LR*(n, c, d)LR 近似 (mn, mc+na, md+nb)LR
if~M為正定，~N為負定:
(m, a, b)LR*(n, c, d)LR 近似 (mn, na-md, nb - mc)LR
if~M, ~N為模糊數且皆為負定:
(m, a, b)LR*(n, c, d)LR 近似 (mn, -nb-md, na-mc)LR
"""

#模糊集合LR表示法擴充加法
#模糊數 ~M(fuzzy number): 在一條實數線R上為一凸狀(convex)正規化(normalized)的模糊集合

#m是實數且為模糊數中間值, a>0, b>0, 且m所對應的歸屬值恰好為1
def fuzzy_LR_type_fuzzy_number(m,a_left,b_right, u_set):
    left_x = []
    right_x = []
    left_attr = []
    right_attr = []
    for x in u_set:
        func_a = (m-x) / a_left
        func_b = (x-m) / b_right
        if x <= m and 0 <= func_a < 1:
            left_attr.append(func_a)
            left_x.append(x)
        if x >= m and 0 <= func_b < 1:
            right_attr.append(func_b)
            right_x.append(x)
    left_xx = dict(zip((left_x),(left_attr)))
    right_xx = dict(zip((right_x),(right_attr)))
    return left_xx, right_xx, m

#m不是實數而是區間(!m, m!)且為模糊數中間值, a>0, b>0, 且區間內(!m, m!)的歸屬值都為1
def fuzzy_LR_type_fuzzy_interval(m_left,m_right,a_left,b_right, u_set):
    left_x = []
    left_attr = []
    right_x = []
    right_attr = []
    one_umx = []
    for x in u_set:
        func_a = (m_left-x) / a_left
        func_b = (x-m_right) / b_right
        if x <= m_left and 0 <= func_a < 1:
            left_attr.append(func_a)
            left_x.append(x)
        if x >= m_right and 0 <= func_b < 1:
            right_attr.append(func_b)
            right_x.append(x)
        elif m_left <= x <= m_right:
            if func_a == 1 or func_b == 1:
                one_umx.append(x)
    left_x = dict(zip((left_x),(left_attr)))
    right_x = dict(zip((right_x),(right_attr)))
    return left_x, right_x, one_umx

#歸屬函數模型
#S函數 (單調遞增型函數)
def fuzzy_LR_type_S_function(a,b,r, u_set):
    zero_x = []
    a2b_x = []
    a2b_attr = []
    b2r_x = []
    b2r_attr = []
    one_x = []
    for x in u_set:
        c = (x-a) / (r-a)
        d = (x-r) / (r-a)
        e = 2*pow(d,2)
        func_a2b = 2*pow(c,2)
        func_b2r = 1-e
        if a <= x <= b and 0 < func_a2b < 1:
            a2b_attr.append(func_a2b)
            a2b_x.append(x)
        elif b <= x <= r and 0 < func_b2r < 1:
            b2r_attr.append(func_b2r)
            b2r_x.append(x)
        elif x <= a and func_a2b == 0:
            zero_x.append(x)
        elif x >= r and func_b2r == 1:
            one_x.append(x)
    a2b_dict = dict(zip((a2b_x),(a2b_attr)))
    b2r_dict = dict(zip((b2r_x),(b2r_attr)))
    return a2b_dict, b2r_dict, one_x, zero_x

#Z函數 (單調遞減型 ，S型函數的相反版)
def fuzzy_LR_type_Z_function(a,b,r, u_set):
    zero_x = []
    a2b_x = []
    a2b_attr = []
    b2r_x = []
    b2r_attr = []
    one_x = []
    for x in u_set:
        c = (x-a) / (r-a)
        d = (x-r) / (r-a)
        e = 2*pow(d,2)
        func_a2b = 2*pow(c,2)
        func_b2r = 1-e
        if a <= x <= b and 0 < func_b2r < 1:
            a2b_attr.append(func_b2r)
            a2b_x.append(x)
        elif b <= x <= r and 0 < func_a2b < 1:
            b2r_attr.append(func_a2b)
            b2r_x.append(x)
        elif x <= a and func_b2r == 0:
            zero_x.append(x)
        elif x >= r and func_a2b == 1:
            one_x.append(x)
    a2b_dict = dict(zip((a2b_x),(a2b_attr)))
    b2r_dict = dict(zip((b2r_x),(b2r_attr)))
    return a2b_dict, b2r_dict, one_x, zero_x



#PI函數
def fuzzy_LR_type_PI_function(b,r,u_set):
    a = []
    c = []
    for x in u_set:
        if x <= r:
            a.append(x)
        elif x >= r:
            c.append(x)
    e = fuzzy_PI_complement(r,r+b/2,r+b,c)
    d = fuzzy_LR_type_S_function(r-b, r-b/2, r, a)
    print(d)
    print(e)

#梯形歸屬度函數
def fuzzy_LR_type_trapezoid_shape(a,b,a1,b1,u_set):
    a1_zero_x = []
    b1_zero_x = []
    a12a_x = []
    a12a_attr = []
    b2b1_x = []
    b2b1_attr = []
    one_x = []
    for x in u_set:
        func_a12a = (x-a1) / (a-a1)
        func_b2b1 = (b1-x) / (b1-b)
        if a1 <= x < a and 0 < func_a12a < 1:
            a12a_attr.append(func_a12a)
            a12a_x.append(x)
        elif b < x <= b1 and 0 < func_b2b1 < 1:
            b2b1_attr.append(func_b2b1)
            b2b1_x.append(x)
        #已假定以下兩者的歸屬度為0
        elif x < a1:
            a1_zero_x.append(x)
        elif x > b1:
            b1_zero_x.append(x)
        #以假定以下的歸屬度為1
        elif a <= x <= b:
            one_x.append(x)
    a12a_dict = dict(zip((a12a_x),(a12a_attr)))
    b2b1_dict = dict(zip((b2b1_x),(b2b1_attr)))
    return a1_zero_x, a12a_dict, one_x, b2b1_dict, b1_zero_x

#三角形歸屬度函數
def fuzzy_LR_type_triangular_shape(a,b,a1,b1,u_set):
    a1_zero_x = []
    b1_zero_x = []
    a12a_x = []
    a12a_attr = []
    a2b1_x = []
    a2b1_attr = []
    one_x = []
    for x in u_set:
        func_a12a = (x-a1) / (a-a1)
        func_a2b1 = (b1-x) / (b1-b)
        if a1 <= x < a and 0 < func_a12a < 1:
            a12a_attr.append(func_a12a)
            a12a_x.append(x)
        elif a < x <= b1 and 0 < func_a2b1 < 1:
            a2b1_attr.append(func_a2b1)
            a2b1_x.append(x)
        #已假定以下兩者的歸屬度為0
        elif x < a1:
            a1_zero_x.append(x)
        elif x > b1:
            b1_zero_x.append(x)
        #已假定以下的歸屬度為1
        elif x == a:
            one_x.append(x)
    a12a_dict = dict(zip((a12a_x),(a12a_attr)))
    a2b1_dict = dict(zip((a2b1_x),(a2b1_attr)))
    return a1_zero_x, a12a_dict, one_x, a2b1_dict, b1_zero_x




#1.模糊數為正定，um(x)=0，所有x <0
#2.模糊數為負定，um(x)=0，所有x >0










"""
給定偏序集合(T,≤)，對於S⊆T，S的上確界sup(S)定義為S的所有上界組成的集合的最小元（若有）。即sup(S)滿足：

∀s∈S ⇒ s≤sup(S)
∀t∈T，若t滿足∀s∈S ⇒ s≤t，則有sup(S)≤t。
sup(S)∈T。
上確界也被稱為最小上界、lub 或 LUB，在格論中也被稱為並，在序理論中S的上確界也被記為\veeS。

若S包含最大元素，則該元素就是上確界。
若S有上確界，則上確界是唯一的。
上確界的對偶概念最大下界叫做下確界或交。
偏序集合的子集可能沒有上確界，即使它有上界。
上確界一定不能混淆於極小，上界，極大元或最大元。


在數學分析中，實數的集合S的上確界或最小上界記為 sup(S)，並被定義為大於或等於 S 中所有成員的最小實數。
實數的一個重要性質是它的完備性：實數集合的所有非空子集是有上界的就是這個實數集合成員的上確界。
簡單講: sup{1,2,3} = 3
"""








