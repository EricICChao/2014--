__author__ = 'Eric'

"""
模糊集合基本: A = {(x, ua(x)) | x屬於U }

x = 元素
ua(x) = 歸屬度函數，歸屬度介於0~1，ua(x)要寫成一組數學公式。
定義: 當x在U的範圍內，會對應到一個介於0~1的數值ua(x)

U = 論域(明確集合)
把考慮的對象限制在一定範圍內，此範圍就稱為論域或全集合(Universal of discourse)，論域中每個概念就稱為論域上的集合。
例如討論"偶數"這個概念，就可以拿所有的自然數為論域，所以論域U就可以寫成：U={自然數論域}={1,2,3,4…..}

所有的這種x所集成的集合就是一fuzzy set
=================================================
關鍵字彙:
支集(Support): 在U當中，對應模糊集合A的ua(x)不為0的所有x之集合，Supp(A) = {x屬於U | ua(x) > 0}

模糊單子(fuzzy singleton): { 唯一一個讓ua(x) = 1的x，x屬於U}
交越點(crossover point): {讓ua(x) = 0.5的x， x屬於U}

核(kernel): 所有可以讓ua(x) = 1的x的集合， Ker(A) = {x | ua(x) = 1}
高度(height): 在集合內ua(x)最高的值(最大值)，Height(A) = sup-ua(x)
if Height(A) = 1:
    A已經正規化(normalized)
else:
    次正規化(subnormal)

截集(a-cut): 所有讓ua(x) >= alpha 的x的集合， Aa = {x屬於U，ua(x) >= a，a屬於(0,1]  }
嚴格截集(Strong a-cut): 所有讓ua(x) > alpha 的x的集合， SAa = {x屬於U，ua(x) > a，a屬於(0,1]  }
==============================================================================
"""


#參考檔案 "迭代test.py" 的結果
#參考檔案 "迭代test_的測試結果"
#參考檔案: 用zip整理dict_list_set_tuple結構.py
#參考檔案: 迭代的製作法, 群集資料相關, 數值型態簡介
#參考: 深入淺出 python pp. 155-156
#參考檔案: 用zip整理dict_list_set_tuple結構.py

"""
#函式命名規則:   5s1i1c = 五次方程式，其中一次方項目有一個，常數項有一個

#建造一組key, 就是U裡面的x
#可設定或不設定attr: 歸屬鍍函數的值
#u_set是要丟進去算的值
#fuzzy_attr是要取出歸屬度函數的值，fuzzy_u是對應值的U裡面的元素
"""

#取得所有非指定的歸屬度函數值和所屬的U的元素
def fuzzy_not_5s1i1c(attr,a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans != attr:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans != attr:
            fuzzy_attr.append(func_ans)
    return print(fuzzy_u), print(fuzzy_attr)

#取得指定的歸屬度函數值和所屬的U的元素(單一)(找尋模糊單子與交越點專用)
def fuzzy_one_5s1i1c(attr,a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans == attr:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans == attr:
            fuzzy_attr.append(func_ans)
    return print(fuzzy_u), print(fuzzy_attr)

#取得所有歸屬度函數值和所屬的U的元素
def fuzzy_all_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_attr.append(func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    return xx


#取得所有不在歸屬度範圍內的值和所屬的U的元素
def fuzzy_not_all_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans <= 0 or func_ans >= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if func_ans <= 0 or func_ans >= 1:
            fuzzy_attr.append(func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    return xx

#支集(Support)
def fuzzy_supp_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 < func_ans <= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 < func_ans <= 1:
            fuzzy_attr.append(func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    return xx

#核(kernel): 所有可以讓ua(x) = 1的x的集合， Ker(A) = {x | ua(x) = 1}
def fuzzy_ker(one_set): #請將所有符合條件的集合先擺入一個set裡，本函式還未測試
    uu = [one_set]
    return uu

#高度(height)
def fuzzy_sup_height_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_attr.append(func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    max_xx = max(zip(xx.values(), xx.keys()))
    if max_xx == 1:
        print(u_set)
        print(xx)
        print("已正規化")
    else:
        print(u_set)
        print(xx)
        print("次正規化")


#截集(alpha-cut)
def fuzzy_alpha_cut_5s1i1c(alpha,a,b,c,d,e,con, u_set):
    alpha_u = []
    if 0 < alpha <= 1:
        for x in u_set:
            func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
            if 0 <= func_ans <= 1:
                if func_ans >= alpha:
                    alpha_u.append(x)
    return alpha_u


#嚴格截集(Strong a-cut)
def fuzzy_strong_alpha_cut_5s1i1c(alpha,a,b,c,d,e,con, u_set):
    alpha_u = []
    if 0 < alpha <= 1:
        for x in u_set:
            func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
            if 0 <= func_ans <= 1:
                if func_ans > alpha:
                    alpha_u.append(x)
    return alpha_u

#檢查有哪些論域和歸屬度
def fuzzy_check_all_5s1i1c(a,b,c,d,e,con, u_set):
    fuzzy_u = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_u.append(x)
    #取得所有歸屬度的值
    fuzzy_attr = []
    for x in u_set:
        func_ans = a*pow(x,5)+b*pow(x,4)+c*pow(x,3)+d*pow(x,2)+e*pow(x,1)+con
        if 0 <= func_ans <= 1:
            fuzzy_attr.append(func_ans)
    xx = dict(zip((fuzzy_u),(fuzzy_attr)))
    return print(xx)

#其他版本: 5i1c
