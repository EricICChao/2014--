__author__ = 'Eric'


import fuzzy_dict
import FuzzyOperations
a = {1, 2, 3, 80}
b = {10, 3, 50}
c = {1,2,3,4,5,6,7,8,9,10,80,90}
d = list(range(3,100))
f = set(range(3,100))


print("================follow is g===============================")
e = FuzzyOperations.fuzzy_LR_type_triangular_shape(20,80,3,100,d)
print(e)


for x in a:
    arr = []
    func = x*2
    arr.append(func)
    print(arr)
