__author__ = 'Eric'


#靜態分析，也稱為均衡分析: 一組經過選擇的相關變數，經過調整，其所構成的內部無發生變化的傾項。

"""
孤立市場均衡模型: 市場局部均衡模型
僅考慮單一商品

變數:
商品需求量(Qd)
商品供給量(Qs)
價格(p)
"""

#部分市場均衡，線性，未完
#請記得給定一組價格，和供需方的行為參數(Qs(x)和Qd(x))
def partial_market_equilibrium_liner(a,b,c,d,p_set):
    qd_y = []
    qd_p = []
    qs_y = []
    qs_p = []
    eq = []
    ep = []
    if a>0 and b>0:
        for p in p_set:
            Qd = a - b*p
            qd_y.append(Qd)
            qd_p.append(p)
    if c>0 and d>0:
        for p in p_set:
            Qs = -c + d*p
            qs_y.append(Qs)
            qs_p.append(p)
    d = dict(zip((qd_p),(qd_y)))
    s = dict(zip((qs_p),(qs_y)))
    print(d)
    print(s)
    for p in p_set:
        Qd = a - b*p
        Qs = -c + d*p    #轉乘float
        if Qs == Qd:
            eq.append(Qs)
            ep.append(p)
        print("均衡數量為: ")
        print(eq)
        print("均衡價格為: ")
        print(ep)