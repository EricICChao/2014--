

import EquilibriumAnalysis


a = set(range(0,50))

b = EquilibriumAnalysis.partial_market_equilibrium_liner(200,35,47,12,a)

