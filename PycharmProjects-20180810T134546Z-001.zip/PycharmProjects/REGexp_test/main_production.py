__author__ = 'Eric'

import re
import regex

a = "ER12332eq"
b = re.search("^[a-z]$", "a")
print(b)















