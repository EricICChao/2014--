__author__ = 'Eric'

import pickle



"""
本模組提供可將資料轉換成可供網頁使用的資料的工具
"""

#取得檔案
def get_data_by_path():
    file_path = input("輸入檔案路徑:  ")
    return file_path




