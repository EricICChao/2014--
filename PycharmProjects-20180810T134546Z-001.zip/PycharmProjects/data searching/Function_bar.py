__author__ = 'Eric'

import os, re, sys
#=======================================================================================================================
#檢索檔案目錄功能

#檢索指定資料夾內的所有內容
def open_Folder():
    #指定查詢資特定料夾內目錄列表
    print("""
        請先檢查要查詢的資料的檔案夾內目錄列表\n
        指定查詢特定資料夾內目錄列表的路徑表示方法:\n
        C://Users//Eric//Desktop//information literacy相關\n
        請輸入指定查詢的資料夾路徑，輸入範例如上:
        """)
    folder_path = input()
    file_names_list = os.listdir(folder_path)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for x in file_names_list:
        print(x)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")

#檢索已設資料夾情境下的資料夾內所有內容
def open_default_Folder():
    file_names_list = os.listdir("C://Users//Eric//PycharmProjects//data searching//save_space")
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for x in file_names_list:
        print(x)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
#=======================================================================================================================
#檔案內容開啟功能

#開啟選定的檔案，未設定路徑
#檔案選定要寫路徑，路徑的寫法:   C://Users//Eric//PycharmProjects//data searching//save_space//1.txt
def open_file_all_by_yourself():
    a = input("請輸入開啟檔案的編碼方法(ex: utf8, us-ascii等等): ")
    b = input("請輸入檔案路徑(ex: 路徑的寫法:   C://Users//Eric//PycharmProjects//data searching//save_space//1.txt): ")
    with open(b , encoding= a) as f2:
        data2 = f2.read()
        print(data2)

#開啟選定的檔案，已預設路徑C://Users//Eric//PycharmProjects//data searching//save_space//，只需填檔案名稱和檔案格式就行
def open_file_name_and_form():
    a = input("請輸入開啟檔案的編碼方法(ex: utf8, us-ascii等等): ")
    b = input ("請輸入檔案名稱和格式: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+b, encoding= a) as f2:
        data2 = f2.read()
        print(data2)
#=======================================================================================================================
#資料輸入檔案功能

#新增文字檔案與寫入資料(但不要覆蓋原資料，所以必須把文字附加到現有檔案的結尾，使用 "at"模式)
"""
要注意: 要新增文字到舊的檔案 "with open(.......) as f :"   的 f 必須和新開檔案一樣使用 f，也就是一律 f 到底，才表示再同一檔案，
不要用f2,f3,..........之類的
"""
def new_file():
    a = input("請輸入新增檔案名稱和格式: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+a, 'xt', encoding= "utf8", newline = '') as f:
        text_data = input("請輸入資料: ")
        f.write(text_data)

def add_text_data():
    b = input("請輸入要新增文字資料的檔案名稱和格式: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+b, 'at', encoding= "utf8", newline = '') as f:
        input_new_data = input("請輸入要新增的資料: ")
        f.write(input_new_data)

#資料連續輸入，並匯出到新的檔案中
def text_data_input_in_new_file():
    data_set = []
    i = 1
    a = input("請設定要輸入的資料項有幾項: ")
    while i < int(a):
        text_data = input("請輸入資料: ")
        data_set.append(text_data)
        next_step = input("接下來要繼續的動作為: (1)輸入下一筆資料 ；(2)繼續修改原本資料； (3)結束應用程式")
        if next_step is '1':
            i += 1
            b = str(i)
            text_data_next = input("請輸入第"+ b + "筆資料: ")
            data_set.append(text_data_next)
        elif next_step is '2':
            continue
        elif next_step is '3':
            sys.exit()
    new_file_name = input("請輸入檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'xt', encoding= "utf8", newline = '') as f:
        for x in data_set:
        #將資料從set中一筆一筆寫入檔案裡
            with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'at', encoding= "utf8", newline = '') as f:
                f.write(x)
#=======================================================================================================================
#符合條件之檔案一次讀取功能

def reading_search_data():
    key_word = input("請輸入要查詢的關鍵字:")
    #指定查詢資特定料夾內目錄list
    folder_path = input("指定要搜尋的資料夾位址，目錄的路徑表示方法:  C://Users//Eric//Desktop//information literacy相關//，請輸入:")
    file_names_list = os.listdir(folder_path)
    new_file_name = input("請輸入要儲存搜尋到的資料檔案的檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space///"+new_file_name, 'xt', encoding= "utf8") as f:
        for x in file_names_list:
            #with open("C://Users//Eric//PycharmProjects//test_text//"+x, encoding= "utf8") as f2:
            with open(folder_path + x,'rt', encoding="utf8") as f2:
                text_data = f2.read()
                #比對英文
                search_english_key_word = re.search(r"\b + key_word + \b", text_data)
                #比對中文.
                search_chinese_key_word = re.search(r"(?u)\b + key_word + \b", text_data)
                if search_english_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)
                elif search_chinese_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)

#符合多個關鍵字的資料

#多個關鍵字的資料，且能分開顯示

