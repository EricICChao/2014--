__author__ = 'Eric'


import os
#連接可以下載到單機上的google雲端硬碟或是MS的Onedrive的資料夾路徑
file_names_list = os.listdir("C://Users//Eric//Google 雲端硬碟")
for x in file_names_list:
    print(x)





