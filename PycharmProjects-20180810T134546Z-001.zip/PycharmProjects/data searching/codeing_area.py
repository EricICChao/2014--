__author__ = 'Eric'


開啟一個檔案區供做程式碼編輯，只是這個檔案的格式是.py，或者是開啟應用程式IDLE
然後直接提供input輸入程式碼，或是開一張UI的文字輸入欄供輸入

a = input("請輸入檔案名稱和格式: ")
with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+a, encoding= "utf8") as f: