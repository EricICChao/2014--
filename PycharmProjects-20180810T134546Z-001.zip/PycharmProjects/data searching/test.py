__author__ = 'Eric'

"""
文件檔搜尋程序:
1.檔案存放空間的路徑操作
         1-1. 取得存放空間的檔案目錄列表
2.搜尋適合的檔案
         2-1. 檢視檔案列表中檔案標題符合的關鍵字
                2-1-1.符合者存放至一set中
         2-2. 尋找檔案內容中有符合關鍵字的檔案
                2-2-1.符合者存放至一set中
3.決定檔案選取策略
         3-1.符合關鍵字的檔案標題的檔案就選取
                3-1-1.符合者存放至一set中
         3-2.符合關鍵字的檔案內容就選取
                3-2-1.符合者存放至一set中
         3-3.符合關鍵字的檔案標題及內容才可選取
                3-3-1.符合者存放至一set中
4.調出所選取的檔案內容
"""
import Function_bar, sys
print("VERSION_1.0\n")
print("歡迎使用程式設計大師中的大師中的大師中的大師中的大師中的大師中的大師中的大師中的大師中----趙翊清設計的資料檢索系統\n")
print("""設計本系統的目的如下:\n
1.程式設計功夫的練習\n
2.設計一個微型的文件資料庫，但是不必用SQL語法，只要繼續搭配本PyCharm就可以變身成像MSSQL server一樣的資料庫系統\n
3.而且內容可以用python設計，靈活性和熟悉度更高，不必特地再學SQL語言\n
4.把平常熟悉和常用的的資料操作作業流程都SOP化(只要多寫幾個模組)，不用每次開啟都要量身訂做\n
5.因為外界的資料庫或系統都太過複雜且用的邏輯和語言我實在看不懂，我只是要一個熟悉和會用的資料檢索系統，所以我怒寫一個\n
以後有想到新功能會再慢慢加入，看最後會不會變成一個大的資料庫系統XD\n
""")

print("""
指定檔案路徑的方法:
C://Users//Eric//PycharmProjects//data searching//save_space//
請記得用 "// " 而不是 " \ "

指定查詢特定資料夾內目錄列表的路徑表示方法:
C://Users//Eric//Desktop//information literacy相關

雖然可以指定操作查詢特定資料夾，不過還是建議放在本專案建立的 "save_space資料夾下"
目前先將欲分析選取的檔案轉成.txt檔案，待日後可讀取.pdf時，再使用.pdf檔
輸入檔案時請記得連檔案格式都輸入，例如: eric.txt
大推用MS-WORD轉換成.txt純文字格式，因為可以讓你選擇轉碼格式(我直接把他轉成utf8)

encoding 請盡量指定 "utf8"比較不容易錯，除非你是用英文的可以指定 "us-ascii"
 """)
print("=================================================================================================")
print("                             從以下開始                                   ")
print("=================================================================================================")
work_item = input("您想執行何種工作: (1)輸入資料；(2)查看預設文字資料庫內的檔案； (3)查看指定資料夾內的檔案；(4)檢視檔案內容 (5)查詢所有符合關鍵字的文字資料檔案內容 (6)結束應用程式")
if work_item is '1':
    input_item = input("您要輸入的模式為何: (1)輸入到新檔案；(2)在原有檔案輸入新內容")
    if input_item is '1':
        Function_bar.text_data_input_in_new_file()
    elif input_item is '2':
        Function_bar.add_text_data()
elif work_item is '2':
    Function_bar.open_default_Folder()
elif work_item is '3':
    Function_bar.open_Folder()
elif work_item is '4':
    input_item = input("您要檢視的檔案為: (1)預設資料夾的檔案；(2)指定的檔案")
    if input_item is '1':
        Function_bar.open_file_name_and_form()
    elif input_item is '2':
        Function_bar.open_file_all_by_yourself()
elif work_item is '5':
    Function_bar.reading_search_data()
elif work_item is '6':
    sys.exit()
