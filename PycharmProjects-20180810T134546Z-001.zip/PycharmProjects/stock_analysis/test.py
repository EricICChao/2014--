__author__ = 'Eric'



import webbrowser
import regex
from bs4 import BeautifulSoup
import urllib.request




url = 'http://mops.twse.com.tw/t21/sii/t21sc03_102_1_0.html'
response = urllib.request.urlopen(url)
html = response.read()
sp = BeautifulSoup(html.decode('cp950'))
sp
c = webbrowser.open('http://mops.twse.com.tw/mops/web/index')



