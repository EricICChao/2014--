__author__ = 'Eric'



YesNo_no = ("n", "N")

#基本資料輸入的check
def CheckBar(a, b):
    print("確定輸入完成了嗎? Y/N")
    check_first = input()
    while check_first in YesNo_no :
        print(a)
        b = input()
        print("確定輸入完成了嗎? Y/N")
        check_first = input()
    return a, b


#問答題的check
def TextCheckBar(q, ans):
    print("確定輸入完成了嗎? Y/N")
    check_second = input()
    while check_second in YesNo_no :
        print(q)
        ans = input()
        print("確定輸入完成了嗎? Y/N")
        check_second = input()
    return q, ans