__author__ = 'Eric'


import Function_Bar
import textwrap
import word_analyze
import os

#==========姓名區===================
print("姓名:")
name = input()
Function_Bar.CheckBar('姓名', name)

#問題: 中文輸入時不會及時顯示你輸入了哪些字。
#=============學號區================
print("學號:")
ID_Number = input()
Function_Bar.CheckBar('學號', ID_Number)
#===============Q1==============
print("Q1: 你覺得這個系統有什麼優缺點?")
print("Ans:")
a = input()
Function_Bar.TextCheckBar('Q1: 你覺得這個系統有什麼優缺點?', a)
textwrap.wrap(a, 50)
#===============Q2==============
print("Q2: 你對於用這個系統對來做防災教育有什麼建議?")
print("Ans:")
b = input()
Function_Bar.TextCheckBar('Q2: 你對於用這個系統對來做防災教育有什麼建議?', b)
textwrap.wrap(b, 50)
#===============Q3==============
print("Q3: 你對於系統中所提供的歷史災情有什麼感覺?")
print("Ans:")
c = input()
Function_Bar.TextCheckBar('Q3: 你對於系統中所提供的歷史災情有什麼感覺?', c)
textwrap.wrap(c, 50)
#==========答案內容區塊===================
print('                 答案                    ')
print('*************************')
print('姓名' + name)
print('學號' + ID_Number)
print('=========================')
print('Q1的Ans:')
print(textwrap.fill(a, 50))
print('=========================')
print('Q2的Ans:')
print(textwrap.fill(b, 50))
print('=========================')
print('Q3的Ans:')
print(textwrap.fill(c, 50))
print('*************************')
#============統計關鍵字出現次數=================
print(word_analyze.check_key_word_uc_set("\"避難\"",r"[\u907f][\u96e3]","避難",c))
#輸入unicode，uc輸入格式r"[uc1][uc2][uc3][uc4]........."
#d = word_analyze.check_key_word_uc_set("\"避難\"",r"[\u907f][\u96e3]","避難",c)
#print(d)
#============找出具有防災意識的人=======


#============分析關鍵字來發現使用者的變化=================


#=================答案和分析結果輸出======================
#輸出成一份.txt或是.csv，需要用到剖析將印出的結果轉成文字格式
with open(ID_Number, 'xt', encoding = "utf8") as f:
    print('姓名' + name, file = f)
    print('學號' + ID_Number, file = f)
    print('                 答案                    \n', file = f)
    print('==========================\n', file = f)
    print('Q1的Ans:\n',file = f )
    print(textwrap.fill(a, 50), file = f)
    print('Q2的Ans:\n', file = f)
    print(textwrap.fill(b, 50), file = f)
    print('Q3的Ans\n:', file = f)
    print(textwrap.fill(c, 50), file = f)
    print('==========================\n', file = f)
    print('出現的關鍵字與次數\n', file = f)
    print(word_analyze.check_key_word_uc_set("\"避難\"",r"[\u907f][\u96e3]","避難",c), file = f)