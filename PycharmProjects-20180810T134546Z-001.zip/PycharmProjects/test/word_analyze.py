__author__ = 'Eric'

import re

"""
#文字區塊搜尋
#比對關鍵字並記錄次數
#顯示紀錄次數
"""


#unicode: \uxxxx

#key_word_str的格式\"key_word\"
#輸入unicode，uc輸入格式r"[uc1][uc2][uc3][uc4]........."
def check_key_word_uc_set(key_word_str,uc,key_word,ans):
    c = print(key_word_str+"出現的次數:" )
    b = ans.count(key_word)
    a = re.findall(uc, ans)
    return a,b

#key_word_str的格式\"key_word\"
#輸入中文，word輸入格式r"[word1][word2][word3]........."
def check_key_word_word_set(key_word_str,word,key_word, ans):
    c = print(key_word_str+"出現的次數:")
    b = ans.count(key_word)
    a = re.findall(word, ans)
    return a,b
#key_word_str的格式\"key_word\"

#def key_word_result(key_word_str,key_word,uc,ans):
#    print(key_word_str+"出現的次數:")
#    print(ans.count(key_word))
#    print(re.findall(uc,ans))
#    print(ans.count(uc))



"""
一組參考範例:
請參考檔案: D:\個人學習\python\規則運算式---模組介紹
裡面的re.findall()的第二組範例

print(re.findall(r"[\u907f][\u96e3]", "避難、去避難囉、安安我避難了避難了避難了避難了難避難了"))
print(re.findall(r"\b[\u907f][\u96e3]\b", "避難、去避難囉、安安我避難了避難了避難了避難了難避難了"))

a = re.findall(r"[\u907f][\u96e3]", "避難、去避難囉、安安我避難了避難了避難了避難了難避難了")
print(a.count("避難"))


result::
['避難', '避難', '避難', '避難', '避難', '避難', '避難']
['避難']
7

--------------參考以下函數----------------
re.search()
re.findall()
re.match()
re.finditer()
re.compile()
"""

#列出關鍵字所在的整段句子