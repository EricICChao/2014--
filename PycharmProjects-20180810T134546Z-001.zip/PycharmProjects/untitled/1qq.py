from collections import OrderedDict
price_1 = 10
price_2 = 11
price_3 = 12
price_4 = 11
price_5 = 9

set_price = [price_1,price_2,price_3,price_4,price_5]

brand_value_1 = 200
brand_value_2 = 310
brand_value_3 = 240
brand_value_4 = 157
brand_value_5 = 300

set_brand_value = [brand_value_1,brand_value_2,brand_value_3,brand_value_4,brand_value_5]

ID_1 = "a"
ID_2 = "b"
ID_3 = "c"
ID_4 = "d"
ID_5 = "e"

set_ID = [ID_1,ID_2,ID_3,ID_4,ID_5]


test_key_value = dict(zip((set_price),(set_brand_value)))
ID_price = dict(zip((set_ID),(set_price)))
ID_brand_value = dict(zip((set_ID),(set_brand_value)))


print(ID_price)
print(ID_brand_value)

