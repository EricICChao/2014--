__author__ = 'Eric'




class input_data:
    def __init__(self, who_are_you):
        self.who_are_you = who_are_you
    def input_data(self, b):
        text_data = input("請輸入資料: ")
        b = int(text_data)
        return b

class input_data2:
    def __init__(self):
        self
    def input_data(self):
        text_data = input("請輸入資料: ")
        b = int(text_data)
        return b


class input_data3:
    def __init__(self):
        self
    def input_data(self, test_number_get):
        text_data = input("請輸入資料: ")
        b = int(text_data) + test_number_get
        return b