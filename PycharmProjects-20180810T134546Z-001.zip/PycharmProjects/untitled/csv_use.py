__author__ = 'Eric'


import csv, collections, re
from collections import namedtuple


"""
此處有兩種技術: regex(較難), dictionary的get方法(較易)
"""
regex_pattern1 =r"^' ,$"
regex_pattern1_1 = r"^' '$ "
regex_pattern2 = '人口'
regex_pattern3 = '人口'


regex_pattern1_2 =r"^\'(.*)\'$"
#Python錦囊妙計  第三版 p.53

"""
with open('C://Users//Eric//Desktop//test.csv') as f:
    f_1 = csv.reader(f)
    heading = next(f_1)
    Row_1 = namedtuple('DATA', heading)
    for x in f_1:
        x2 = Row_1(*x)
        print(x2)
print("======================================")
"""

with open('C://Users//Eric//Desktop//test.csv') as f2:
    f_2 = csv.DictReader(f2)
    for y in f_2:
        print(y)
        e = y.get('人口')
        print(e)
        f = float(e)
        ee = f +1000
        print(ee)
#精通Python3程式設計 第二版 p.129

print("======================================")
with open('C://Users//Eric//Desktop//test.csv') as f3:
    f_3 = csv.DictReader(f3)
    for z in f_3:

        z_s = str(z)
        a = re.split(regex_pattern1,z_s)
        print(a)





        b = re.search(regex_pattern2, z_s)
        print(b)
        c = b.start()
        print(c)
        d = b.end()
        print(d)






#處理大數據的必備美工刀  全支援中文的正規表示法精解 p.14-14

"""
要先把字典格式存進字串之中，
先切割各組變數(regex_pattern1)，
比對我要的變數組(regex_pattern2)，
再切出我要的變數組(regex_pattern3)，再切切出我要的數字(文字格式)(regex_pattern4)，
再轉成數字格式
"""

print("======================================")
"""
with open('C://Users//Eric//Desktop//test.csv') as f3:
    f_3 = csv.DictReader(f3)
    #我要怎麼讓DictReader出來的東西變成真正的dictionary???
    a = csv.register_dialect('CPI')
    print(f_3.get(a))

"""






