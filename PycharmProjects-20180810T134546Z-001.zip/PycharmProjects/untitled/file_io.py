__author__ = 'Eric'

import io,os, PDF


f = open("PIC000026.jpg", "rb", buffering = 0)
print(f)
input("請entry: ")
f.close


