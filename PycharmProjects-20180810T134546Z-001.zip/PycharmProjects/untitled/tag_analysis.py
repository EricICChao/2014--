__author__ = 'Eric'


import urllib.request, re



#web_site = urllib.urlopen('http://www.twse.com.tw/ch/index.php')
web_site = urllib.request.urlopen('http://www.twse.com.tw/ch/index.php')

#目前urlopen出來的東西是bytes的資料型態

html_source = web_site.read()
#html_source = web_site.getcode()
web_site.close()
pattern = r"<[^/>][^>]*[^/>]>"
re.findall(pattern,html_source)

"""
new_file_name = input("請輸入要儲存搜尋到的資料檔案的檔案格式與名稱: ")
with open("C://Users//Eric//PycharmProjects//untitled//test_text//"+new_file_name, 'xt', encoding= "utf8") as f:
    for x in file_names_list:
"""







