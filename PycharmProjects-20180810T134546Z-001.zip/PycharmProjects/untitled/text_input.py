__author__ = 'Eric'

#新增文字檔案與寫入資料(但不要覆蓋原資料，所以必須把文字附加到現有檔案的結尾，使用 "at"模式)
"""
要注意: 要新增文字到舊的檔案 "with open(.......) as f :"   的 f 必須和新開檔案一樣使用 f，也就是一律 f 到底，才表示再同一檔案，
不要用f2,f3,..........之類的
"""

#研究如何分行



a = input("請輸入新增檔案名稱和格式: ")
with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+a, 'xt', encoding= "utf8", newline = '') as f:
    text_data = input("請輸入資料: ")
    f.write(text_data)

b = input("請輸入要新增文字資料的檔案名稱和格式: ")
with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+b, 'at', encoding= "utf8", newline = '') as f:
    input_new_data = input("請輸入要新增的資料: ")
    f.write(input_new_data)




