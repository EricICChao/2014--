import heapq

#取出list中前N個最大和最小的項目，並對其作加減運算。


a = [1,2,3,4,5,6,7,8,9,0,10]
b = heapq.nlargest(1,a)   #取出a中前N個最大的項目
c = heapq.nsmallest(1,a)  #取出a中前N個最小的項目
d = b[0]-c[0]             #跟對list b 和 list c中的第0個元素進行加減運算。

print(b)
print(c)      
print(d)

#以下為結果
"""
>>> 
[10]
[0]
>>> ================================ RESTART ================================
>>> 
Traceback (most recent call last):
  File "C:/Users/Eric/Desktop/1.py", line 7, in <module>
    d = b-c
TypeError: unsupported operand type(s) for -: 'list' and 'list'
>>> ================================ RESTART ================================
>>> 
[10]
[0]
10
>>> 
"""
