__author__ = 'Eric'

import datetime, re

"""
時間每一回合，以月份做為單位

"""
a = datetime.time()   #取得完全獨立的新時間，和現實世界的時間隔離，從00:00:00開始
print(a)
date_time = datetime.date(2014,9,1)          #datetime.date(year, month, day)指定想要的年月日
print(date_time)
every_times_add_time = datetime.timedelta(days = 30)                        #每一回合要加上的時間,  datetime.timedelta()只能處理到  'day' 的時間單位
c = date_time + every_times_add_time
print(c)


def time_count():
    month_catch = r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"      #命名分組捕捉
    i = 1
    run_times = input("請設定要玩幾回合(1回合代表1個月): ")
    while i < int(run_times):
        i += 1
        time_times = i*every_times_add_time
        now_time = date_time + time_times
        now_time_string = str(now_time)       #str()將資料轉成字串物件
        print(now_time)
        month_now = re.search(month_catch, now_time_string).group(2)
        print("目前月份是" +month_now+ "月")
    time_up_date = int(run_times)*every_times_add_time+date_time
    print("結束日期是:")
    print(time_up_date)




month_catch = r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"      #命名分組捕捉
i = 1
run_times = input("請設定要玩幾回合(1回合代表1個月): ")
while i < int(run_times):
    i += 1
    time_times = i*every_times_add_time
    now_time = str(date_time + time_times)   #str()直接將計算結果轉成字串物件
    #now_time_string = str(now_time)       str()將資料轉成字串物件
print(now_time)
month_now = re.search(month_catch, now_time).group(2)
print("目前月份是" +month_now+ "月")
time_up_date = int(run_times)*every_times_add_time+date_time
print("結束日期是:")
print(time_up_date)


