__author__ = 'Eric'

import any_test_class

i = 1
j = 1
test_number = 0.07
#=======================================================================================================================
a = input("請設定要輸入的資料項有幾項: ")
#=======================================================================================================================
"""
while i < int(a):
    text_data = input("請輸入資料: ")
    b = int(text_data)
    j += b
    i += 1
    c = "目前的 j 為:"
    print(c)
    print(j)

print(j)
"""

"""
while i < int(a):
    who_am_i = any_test_class.input_data("12")
    b = 0
    input_any_data = any_test_class.input_data.input_data(who_am_i, b)
    j += input_any_data
    i += 1
    c = "目前的 j 為:"
    print(c)
    print(j)

print(j)
"""

"""
while i < int(a):
    who_am_i = any_test_class.input_data2()
    data_input =any_test_class.input_data2.input_data(who_am_i)
    j += data_input
    i += 1
    c = "目前的 j 為:"
    print(c)
    print(j)

print(j)
"""

while i < int(a):
    who_am_i = any_test_class.input_data3()
    data_input =any_test_class.input_data3.input_data(who_am_i, j)
    j += data_input
    i += 1
    c = "目前的 j 為:"
    print(c)
    print(j)

print(j)