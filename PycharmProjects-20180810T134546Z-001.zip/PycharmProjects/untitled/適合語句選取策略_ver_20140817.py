__author__ = 'Eric'
coding = "utf8" or "US-ASCII"

#適合語句選取策略

"""步驟
1.設立切段準則分割句子
    確立切段點(如何判斷出一小結段落進行分割)
    分割的句子擺入set1
2.比對適合句子
    輸入關鍵字， 比對關鍵字自各分割過的句子
3.句子中符合關鍵字者，句子顯示
    欲比對與顯示的句子形式:     re"^[開頭條件]......[關鍵字].......[結尾條件]$"
    符合者存入set2

可參考文件: D:\個人學習\python\多行文字搜尋比對
"""

import re
print("""
運作流程:
    一組文字檔案
    將文字檔案切段擺入set1中:
        切段準則: 開頭是空行或是空白鍵；結尾是.或是。
    將各段抽出比對關鍵字:
        關鍵字比對原則: 使用分組/捕捉  和  斷言/單字邊界
    如果符合的關鍵字的切段，存入另一set2中
""")
#文字檔案切段模式:
data_split_pattern = r"(?m)^\n"
#切段後存放地點:
set1 = []
"""
(?m): 顯示為多行模式，再進行pattern設定(因為字串是多行組成)。
目前  r"(?m)^\n" 這一組模式會判定跳空行，在set裡的顯示為' ',
如果是一組段落，裡面也有個別的換行，只是沒有空行，在set裡的顯示為' 第一行\n 空白間隔\n 第二行\n',

也就是這一組的切割以空行為判斷，但我是設定為\n而非\s，可能是python的\s在ASCII等效於\n，同時又是空白符號的判斷所制，
所以換行是以整行空白為判斷基準，在字串切割函式re.split()。
"""

#關鍵字比對模式
match_pattern = r"([情境] | [情境學習])"
#比對關鍵字後存放地點
set2 = []
"""
斷言/單字邊界的變數 = 模式
"""




#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
with open("C://Users//Eric//PycharmProjects//untitled//可用情境學習文獻節錄.txt", 'rt', encoding="utf8") as f:
    data = f.read()

print("切割句子=============切割句子=================切割句子")
for y in re.split(data_split_pattern, data):
    set1.append(y)
#print(set1)
print("切割完成=============切割完成=================切割完成")

print("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
print("比對關鍵字==========比對關鍵字============== 比對關鍵字")
for x in set1:
    y = re.search(match_pattern, x)
    if y is '情境' or '情境學習':
        set2.append(x)
print(set2)
print("比對完成=============比對完成=================比對完成")


#以下程式碼參考，讓set的print可以變成直的
"""
def open_Folder():
    folder_path = input()
    file_names_list = os.listdir(folder_path)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
    for x in file_names_list:
        print(x)
    print("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
"""




























"""原始版本
line_set = []
data_regex = r"(?m)^\d.*"
print("1111111===========1=================11111111")
for x in re.split(data_regex, data):
    line_set.append(x)
    print(line_set)

match_sentence =[]
match_sentence_regex = r"(?m)^\b[\u60c5\u5883\u5b78\u7fd2]"
print("============================")
for x in line_set:
    for match_sentence in re.finditer(match_sentence_regex, x):
        print(match_sentence)
"""