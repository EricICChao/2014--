__author__ = 'Eric'

import urllib.request
YesNo_no = ("n", "N")

#要check的點或項目
def CheckBar(a, b):
    print("確定輸入完成了嗎? Y/N")
    check_first = input()
    while check_first in YesNo_no :
        print(a)
        b = input()
        print("確定輸入完成了嗎? Y/N")
        check_first = input()
    return a, b



#網頁抓取並輸出成文字檔
def web_page_grab():
    a = input("請輸入網址: ")
    CheckBar("網址", a)
    b = input("原始網頁碼的檔案儲存命名: ")
    CheckBar("原始網頁碼的檔案儲存命名", b)
    web = urllib.request.urlopen(a)
    content = web.read()
    with open(b, 'xt', encoding = "utf8") as f:
        print(content, file = f)
    return content


#外部檔案讀取
#專門讀寫或開啟文字檔案
def open_txt_file(file, encoding):
    with open(file,'rt',encoding=encoding) as f:
        data = f.read()
        print(data)
    return data
"""範例
with open('eric.txt','rt',encoding="utf8") as f:
    data = f.read()
    print(data)
"""
#專門讀寫或開啟非文字和2進位檔的檔案
def open_other_file(file,encoding):
    with open(file, encoding=encoding) as f2:
        data2 = f2.read()
        print(data2)
    return data2
"""範例
with open('eric.htm', encoding="utf8") as f2:
    data2 = f2.read()
    print(data2)
"""