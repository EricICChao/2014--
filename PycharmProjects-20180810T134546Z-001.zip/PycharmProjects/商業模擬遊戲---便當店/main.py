__author__ = 'Eric'

import situtation_environment, characters_behavior, sys, random

run_time_now = 0      #回合計數器起始值
all_run_times = input("請設定要玩幾回合(1回合代表1個月): ")
end_date = situtation_environment.time_up(all_run_times)
#capital
Eric_Chao_total_money = 10000000
Com1_total_money = 12000000
Com2_total_money = 9000000
Com3_total_money = 15000000
#brand value
Eric_Chao_brand_value = 10000
Com1_total_brand_value = 9000
Com2_total_brand_value = 12000
Com3_total_brand_value = 14000
#各項參數紀錄



print("=================================================================================================")
while run_time_now < int(all_run_times):
#前置運算
    run_time_now += 1
    #每回合商譽累積
    brand_value_bonus = random.randint(1,20)
    Eric_Chao_brand_value += brand_value_bonus
    Com_1_total_brand_value += brand_value_bonus
    Com_2_total_brand_value += brand_value_bonus
    Com_3_total_brand_value += brand_value_bonus
    #日期
    date_present = situtation_environment.time_catch(run_time_now)
    #突發事件
    now_month = situtation_environment.compare_month(run_time_now)
    what_event = situtation_environment.unexpected_events_probability_parameters(now_month)
    what_event2 = situtation_environment.unexpected_events_probability_parameters2(now_month)
    #廠商資訊
    firm_name = ("1","2","3","4","5","6","7","8") #供選擇哪家廠商進貨用
    information_firm = ["商譽:","供貨量:","價格:"]
    information_meat1 = []
    information_meat2 = []
    information_meat3 = []
    information_meat4 = []
    information_vegetable1 = []
    information_vegetable2 = []
    information_vegetable3 = []
    information_vegetable4 = []
    #供應商1~肉商
    firm_meat1 = characters_behavior.firm("肉商", 2000000, 24, 10000, now_month)
    firm_meat1_brand_value = characters_behavior.firm.brand_value_output(firm_meat1)
    firm_meat1_event = characters_behavior.firm.get_unexpected_event(firm_meat1,what_event)
    firm_meat1_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat1,firm_meat1.mode_char,firm_meat1_event)
    firm_meat1_price = characters_behavior.firm.firm_price(firm_meat1,firm_meat1.mode_char,firm_meat1_event)
    #供應商2~肉商
    firm_meat2 = characters_behavior.firm("肉商", 1800000, 28, 20000, now_month)
    firm_meat2_brand_value = characters_behavior.firm.brand_value_output(firm_meat2)
    firm_meat2_event = characters_behavior.firm.get_unexpected_event(firm_meat2,what_event)
    firm_meat2_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat2,firm_meat2.mode_char,firm_meat2_event)
    firm_meat2_price = characters_behavior.firm.firm_price(firm_meat2,firm_meat2.mode_char,firm_meat2_event)
    #供應商3~肉商
    firm_meat3 = characters_behavior.firm("肉商", 2400000, 21, 8000, now_month)
    firm_meat3_brand_value = characters_behavior.firm.brand_value_output(firm_meat3)
    firm_meat3_event = characters_behavior.firm.get_unexpected_event(firm_meat3,what_event)
    firm_meat3_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat3,firm_meat3.mode_char,firm_meat3_event)
    firm_meat3_price = characters_behavior.firm.firm_price(firm_meat3,firm_meat3.mode_char,firm_meat3_event)
    #供應商4~肉商
    firm_meat4 = characters_behavior.firm("肉商", 2100000, 25, 12000, now_month)
    firm_meat4_brand_value = characters_behavior.firm.brand_value_output(firm_meat4)
    firm_meat4_event = characters_behavior.firm.get_unexpected_event(firm_meat4,what_event)
    firm_meat4_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat4,firm_meat4.mode_char,firm_meat4_event)
    firm_meat4_price = characters_behavior.firm.firm_price(firm_meat4,firm_meat4.mode_char,firm_meat4_event)
    #供應商1~菜商
    firm_vegetable1 = characters_behavior.firm("菜商", 2000000, 22, 25000, now_month)
    firm_vegetable1_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable1)
    firm_vegetable1_event = characters_behavior.firm.get_unexpected_event(firm_vegetable1,what_event)
    firm_vegetable1_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable1,firm_vegetable1.mode_char,firm_vegetable1_event)
    firm_vegetable1_price = characters_behavior.firm.firm_price(firm_vegetable1,firm_vegetable1.mode_char,firm_vegetable1_event)
    #供應商2~菜商
    firm_vegetable2 = characters_behavior.firm("菜商", 3700000, 12, 16000, now_month)
    firm_vegetable2_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable2)
    firm_vegetable2_event = characters_behavior.firm.get_unexpected_event(firm_vegetable2,what_event)
    firm_vegetable2_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable2,firm_vegetable2.mode_char,firm_vegetable2_event)
    firm_vegetable2_price = characters_behavior.firm.firm_price(firm_vegetable2,firm_vegetable2.mode_char,firm_vegetable2_event)
    #供應商3~菜商
    firm_vegetable3 = characters_behavior.firm("菜商", 4500000, 10, 12000, now_month)
    firm_vegetable3_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable3)
    firm_vegetable3_event = characters_behavior.firm.get_unexpected_event(firm_vegetable3,what_event)
    firm_vegetable3_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable3,firm_vegetable3.mode_char,firm_vegetable3_event)
    firm_vegetable3_price = characters_behavior.firm.firm_price(firm_vegetable3,firm_vegetable3.mode_char,firm_vegetable3_event)
    #供應商4~菜商
    firm_vegetable4 = characters_behavior.firm("菜商", 6000000, 7, 9000, now_month)
    firm_vegetable4_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable4)
    firm_vegetable4_event = characters_behavior.firm.get_unexpected_event(firm_vegetable4,what_event)
    firm_vegetable4_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable4,firm_vegetable4.mode_char,firm_vegetable4_event)
    firm_vegetable4_price = characters_behavior.firm.firm_price(firm_vegetable4,firm_vegetable4.mode_char,firm_vegetable4_event)
    #消費者
    #吃素
        #消費者區塊---吃素1
    consumer_vegetarian1 = characters_behavior.consumer(200000,200)
    consumer_vegetarian1_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian1,30,50)
        #消費者區塊---吃素2
    consumer_vegetarian2 = characters_behavior.consumer(150000,400)
    consumer_vegetarian2_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian2,47,73)
        #消費者區塊---吃素3
    consumer_vegetarian3 = characters_behavior.consumer(350000,1000)
    consumer_vegetarian3_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian3,70,120)
    #吃葷
        #消費者區塊---吃葷1
    consumer_1 = characters_behavior.consumer(300000,420)
    consumer_1_total_demand = characters_behavior.consumer.total_demand(consumer_1,50,70)
        #消費者區塊---吃葷2
    consumer_2 = characters_behavior.consumer(500000,950)
    consumer_2_total_demand = characters_behavior.consumer.total_demand(consumer_2,90,150)
        #消費者區塊---吃葷3
    consumer_3 = characters_behavior.consumer(400000,1050)
    consumer_3_total_demand = characters_behavior.consumer.total_demand(consumer_3,100,120)


    #本回合玩家各項參數紀錄
    order_record_set = [] #本回合玩家購買的廠商有哪些
    lunch_box_category = ("1", "2") #供玩家選擇製作何種便當用
    player_total_meat_q = 0  #本回合買的肉的量
    player_total_vegetable_q = 0 #本回合買的菜的量
    player_total_cost = 0 #玩家本回合的叫貨成本
    player_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Eric_Chao_total_money的)
    vegetable_lunch_box_q = 0 #本回合玩家作的素食便當的量
    meat_lunch_box_q = 0 #本回合玩家作的葷食便當的量
    #本回合Com1各項參數紀錄
    Com1_total_meat_q = 0  #本回合Com1買的肉的量
    Com1_total_vegetable_q = 0 #本回合Com1買的菜的量
    Com1_total_cost = 0 #Com1本回合的叫貨成本
    Com1_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com1_total_money的)
    Com1_vegetable_lunch_box_q = 0 #本回Com1作的素食便當的量
    Com1_meat_lunch_box_q = 0 #本回合Com1作的葷食便當的量
    #本回合Com2各項參數紀錄
    Com2_total_meat_q = 0  #本回合Com2買的肉的量
    Com2_total_vegetable_q = 0 #本回合Com2買的菜的量
    Com2_total_cost = 0 #Com2本回合的叫貨成本
    Com2_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com2_total_money的)
    Com2_vegetable_lunch_box_q = 0 #本回Com2作的素食便當的量
    Com2_meat_lunch_box_q = 0 #本回合Com2作的葷食便當的量
    #本回合Com3各項參數紀錄
    Com3_total_meat_q = 0  #本回合Com3買的肉的量
    Com3_total_vegetable_q = 0 #本回合Com3買的菜的量
    Com3_total_cost = 0 #Com3本回合的叫貨成本
    Com3_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com3_total_money的)
    Com3_vegetable_lunch_box_q = 0 #本回Com3作的素食便當的量
    Com3_meat_lunch_box_q = 0 #本回合Com3作的葷食便當的量


        #各廠商聲譽
    information_meat1.append(firm_meat1_brand_value)
    information_meat2.append(firm_meat2_brand_value)
    information_meat3.append(firm_meat3_brand_value)
    information_meat4.append(firm_meat4_brand_value)
    information_vegetable1.append(firm_vegetable1_brand_value)
    information_vegetable2.append(firm_vegetable2_brand_value)
    information_vegetable3.append(firm_vegetable3_brand_value)
    information_vegetable4.append(firm_vegetable4_brand_value)
        #各廠商供應量
    information_meat1.append(firm_meat1_total_supply)
    information_meat2.append(firm_meat2_total_supply)
    information_meat3.append(firm_meat3_total_supply)
    information_meat4.append(firm_meat4_total_supply)
    information_vegetable1.append(firm_vegetable1_total_supply)
    information_vegetable2.append(firm_vegetable2_total_supply)
    information_vegetable3.append(firm_vegetable3_total_supply)
    information_vegetable4.append(firm_vegetable4_total_supply)
        #各廠商價格
    information_meat1.append(firm_meat1_price)
    information_meat2.append(firm_meat2_price)
    information_meat3.append(firm_meat3_price)
    information_meat4.append(firm_meat4_price)
    information_vegetable1.append(firm_vegetable1_price)
    information_vegetable2.append(firm_vegetable2_price)
    information_vegetable3.append(firm_vegetable3_price)
    information_vegetable4.append(firm_vegetable4_price)
    meat1_information = dict(zip((information_firm),(information_meat1)))
    meat2_information =dict(zip((information_firm),(information_meat2)))
    meat3_information =dict(zip((information_firm),(information_meat3)))
    meat4_information =dict(zip((information_firm),(information_meat4)))
    vegetable1_information = dict(zip((information_firm),(information_vegetable1)))
    vegetable2_information = dict(zip((information_firm),(information_vegetable2)))
    vegetable3_information = dict(zip((information_firm),(information_vegetable3)))
    vegetable4_information = dict(zip((information_firm),(information_vegetable4)))
    firm_information_record =[meat1_information,meat2_information,meat3_information,meat4_information,vegetable1_information,vegetable2_information,vegetable3_information,vegetable4_information]
    print("肉商1")
    print(meat1_information)
    print("肉商2")
    print(meat2_information)
    print("肉商3")
    print(meat3_information)
    print("肉商4")
    print(meat4_information)
    print("菜商1")
    print(vegetable1_information)
    print("菜商2")
    print(vegetable2_information)
    print("菜商3")
    print(vegetable3_information)
    print("菜商4")
    print(vegetable4_information)

    #玩家一操作
    Eric_Chao = characters_behavior.player()
    print("玩家目前金錢")
    print(Eric_Chao_total_money)
    print("玩家目前商譽")
    print(Eric_Chao_brand_value)
    Order_check = input("是否採購食材(Y \ N):")
    YesNo_yes = ("y", "Y")
    while Order_check in YesNo_yes:
        order_firm = input("採購對象: 1.肉商1, 2.肉商2, 3.肉商3, 4.肉商4, 5.菜商1, 6.菜商2, 7.菜商3, 8.菜商4, 9.採購完畢")
        a = int(order_firm)
        if order_firm in firm_name:
            order_amounts = characters_behavior.player.player_buy_foods_amounts(Eric_Chao, a)
            if order_firm == "1":
                firm_meat1_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat1_price
            elif order_firm == "2":
                firm_meat2_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat2_price
            elif order_firm == "3":
                firm_meat3_total_supply -= order_amounts
                player_total_cost += order_amounts*firm_meat3_price
                player_total_meat_q += order_amounts
            elif order_firm == "4":
                firm_meat4_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat4_price
            elif order_firm == "5":
                firm_vegetable1_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable1_price
            elif order_firm == "6":
                firm_vegetable2_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable2_price
            elif order_firm == "7":
                firm_vegetable3_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable3_price
            elif order_firm == "8":
                firm_vegetable4_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable4_price
            order_record = characters_behavior.player.player_buy_firm_record(Eric_Chao, order_firm)
            order_record_set.append(order_record)
        elif order_firm == "9":
            break
        else:
            print("請輸入採購對象選單的選項")
        print("買的肉量: ")
        print(player_total_meat_q)
        print("買的菜量: ")
        print(player_total_vegetable_q)
    print("本回合採購的總肉量: ")
    print(player_total_meat_q)
    print("本回合採購的總菜量: ")
    print(player_total_vegetable_q)
    print("玩家採購總金額: ")
    print(player_total_cost)
    print("玩家採購後資金: ")
    Eric_Chao_total_money -= player_total_cost
    print(Eric_Chao_total_money)
    would_you_want_sell = input("本月是否要賣便當(Y \ N):")
    YesNo_yes = ("y", "Y")
    while would_you_want_sell in YesNo_yes:
        print("目前肉的存量: ")
        print(player_total_meat_q)
        print("目前菜的存量: ")
        print(player_total_vegetable_q)
        print("目前葷食便當的量:")
        print(meat_lunch_box_q)
        print("目前素食便當的量:")
        print(vegetable_lunch_box_q)
        decision = input("你要製作: 1. 素食便當 2. 葷食便當")
        make_lunch_box = characters_behavior.player.make_lunch_box_q_decision(Eric_Chao, decision)
        if decision == "1":
            vegetable_lunch_box_q += make_lunch_box
            player_total_vegetable_q -= make_lunch_box*5
        elif decision == "2":
            meat_lunch_box_q += make_lunch_box
            player_total_meat_q -= make_lunch_box*3
            player_total_vegetable_q -= make_lunch_box*3
        do_you_want_continue = input("是否繼續製作(Y \ N):")
        if do_you_want_continue in YesNo_yes:
            continue
        else:
            break
    #我定的便當價格(素、葷)
    print("可賣的葷食便當的量:")
    print(meat_lunch_box_q)
    print("可賣的素食便當的量:")
    print(vegetable_lunch_box_q)
    vegetable_lunch_box_price = characters_behavior.player.make_price_decision(Eric_Chao, "你的素食便當定價為: ")
    meat_lunch_box_price = characters_behavior.player.make_price_decision(Eric_Chao, "你的葷食便當定價為: ")


#便當如何分 配給各消費者區塊



    #電腦Com1


    #電腦Com2

    #電腦Com3





    #食材廠商中鏢
    print(what_event2)
    print(what_event)
    bad_news = characters_behavior.firm.I_get_bad_news(firm_meat4, what_event, 12000)

    #各消費者區塊對player的需求量
    vegetarian1_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian1,consumer_vegetarian1_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    vegetarian2_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian2,consumer_vegetarian2_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    vegetarian3_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian3,consumer_vegetarian3_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    meat1_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_1,consumer_1_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    meat2_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_2,consumer_2_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    meat3_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_3,consumer_3_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    #各消費者區塊對Com1的需求量
    #Com1_vegetarian1_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian1,consumer_vegetarian1_total_demand,lun_box_price.vegetable_lunch_box_price,Eric_Chao_brand_value)
    #Com1_vegetarian2_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian2,consumer_vegetarian2_total_demand,lun_box_price.vegetable_lunch_box_price,Eric_Chao_brand_value)
    #Com1_vegetarian3_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_vegetarian3,consumer_vegetarian3_total_demand,lun_box_price.vegetable_lunch_box_price,Eric_Chao_brand_value)
    #Com1_meat1_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_1,consumer_1_total_demand,lun_box_price.meat_lunch_box_price,Eric_Chao_brand_value)
    #Com1_meat2_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_2,consumer_2_total_demand,lun_box_price.meat_lunch_box_price,Eric_Chao_brand_value)
    #Com1_meat3_demand = characters_behavior.consumer.preference_restaurant_demand(consumer_3,consumer_3_total_demand,lun_box_price.meat_lunch_box_price,Eric_Chao_brand_value)
        #消費者對個別餐廳的需求量變動(計算我的便當製作的量和消費者需求量的加減，以及賺到的player_revenue。加到最上面的Eric_Chao_total_money)







    player_revenue = vegetable_lunch_box_q*vegetable_lunch_box_price + meat_lunch_box_q*meat_lunch_box_price - player_total_cost  #player本回合總收益
    Eric_Chao_total_money += player_revenue    #player本回合的總資金
    print("本回合player總收益: ")
    print(player_revenue)
    print("本回合player的總資金: ")
    print(Eric_Chao_total_money)
    Com1_revenue = vegetable_lunch_box_q*vegetable_lunch_box_price + meat_lunch_box_q*meat_lunch_box_price - Com1_total_cost  #Com1本回合總收益
    Com1_total_money += Com1_revenue    #Com1本回合的總資金
    print("本回合Com1總收益: ")
    print(Com1_revenue)
    print("本回合Com1的總資金: ")
    print(Com1_total_money)
    Com2_revenue = vegetable_lunch_box_q*vegetable_lunch_box_price + meat_lunch_box_q*meat_lunch_box_price - Com2_total_cost  #Com1本回合總收益
    Com2_total_money += Com2_revenue    #Com1本回合的總資金
    print("本回合Com2總收益: ")
    print(Com2_revenue)
    print("本回合Com2的總資金: ")
    print(Com2_total_money)
    Com3_revenue = vegetable_lunch_box_q*vegetable_lunch_box_price + meat_lunch_box_q*meat_lunch_box_price - Com3_total_cost  #Com1本回合總收益
    Com3_total_money += player_revenue    #Com1本回合的總資金
    print("本回合Com3總收益: ")
    print(Com3_revenue)
    print("本回合Com3的總資金: ")
    print(Com3_total_money)

    print("=================================================================================================")


#資料連續輸入，並匯出到新的檔案中
def text_data_input_in_new_file():
    data_set = []
    i = 1
    a = input("請設定要輸入的資料項有幾項: ")
    while i < int(a):
        text_data = input("請輸入資料: ")
        data_set.append(text_data)
        next_step = input("接下來要繼續的動作為: (1)輸入下一筆資料 ；(2)繼續修改原本資料； (3)結束應用程式")
        if next_step is '1':
            i += 1
            b = str(i)
            text_data_next = input("請輸入第"+ b + "筆資料: ")
            data_set.append(text_data_next)
        elif next_step is '2':
            continue
        elif next_step is '3':
            sys.exit()
    new_file_name = input("請輸入檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'xt', encoding= "utf8", newline = '') as f:
        for x in data_set:
        #將資料從set中一筆一筆寫入檔案裡
            with open("C://Users//Eric//PycharmProjects//data searching//save_space//"+new_file_name, 'at', encoding= "utf8", newline = '') as f:
                f.write(x)
#=======================================================================================================================

