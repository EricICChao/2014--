__author__ = 'Eric'
import random, datetime, re, os

#突發事件
"""
哪些事件，定義:
    供應商事件:
        颱風(7~10月): 果菜量減少10~40%，漲價10~40%
        水災: 果菜量減少30~50%，漲價35~60%
        肉類生長不及: 肉類供應量減少40%，漲價45%
    消費者事件:
        農藥風暴(全年發生): 消費者要求賠償、毀損商譽
        餿油風暴(全年發生): 消費者要求賠償、毀損商譽
        病死肉風暴(全年發生): 消費者要求賠償、毀損商譽

發生機率:
    供應商事件:
        颱風: 15%
        水災: 伴隨颱風，機率是颱風的75%
        肉類生長不及: 20%
    消費者事件:
        農藥風暴: 1%
        餿油風暴: 1%
        病死肉風暴: 1%
"""
probability = random.randint(1,100)
probability_floods = random.randint(1,100)
def unexpected_events_probability_parameters(now_month):
    if 1 <= probability <= 15:
        if now_month == '07':
            if 1 <= probability_floods <= 75:
                print("仄紅胎又淹水囉~")
                return 'b'
            else:
                print("仄紅胎囉~")
                return 'a'
        elif now_month == '08':
            if 1 <= probability_floods <= 75:
                print("仄紅胎又淹水囉~")
                return 'b'
            else:
                print("仄紅胎囉~")
                return 'a'
        elif now_month == '09':
            if 1 <= probability_floods <= 75:
                print("仄紅胎又淹水囉~")
                return 'b'
            else:
                print("仄紅胎囉~")
                return 'a'
        elif now_month == '10':
            if 1 <= probability_floods <= 75:
                print("仄紅胎又淹水囉~")
                return 'b'
            else:
                print("仄紅胎囉~")
                return 'a'
    elif 16 <= probability <= 36:
        print("沒肉了~")
        return 'c'
    elif probability == 37:
        print("發現農藥!!!")
        return 'd'
    elif probability == 38:
        print("發現胎哥油!!!")
        return 'e'
    elif probability == 39:
        print("發現黑心病死肉!!!")
        return 'f'

def unexpected_events_probability_parameters2(now_month):
    month_set = ['07','08','09','10']
    if now_month in month_set:
        if 1 <= probability <= 15:
            if 1 <= probability_floods <= 75:
                print("@@@仄紅胎又淹水囉~")
                return 'b'
            else:
                print("@@@仄紅胎囉~")
                return 'a'
    elif 16 <= probability <= 36:
        print("@@@沒肉了~")
        return 'c'
    elif probability == 37:
        print("@@@發現農藥!!!")
        return 'd'
    elif probability == 38:
        print("@@@發現胎哥油!!!")
        return 'e'
    elif probability == 39:
        print("@@@發現黑心病死肉!!!")
        return 'f'

#=======================================================================================================================
#時間監控模組
#參數區
start_date = datetime.date(2014,9,1)
every_times_add_time = datetime.timedelta(days = 30)
month_catch = r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"      #命名分組捕捉

#回合數紀錄顯示器
def time_catch(run_time_now):
    time_times = run_time_now*every_times_add_time
    now_time = str(start_date + time_times)
    print("目前日期是: "+now_time)

#突發事件比對引數
def compare_month(run_time_now):
    time_times = run_time_now*every_times_add_time
    now_time = str(start_date + time_times)
    month_now = re.search(month_catch, now_time).group(2)
    return month_now      #供突發事件判別用

#結束日期
def time_up(all_run_times):
    date_up = int(all_run_times)*every_times_add_time+start_date
    print("結束日期是:")
    print(date_up)
#=======================================================================================================================
#消費者事件處理方法與結果
"""
    關鍵字句反應資料庫調用關鍵字句
    機率模型隨機選定要符合的關鍵字
    依據輸入內容裡是否可比對到關鍵字:
        如果比對到，賠償金額10000，商譽增加10%
        如果比對不到，賠償金額10000，商譽減少20%


回應關鍵字:
事件、、感到抱歉、對不起、負起責任、賠償、發票、餐券、暫停營業、

、農藥 #農藥   return 'd'
、胎哥油 #胎哥油         return 'e'
黑心病死肉  #黑心病死肉     return 'f'

捕捉到符合多少的關鍵字，商譽的損失也會不一樣。



"""

#符合條件之檔案一次讀取功能

def reading_search_data():
    key_word = input("請輸入要查詢的關鍵字:")
    #指定查詢資特定料夾內目錄list
    folder_path = input("指定要搜尋的資料夾位址，目錄的路徑表示方法:  C://Users//Eric//Desktop//information literacy相關//，請輸入:")
    file_names_list = os.listdir(folder_path)
    new_file_name = input("請輸入要儲存搜尋到的資料檔案的檔案格式與名稱: ")
    with open("C://Users//Eric//PycharmProjects//data searching//save_space///"+new_file_name, 'xt', encoding= "utf8") as f:
        for x in file_names_list:
            #with open("C://Users//Eric//PycharmProjects//test_text//"+x, encoding= "utf8") as f2:
            with open(folder_path + x,'rt', encoding="utf8") as f2:
                text_data = f2.read()
                #比對英文
                search_english_key_word = re.search(r"\b + key_word + \b", text_data)
                #比對中文.
                search_chinese_key_word = re.search(r"(?u)\b + key_word + \b", text_data)
                if search_english_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)
                elif search_chinese_key_word is not None or text_data.count(key_word) != 0:
                    f.write(text_data)



#=======================================================================================================================
#便當如何分 配給各消費者區塊
#寫一組分配的演算法





