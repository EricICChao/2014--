__author__ = 'Eric'

import random

#玩家
class player:
    def __init__(self):
        self
    def player_buy_foods_amounts(self, your_select_firm):
        firm_name_string = ["肉商1", "肉商2", "肉商3", "肉商4", "菜商1", "菜商2", "菜商3", "菜商4"]
        if 1 <= your_select_firm <= 8:
            b = str(firm_name_string[your_select_firm-1])  #set的第 一個元素是set[0]，所以用[your_select_firm-1]才能表示輸入選項1要選第一個元素，此後的元素也是以此規則類推
            a = input("請輸入你想要購買" + b + "多少單位:")
            amounts = int(a)
            return amounts
        elif your_select_firm == 9:
            return str(your_select_firm)
    def player_buy_firm_record(self, firm_name):
        return firm_name
    def make_lunch_box_q_decision(self, decision):
        if decision == '1':
            a = input("請輸入你想要製作的素食便當數量(菜: 5單位):")
            lunch_box_q = int(a)
            return lunch_box_q
        elif decision == '2':
            b = input("請輸入你想要製作的葷食便當數量(菜: 3單位, 肉: 3單位):")
            lunch_box_q = int(b)
            return lunch_box_q
        else:
            print("請輸入 1,2")
    def make_price_decision(self, what_is_your_lunch_box_price_string):
        k = input(what_is_your_lunch_box_price_string)
        price = int(k)
        return price

#電腦AI
"""
計算目前自身的金錢、庫存、商譽、計算消費者偏好與需求、商品製作數量、供應商需求模型
下達指令能力:
叫貨
做商品
訂價
"""
class computer_AI:
    def __init__(self):
        self
    #暫且把所有AI的各別消費者區塊的supply函式設定為如此
    def AI_lunch_box_q_decision(self, total_demand1,total_demand2, total_demand3, brand_value):
        which_segment_total_demand = (total_demand1/4)+(total_demand2/4)+(total_demand3/4)
        supply_lunch_box_q = which_segment_total_demand*(0.8+brand_value*0.00001)
        return supply_lunch_box_q
    def AI_buy_food_amounts(self, self_supply_lunch_box_q,rate, unit):
        #取得要製造的數量後，再計算所需要的材料的量，再決定要分配到哪幾間廠商購買，unit表示製作一份需要多少單位
        food_amount = self_supply_lunch_box_q*rate*0.01*unit
        return food_amount
    def AI_lunch_box_price_decision(self,food_amounts_cost, revenue_rate, self_supply_lunch_box_q):
        #revenue_rate: 設定他們要的收益率
        price = (1+revenue_rate)*(food_amounts_cost/self_supply_lunch_box_q)
        return price
    def AI_distribute_lunch_box_q(self, lunch_box_q, rate):
        #設定他們的便當要賣給哪一區塊的量
        distribute_q = lunch_box_q*rate
        return distribute_q

#消費者
# 便當店商譽和所得會影響選擇、需求量會有百分比的變動、價格會影響購買數量
class consumer:
    def __init__(self, base_number, price_based_number):
        #注意收入的因素(收入越高，相當於price_based_number減少，base_number上升(因為總需求用到)；收入越低則反之)
        self.base_number = base_number
        self.price_based_number = price_based_number
    #注意收入的因素(收入越高，越青睞或是能接受高價的便當，相當於下面的price_rank的max會下降)
    def total_demand(self, price_rank_min, price_rank_max):
        price_rank = random.randint(price_rank_min,price_rank_max)
        #based_number是當價格為0時，便當的總需求量(至少要設定到百萬)，price_based_number*price是價格變化後，便當需求減少的數量(至多設定到萬)
        Qd = self.base_number-self.price_based_number*price_rank
        return Qd

#原料廠商
class firm:
    def __init__(self,mode_char = "商店",total_supply = 0, price = 0, brand_value = 0, now_month = '00'):
        self.total_supply = total_supply
        self.price = price
        self.brand_value = brand_value
        self.now_month = now_month
        self.mode_char = mode_char
        #商譽不佳，越容易成為消費者事件的主角，妳有跟他們進貨的紀錄就完了
        #mode_char決定你是哪一種廠商的突發事件參數。
        #mode_char: 菜商, 肉商
    #取得目前發生事件
    def get_unexpected_event(self,what_event):
        if what_event == 'a':
            return 'a'
        elif what_event == 'b':
            return 'b'
        elif what_event == 'c':
            return 'c'
        elif what_event == 'd':
            return 'd'
        elif what_event == 'e':
            return 'e'
    #請傳入get_unexpected_event的參數
    def firm_supply_quantity(self,mode_char, firm_get_unexpected_event):
        if self.mode_char == "菜商":
            if firm_get_unexpected_event == 'a':
                total_supply = self.total_supply*(1-0.01*random.randint(10,40))
                return total_supply
            elif firm_get_unexpected_event == 'b':
                total_supply = self.total_supply*(1-0.01*random.randint(30,50))
                return total_supply
            else:
                return self.total_supply
        elif self.mode_char == "肉商":
            if firm_get_unexpected_event == 'c':
                total_supply = self.total_supply*(1-0.4)
                return total_supply
            else:
                return self.total_supply
    def firm_price(self,mode_char, firm_get_unexpected_event):
        if self.mode_char == "菜商":
            if firm_get_unexpected_event == 'a':
                price = self.price*random.randint(110,140)*0.01
                return price
            elif firm_get_unexpected_event == 'b':
                price = self.price*random.randint(1170,1200)*0.001
                return price
            else:
                return self.price
        elif self.mode_char == "肉商":
            if firm_get_unexpected_event == 'c':
                price = self.price*145*0.01
                return price
            else:
                return self.price
    def brand_value_output(self):
        return self.brand_value

