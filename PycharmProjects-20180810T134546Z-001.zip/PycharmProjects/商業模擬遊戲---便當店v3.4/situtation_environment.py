__author__ = 'Eric'
import random, datetime, re

#突發事件
"""
哪些事件，定義:
    供應商事件:
        颱風(7~10月): 果菜量減少10~40%，漲價10~40%
        水災: 果菜量減少30~50%，漲價35~60%
        肉類生長不及: 肉類供應量減少40%，漲價45%
    消費者事件:
        農藥風暴(全年發生): 消費者要求賠償、毀損商譽
        病死肉風暴(全年發生): 消費者要求賠償、毀損商譽

發生機率:
    供應商事件:
        颱風: 15%
        水災: 伴隨颱風，機率是颱風的75%
        肉類生長不及: 20%
    消費者事件:
        農藥風暴: 1%
        病死肉風暴: 1%
"""
probability = random.randint(1,100)
probability_floods = random.randint(1,100)

def unexpected_events_probability_parameters2(now_month):
    month_set = ['07','08','09','10']
    if now_month in month_set:
        if 1 <= probability <= 15:
            if 1 <= probability_floods <= 75:
                print("@@@颱風淹水~")
                return 'b'
            else:
                print("@@@颱風~")
                return 'a'
    elif 16 <= probability <= 36:
        print("@@@沒肉了~")
        return 'c'
    elif probability == 37:
        print("@@@發現農藥!!!")
        return 'd'
    elif probability == 38:
        print("@@@發現黑心病死肉!!!")
        return 'e'
    else:
        print("本月無事")


#=======================================================================================================================
#時間監控模組
#參數區
start_date = datetime.date(2014,9,1)
every_times_add_time = datetime.timedelta(days = 30)
month_catch = r"(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})"      #命名分組捕捉

#回合數紀錄顯示器
def time_catch(run_time_now):
    time_times = run_time_now*every_times_add_time
    now_time = str(start_date + time_times)
    print("目前日期是: "+now_time)

#突發事件比對引數
def compare_month(run_time_now):
    time_times = run_time_now*every_times_add_time
    now_time = str(start_date + time_times)
    month_now = re.search(month_catch, now_time).group(2)
    return month_now      #供突發事件判別用

#結束日期
def time_up(all_run_times):
    date_up = int(all_run_times)*every_times_add_time+start_date
    print("結束日期是:")
    print(date_up)

#=======================================================================================================================
#廠商中鏢運算
#中鏢的廠商
def get_bad_news(what_event2, firm_name, brand_value, event_code):
    get_bad_news_probability = random.randint(1,100)
    while what_event2 == event_code:
        if 15000<= brand_value <= 19999 and 1 <= get_bad_news_probability <= 10:
            return firm_name
        elif 10000 <= brand_value <= 14999 and 11 <= get_bad_news_probability <= 40:
            return firm_name
        elif brand_value <= 9999:
            return firm_name
        else:
            return 'no'

#餐廳是否有買到中鏢廠商的東西
def are_you_got_it(order_record_set, firm_get_bad_news):
     if firm_get_bad_news in order_record_set:
        return 'get'

#=======================================================================================================================
#便當如何限制再player和Com123販售後，不超過所有消費者的需求
def preference_restaurant_demand(total_demand,restaurant_price, restaurant_brand_value):
    demand = (total_demand/4)*(0.7+restaurant_brand_value*0.0001) - restaurant_price*10
    return demand

#player市場區塊分配
def distribute_lunch_box_q(consumer):
    a = print("輸入分配給"+ consumer+ "的量")
    b = input()
    q = int(b)
    return q

#市場區塊利潤
def segment_revenue_situated(lunch_box_q_situated1,lunch_box_q_situated2, price):
    #situated1是個別餐廳的生產量未超過個別區塊對個別餐應的需求
    #situated2是個別餐廳的生產量已超過個別區塊對個別餐應的需求
    if lunch_box_q_situated1 < lunch_box_q_situated2:
        segment_revenue = lunch_box_q_situated1*price
    else:
        segment_revenue = lunch_box_q_situated2*price
    return segment_revenue

#市場銷售量
def segment_q_situated(lunch_box_q_situated1,lunch_box_q_situated2):
    #situated1是個別餐廳的生產量未超過個別區塊對個別餐應的需求
    #situated2是個別餐廳的生產量已超過個別區塊對個別餐應的需求
    if lunch_box_q_situated1 < lunch_box_q_situated2:
        return lunch_box_q_situated1
    else:
        return lunch_box_q_situated2