__author__ = 'Eric'

import situtation_environment, characters_behavior, sys, random

run_time_now = 0      #回合計數器起始值
all_run_times = input("請設定要玩幾回合(1回合代表1個月): ")
end_date = situtation_environment.time_up(all_run_times)
#capital
Eric_Chao_total_money = 10000000
Com1_total_money = 12000000
Com2_total_money = 9000000
Com3_total_money = 15000000
#brand value
Eric_Chao_brand_value = 1000
Com1_total_brand_value = 900
Com2_total_brand_value = 1200
Com3_total_brand_value = 1400


print("=================================================================================================")
while run_time_now < int(all_run_times):
    #===================================================================================================================
    #前置運算
    run_time_now += 1
    #每回合商譽累積
    brand_value_bonus = random.randint(1,20)
    Eric_Chao_brand_value += brand_value_bonus
    Com1_total_brand_value += brand_value_bonus
    Com2_total_brand_value += brand_value_bonus
    Com3_total_brand_value += brand_value_bonus

#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1
    print("行33")
    print("目前各玩家total money")
    print(Eric_Chao_total_money,Com1_total_money,Com2_total_money,Com3_total_money)
    print("本回合商譽bonus, 目前各玩家商譽")
    print(brand_value_bonus, Eric_Chao_brand_value, Com1_total_brand_value, Com2_total_brand_value, Com3_total_brand_value)
#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1#檢查點1


    #日期
    date_present = situtation_environment.time_catch(run_time_now)
    #突發事件
    now_month = situtation_environment.compare_month(run_time_now)
    what_event2 = situtation_environment.unexpected_events_probability_parameters2(now_month)
    print(what_event2)
    #===================================================================================================================
    #廠商資訊
    firm_name = ("1","2","3","4","5","6","7","8") #供選擇哪家廠商進貨用
    information_firm = ["商譽:","供貨量:","價格:"]
    information_meat1 = []
    information_meat2 = []
    information_meat3 = []
    information_meat4 = []
    information_vegetable1 = []
    information_vegetable2 = []
    information_vegetable3 = []
    information_vegetable4 = []
    #供應商1~肉商
    firm_meat1 = characters_behavior.firm("肉商", 20000000, 24, 10000, now_month)
    firm_meat1_brand_value = characters_behavior.firm.brand_value_output(firm_meat1)
    firm_meat1_event = characters_behavior.firm.get_unexpected_event(firm_meat1,what_event2)
    firm_meat1_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat1,firm_meat1.mode_char,firm_meat1_event)
    firm_meat1_price = characters_behavior.firm.firm_price(firm_meat1,firm_meat1.mode_char,firm_meat1_event)
    #供應商2~肉商
    firm_meat2 = characters_behavior.firm("肉商", 18000000, 28, 20000, now_month)
    firm_meat2_brand_value = characters_behavior.firm.brand_value_output(firm_meat2)
    firm_meat2_event = characters_behavior.firm.get_unexpected_event(firm_meat2,what_event2)
    firm_meat2_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat2,firm_meat2.mode_char,firm_meat2_event)
    firm_meat2_price = characters_behavior.firm.firm_price(firm_meat2,firm_meat2.mode_char,firm_meat2_event)
    #供應商3~肉商
    firm_meat3 = characters_behavior.firm("肉商", 24000000, 21, 8000, now_month)
    firm_meat3_brand_value = characters_behavior.firm.brand_value_output(firm_meat3)
    firm_meat3_event = characters_behavior.firm.get_unexpected_event(firm_meat3,what_event2)
    firm_meat3_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat3,firm_meat3.mode_char,firm_meat3_event)
    firm_meat3_price = characters_behavior.firm.firm_price(firm_meat3,firm_meat3.mode_char,firm_meat3_event)
    #供應商4~肉商
    firm_meat4 = characters_behavior.firm("肉商", 21000000, 25, 12000, now_month)
    firm_meat4_brand_value = characters_behavior.firm.brand_value_output(firm_meat4)
    firm_meat4_event = characters_behavior.firm.get_unexpected_event(firm_meat4,what_event2)
    firm_meat4_total_supply = characters_behavior.firm.firm_supply_quantity(firm_meat4,firm_meat4.mode_char,firm_meat4_event)
    firm_meat4_price = characters_behavior.firm.firm_price(firm_meat4,firm_meat4.mode_char,firm_meat4_event)
    #供應商1~菜商
    firm_vegetable1 = characters_behavior.firm("菜商", 20000000, 22, 25000, now_month)
    firm_vegetable1_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable1)
    firm_vegetable1_event = characters_behavior.firm.get_unexpected_event(firm_vegetable1,what_event2)
    firm_vegetable1_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable1,firm_vegetable1.mode_char,firm_vegetable1_event)
    firm_vegetable1_price = characters_behavior.firm.firm_price(firm_vegetable1,firm_vegetable1.mode_char,firm_vegetable1_event)
    #供應商2~菜商
    firm_vegetable2 = characters_behavior.firm("菜商", 37000000, 12, 16000, now_month)
    firm_vegetable2_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable2)
    firm_vegetable2_event = characters_behavior.firm.get_unexpected_event(firm_vegetable2,what_event2)
    firm_vegetable2_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable2,firm_vegetable2.mode_char,firm_vegetable2_event)
    firm_vegetable2_price = characters_behavior.firm.firm_price(firm_vegetable2,firm_vegetable2.mode_char,firm_vegetable2_event)
    #供應商3~菜商
    firm_vegetable3 = characters_behavior.firm("菜商", 45000000, 10, 12000, now_month)
    firm_vegetable3_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable3)
    firm_vegetable3_event = characters_behavior.firm.get_unexpected_event(firm_vegetable3,what_event2)
    firm_vegetable3_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable3,firm_vegetable3.mode_char,firm_vegetable3_event)
    firm_vegetable3_price = characters_behavior.firm.firm_price(firm_vegetable3,firm_vegetable3.mode_char,firm_vegetable3_event)
    #供應商4~菜商
    firm_vegetable4 = characters_behavior.firm("菜商", 60000000, 7, 9000, now_month)
    firm_vegetable4_brand_value = characters_behavior.firm.brand_value_output(firm_vegetable4)
    firm_vegetable4_event = characters_behavior.firm.get_unexpected_event(firm_vegetable4,what_event2)
    firm_vegetable4_total_supply = characters_behavior.firm.firm_supply_quantity(firm_vegetable4,firm_vegetable4.mode_char,firm_vegetable4_event)
    firm_vegetable4_price = characters_behavior.firm.firm_price(firm_vegetable4,firm_vegetable4.mode_char,firm_vegetable4_event)
        #各廠商聲譽
    information_meat1.append(firm_meat1_brand_value)
    information_meat2.append(firm_meat2_brand_value)
    information_meat3.append(firm_meat3_brand_value)
    information_meat4.append(firm_meat4_brand_value)
    information_vegetable1.append(firm_vegetable1_brand_value)
    information_vegetable2.append(firm_vegetable2_brand_value)
    information_vegetable3.append(firm_vegetable3_brand_value)
    information_vegetable4.append(firm_vegetable4_brand_value)
        #各廠商供應量
    information_meat1.append(firm_meat1_total_supply)
    information_meat2.append(firm_meat2_total_supply)
    information_meat3.append(firm_meat3_total_supply)
    information_meat4.append(firm_meat4_total_supply)
    information_vegetable1.append(firm_vegetable1_total_supply)
    information_vegetable2.append(firm_vegetable2_total_supply)
    information_vegetable3.append(firm_vegetable3_total_supply)
    information_vegetable4.append(firm_vegetable4_total_supply)
        #各廠商價格
    information_meat1.append(firm_meat1_price)
    information_meat2.append(firm_meat2_price)
    information_meat3.append(firm_meat3_price)
    information_meat4.append(firm_meat4_price)
    information_vegetable1.append(firm_vegetable1_price)
    information_vegetable2.append(firm_vegetable2_price)
    information_vegetable3.append(firm_vegetable3_price)
    information_vegetable4.append(firm_vegetable4_price)
    meat1_information = dict(zip((information_firm),(information_meat1)))
    meat2_information =dict(zip((information_firm),(information_meat2)))
    meat3_information =dict(zip((information_firm),(information_meat3)))
    meat4_information =dict(zip((information_firm),(information_meat4)))
    vegetable1_information = dict(zip((information_firm),(information_vegetable1)))
    vegetable2_information = dict(zip((information_firm),(information_vegetable2)))
    vegetable3_information = dict(zip((information_firm),(information_vegetable3)))
    vegetable4_information = dict(zip((information_firm),(information_vegetable4)))
    firm_information_record =[meat1_information,meat2_information,meat3_information,meat4_information,vegetable1_information,vegetable2_information,vegetable3_information,vegetable4_information]
    #===================================================================================================================
    #消費者
    #吃素
        #消費者區塊---吃素1
    consumer_vegetarian1 = characters_behavior.consumer(200000,200)
    consumer_vegetarian1_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian1,30,50)
    cv1 = str(consumer_vegetarian1_total_demand)
    print("素食者1區塊的總需求:" + cv1)
        #消費者區塊---吃素2
    consumer_vegetarian2 = characters_behavior.consumer(150000,400)
    consumer_vegetarian2_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian2,47,73)
    cv2 = str(consumer_vegetarian2_total_demand)
    print("素食者2區塊的總需求:" + cv2)
        #消費者區塊---吃素3
    consumer_vegetarian3 = characters_behavior.consumer(350000,1000)
    consumer_vegetarian3_total_demand = characters_behavior.consumer.total_demand(consumer_vegetarian3,70,120)
    cv3 = str(consumer_vegetarian3_total_demand)
    print("素食者3區塊的總需求:" + cv3)
    #吃葷
        #消費者區塊---吃葷1
    consumer_1 = characters_behavior.consumer(300000,420)
    consumer_1_total_demand = characters_behavior.consumer.total_demand(consumer_1,50,70)
    c1 = str(consumer_1_total_demand)
    print("一般消費者1區塊的總需求:" + c1)
        #消費者區塊---吃葷2
    consumer_2 = characters_behavior.consumer(500000,950)
    consumer_2_total_demand = characters_behavior.consumer.total_demand(consumer_2,90,150)
    c2 = str(consumer_2_total_demand)
    print("一般消費者2區塊的總需求:" + c2)
        #消費者區塊---吃葷3
    consumer_3 = characters_behavior.consumer(400000,1050)
    consumer_3_total_demand = characters_behavior.consumer.total_demand(consumer_3,100,120)
    c3 = str(consumer_3_total_demand)
    print("一般消費者3區塊的總需求:" + c3)
    #===================================================================================================================
    #廠商訊息顯示
    print("肉商1")
    print(meat1_information)
    print("肉商2")
    print(meat2_information)
    print("肉商3")
    print(meat3_information)
    print("肉商4")
    print(meat4_information)
    print("菜商1")
    print(vegetable1_information)
    print("菜商2")
    print(vegetable2_information)
    print("菜商3")
    print(vegetable3_information)
    print("菜商4")
    print(vegetable4_information)
    #===================================================================================================================
    #本回合玩家各項參數紀錄
    order_record_set = [] #本回合玩家購買的廠商有哪些
    lunch_box_category = ("1", "2") #供玩家選擇製作何種便當用
    player_total_meat_q = 0  #本回合買的肉的量
    player_total_vegetable_q = 0 #本回合買的菜的量
    player_total_cost = 0 #玩家本回合的叫貨成本
    player_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Eric_Chao_total_money的)
    vegetable_lunch_box_q = 0 #本回合玩家作的素食便當的量
    meat_lunch_box_q = 0 #本回合玩家作的葷食便當的量
    #本回合Com1各項參數紀錄
    Com1_order_record_set = ["1","2","4","5","6","7"] #本回合Com1購買的廠商有哪些，請寫入"1","'2", "3"....這樣的廠商名字形式
    Com1_total_cost = 0 #Com1本回合的叫貨成本
    Com1_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com1_total_money的)
    Com1_vegetable_lunch_box_q = 0 #本回Com1作的素食便當的量
    Com1_meat_lunch_box_q = 0 #本回合Com1作的葷食便當的量
    #本回合Com2各項參數紀錄
    Com2_order_record_set = ["1","3","7","8"] #本回合Com2購買的廠商有哪些，請寫入"1","'2", "3"....這樣的廠商名字形式
    Com2_total_cost = 0 #Com2本回合的叫貨成本
    Com2_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com2_total_money的)
    Com2_vegetable_lunch_box_q = 0 #本回Com2作的素食便當的量
    Com2_meat_lunch_box_q = 0 #本回合Com2作的葷食便當的量
    #本回合Com3各項參數紀錄
    Com3_order_record_set = ["2", "4", "5", "6"] #本回合Com3購買的廠商有哪些，請寫入"1","'2", "3"....這樣的廠商名字形式
    Com3_total_cost = 0 #Com3本回合的叫貨成本
    Com3_revenue = 0   #本回合總營收 - 總成本的利潤 (要回加給Com3_total_money的)
    Com3_vegetable_lunch_box_q = 0 #本回Com3作的素食便當的量
    Com3_meat_lunch_box_q = 0 #本回合Com3作的葷食便當的量
    #===================================================================================================================
    #玩家一操作
    Eric_Chao = characters_behavior.player()
    print("玩家目前金錢")
    print(Eric_Chao_total_money)
    print("玩家目前商譽")
    print(Eric_Chao_brand_value)

#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2
    print("行232")
    print("目前各玩家total money")
    print(Eric_Chao_total_money,Com1_total_money,Com2_total_money,Com3_total_money)
    print("本回合商譽bonus, 目前各玩家商譽")
    print(brand_value_bonus, Eric_Chao_brand_value, Com1_total_brand_value, Com2_total_brand_value, Com3_total_brand_value)
    print(what_event2)
    print("素食者1區塊的總需求:" + cv1)
    print("素食者2區塊的總需求:" + cv2)
    print("素食者3區塊的總需求:" + cv3)
    print("一般消費者1區塊的總需求:" + c1)
    print("一般消費者2區塊的總需求:" + c2)
    print("一般消費者3區塊的總需求:" + c3)
    print("目前player各參數")
    print( order_record_set,player_total_meat_q,player_total_vegetable_q,player_total_cost,player_revenue,vegetable_lunch_box_q,meat_lunch_box_q)
    print("目前Com1各參數")
    print(Com1_order_record_set,Com1_total_cost,Com1_revenue,Com1_vegetable_lunch_box_q,Com1_meat_lunch_box_q)
    print("目前Com2各參數")
    print(Com2_order_record_set,Com2_total_cost,Com2_revenue,Com2_vegetable_lunch_box_q,Com2_meat_lunch_box_q)
    print("目前Com3各參數")
    print(Com3_order_record_set,Com3_total_cost,Com3_revenue,Com3_vegetable_lunch_box_q,Com3_meat_lunch_box_q)
#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2#檢查點2


    Order_check = input("是否採購食材(Y \ N):")
    YesNo_yes = ("y", "Y")
    while Order_check in YesNo_yes:
        order_firm = input("採購對象: 1.肉商1, 2.肉商2, 3.肉商3, 4.肉商4, 5.菜商1, 6.菜商2, 7.菜商3, 8.菜商4, 9.採購完畢")
        a = int(order_firm)
        if order_firm in firm_name:
            order_amounts = characters_behavior.player.player_buy_foods_amounts(Eric_Chao, a)
            if order_firm == "1":
                firm_meat1_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat1_price

#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行268")
                print(firm_meat1_total_supply,order_amounts,player_total_meat_q,player_total_cost,order_amounts*firm_meat1_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3

            elif order_firm == "2":
                firm_meat2_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat2_price

#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行278")
                print(firm_meat2_total_supply,order_amounts,player_total_meat_q,player_total_cost,order_amounts*firm_meat2_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3

            elif order_firm == "3":
                firm_meat3_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat3_price



#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行290")
                print(firm_meat3_total_supply,order_amounts,player_total_meat_q,player_total_cost,order_amounts*firm_meat3_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3


            elif order_firm == "4":
                firm_meat4_total_supply -= order_amounts
                player_total_meat_q += order_amounts
                player_total_cost += order_amounts*firm_meat4_price


#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行302")
                print(firm_meat4_total_supply,order_amounts,player_total_meat_q,player_total_cost,order_amounts*firm_meat4_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3



            elif order_firm == "5":
                firm_vegetable1_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable1_price

#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行314")
                print(firm_vegetable1_total_supply,order_amounts,player_total_vegetable_q,player_total_cost,order_amounts*firm_vegetable1_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3



            elif order_firm == "6":
                firm_vegetable2_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable2_price

#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行326")
                print(firm_vegetable2_total_supply,order_amounts,player_total_vegetable_q,player_total_cost,order_amounts*firm_vegetable2_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3



            elif order_firm == "7":
                firm_vegetable3_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable3_price

#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行338")
                print(firm_vegetable3_total_supply,order_amounts,player_total_vegetable_q,player_total_cost,order_amounts*firm_vegetable3_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3

            elif order_firm == "8":
                firm_vegetable4_total_supply -= order_amounts
                player_total_vegetable_q += order_amounts
                player_total_cost += order_amounts*firm_vegetable4_price
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3
                print("行347")
                print(firm_vegetable4_total_supply,order_amounts,player_total_vegetable_q,player_total_cost,order_amounts*firm_vegetable4_price)
#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3#檢查點3


            order_record = characters_behavior.player.player_buy_firm_record(Eric_Chao, order_firm)
            order_record_set.append(order_record)

#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4
            print("行356")
            print(order_record, order_record_set)
#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4#檢查點4


        elif order_firm == "9":
            break
        else:
            print("請輸入採購對象選單的選項")
        print("買的肉量: ")
        print(player_total_meat_q)
        print("買的菜量: ")
        print(player_total_vegetable_q)

#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5
        print("行371")
        print(player_total_meat_q, player_total_vegetable_q)
#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5#檢查點5


    print("本回合採購的總肉量: ")
    print(player_total_meat_q)
    print("本回合採購的總菜量: ")
    print(player_total_vegetable_q)
    print("玩家採購總金額: ")
    print(player_total_cost)
    print("玩家採購後資金: ")
    Eric_Chao_total_money -= player_total_cost
    print(Eric_Chao_total_money)

#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6
    print("行387")
    print(player_total_meat_q, player_total_vegetable_q, player_total_cost, Eric_Chao_total_money)
#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6#檢查點6


    would_you_want_sell = input("本月是否要賣便當(Y \ N):")
    YesNo_yes = ("y", "Y")
    while would_you_want_sell in YesNo_yes:
        print("目前肉的存量: ")
        print(player_total_meat_q)
        print("目前菜的存量: ")
        print(player_total_vegetable_q)
        print("目前葷食便當的量:")
        print(meat_lunch_box_q)
        print("目前素食便當的量:")
        print(vegetable_lunch_box_q)


        decision = input("你要製作: 1. 素食便當 2. 葷食便當")
#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7
        print("行407")
        print(decision)
#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7

        make_lunch_box = characters_behavior.player.make_lunch_box_q_decision(Eric_Chao, decision)
#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7
        print("行413")
        print(make_lunch_box)
#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7#檢查點7



        if decision == "1":
            vegetable_lunch_box_q += make_lunch_box
            player_total_vegetable_q -= make_lunch_box*5
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
            print("行423")
            print(vegetable_lunch_box_q, make_lunch_box, player_total_vegetable_q, make_lunch_box*5)
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8


            if player_total_vegetable_q < 0:                                # 素食便當製作完後，菜量減到0以下(表示超過可製作的量)
                vegetable_lunch_box_q -= make_lunch_box
                player_total_vegetable_q += make_lunch_box*5
                print("超過可以製做素食便當的量!!!請重新輸入")
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
                print("行433")
                print(vegetable_lunch_box_q, make_lunch_box, player_total_vegetable_q, make_lunch_box*5)
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
                continue
        elif decision == "2":
            meat_lunch_box_q += make_lunch_box
            player_total_meat_q -= make_lunch_box*3
            player_total_vegetable_q -= make_lunch_box*3
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
            print("行442")
            print(meat_lunch_box_q, make_lunch_box, player_total_meat_q, make_lunch_box*3, player_total_vegetable_q)
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8

            if player_total_meat_q <0:                                     # 葷食便當製作完後，肉量減到0以下(表示超過可製作的量)
                meat_lunch_box_q -= make_lunch_box
                player_total_meat_q += make_lunch_box*3
                player_total_vegetable_q += make_lunch_box*3
                print("超過可以製做葷食便當的量!!!請重新輸入")
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
                print("行452")
                print(meat_lunch_box_q, make_lunch_box, player_total_meat_q, make_lunch_box*3, player_total_vegetable_q)
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8

                continue
            elif player_total_meat_q > 0:
                    if player_total_vegetable_q < 0:     # 葷食便當製作完後，肉量還超過0，但菜量減到0以下(表示超過可製作的量)
                        meat_lunch_box_q -= make_lunch_box
                        player_total_meat_q += make_lunch_box*3
                        player_total_vegetable_q += make_lunch_box*3
                        print("超過可以製做葷食便當的量!!!請重新輸入")
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
                        print("行464")
                        print(meat_lunch_box_q, make_lunch_box, player_total_meat_q, make_lunch_box*3, player_total_vegetable_q)
#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8#檢查點8
                        continue



        do_you_want_continue = input("是否繼續製作(Y \ N):")
        if do_you_want_continue in YesNo_yes:
            continue
        else:
            break
    #我定的便當價格(素、葷)
    print("可賣的葷食便當的量:")
    print(meat_lunch_box_q)
    print("可賣的素食便當的量:")
    print(vegetable_lunch_box_q)


    vegetable_lunch_box_price = characters_behavior.player.make_price_decision(Eric_Chao, "你的素食便當定價為: ")
    meat_lunch_box_price = characters_behavior.player.make_price_decision(Eric_Chao, "你的葷食便當定價為: ")
#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9
    print("行486")
    print(vegetable_lunch_box_price, meat_lunch_box_price)
#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9#檢查點9

    #電腦Com1    信譽比player和Com2好
    Com1 = characters_behavior.computer_AI()
    Com1_vegetable_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com1,consumer_vegetarian1_total_demand, consumer_vegetarian2_total_demand,consumer_vegetarian3_total_demand,Com1_total_brand_value)
    Com1_meat_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com1,consumer_1_total_demand, consumer_2_total_demand,consumer_3_total_demand,Com1_total_brand_value)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行495")
    print(Com1_vegetable_lunch_box_q, Com1_meat_lunch_box_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10

    Com1_buy_firm_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_vegetable_lunch_box_q, 30, 5)   #因為素食要5單位, 葷食要3單位
    Com1_buy_firm_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_vegetable_lunch_box_q, 50, 5)
    Com1_buy_firm_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_vegetable_lunch_box_q, 20, 5)
    Com1_buy_firm_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_vegetable_lunch_box_q, 0, 5)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行504")
    print(Com1_buy_firm_vegetable1_q,Com1_buy_firm_vegetable2_q,Com1_buy_firm_vegetable3_q,Com1_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10

    Com1_buy_firm_meat1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 20, 3)    #葷食要3單位肉
    Com1_buy_firm_meat2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 30, 3)
    Com1_buy_firm_meat3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 0, 3)
    Com1_buy_firm_meat4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 50, 3)
    Com1_buy_firm_meat_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 30, 3)   #因為葷食要3單位菜
    Com1_buy_firm_meat_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 50, 3)
    Com1_buy_firm_meat_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 20, 3)
    Com1_buy_firm_meat_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com1, Com1_meat_lunch_box_q, 0, 3)


#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行513")
    print(Com1_buy_firm_meat1_q,Com1_buy_firm_meat2_q,Com1_buy_firm_meat3_q,Com1_buy_firm_meat4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    firm_meat1_total_supply -= Com1_buy_firm_meat1_q
    firm_vegetable1_total_supply -= Com1_buy_firm_vegetable1_q
    firm_vegetable1_total_supply -=Com1_buy_firm_meat_vegetable1_q
    firm_meat2_total_supply -= Com1_buy_firm_meat2_q
    firm_vegetable2_total_supply -= Com1_buy_firm_vegetable2_q
    firm_vegetable2_total_supply -= Com1_buy_firm_meat_vegetable2_q
    firm_meat3_total_supply -= Com1_buy_firm_meat3_q
    firm_vegetable3_total_supply -= Com1_buy_firm_vegetable3_q
    firm_vegetable3_total_supply -=Com1_buy_firm_meat_vegetable3_q
    firm_meat4_total_supply -= Com1_buy_firm_meat4_q
    firm_vegetable4_total_supply -= Com1_buy_firm_vegetable4_q
    firm_vegetable4_total_supply -=Com1_buy_firm_meat_vegetable4_q
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行527")
    print(firm_meat1_total_supply,Com1_buy_firm_meat1_q, firm_vegetable1_total_supply,Com1_buy_firm_vegetable1_q,firm_meat2_total_supply,Com1_buy_firm_meat2_q, firm_vegetable2_total_supply,Com1_buy_firm_vegetable2_q,firm_meat3_total_supply,Com1_buy_firm_meat3_q,firm_vegetable3_total_supply,Com1_buy_firm_vegetable3_q, firm_meat4_total_supply,Com1_buy_firm_meat4_q,firm_vegetable4_total_supply,Com1_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10

    Com1_vegetable_cost = Com1_buy_firm_vegetable1_q*firm_vegetable1_price + Com1_buy_firm_vegetable2_q*firm_vegetable2_price + Com1_buy_firm_vegetable3_q*firm_vegetable3_price + Com1_buy_firm_vegetable4_q*firm_vegetable4_price
    Com1_meat_cost = Com1_buy_firm_meat1_q*firm_meat1_price + Com1_buy_firm_meat2_q*firm_meat2_price +Com1_buy_firm_meat3_q*firm_meat3_price +Com1_buy_firm_meat4_q*firm_meat4_price
    Com1_meat_vegetable_cost =Com1_buy_firm_meat_vegetable1_q*firm_vegetable1_price + Com1_buy_firm_meat_vegetable2_q*firm_vegetable2_price + Com1_buy_firm_meat_vegetable3_q*firm_vegetable3_price + Com1_buy_firm_meat_vegetable4_q*firm_vegetable4_price
    Com1_total_cost = Com1_meat_cost + Com1_vegetable_cost + Com1_meat_vegetable_cost
    Com1_total_money -= Com1_total_cost
    Com1_vegetable_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com1,Com1_vegetable_cost,4.4,Com1_vegetable_lunch_box_q)
    Com1_meat_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com1,Com1_meat_vegetable_cost+Com1_meat_cost,3.9,Com1_meat_lunch_box_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行538")
    print(Com1_vegetable_cost,
    Com1_meat_cost,
    Com1_total_cost,
    Com1_total_money,
    Com1_vegetable_price,
    Com1_meat_price)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    #Com1賣給各區塊的便當數量之分配
    Com1_distribute_vegetarian1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_vegetable_lunch_box_q/3, 0.4)
    Com1_distribute_vegetarian2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_vegetable_lunch_box_q/3, 0.2)
    Com1_distribute_vegetarian3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_vegetable_lunch_box_q/3, 0.4)
    Com1_distribute_meat1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_meat_lunch_box_q/3, 0.3)
    Com1_distribute_meat2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_meat_lunch_box_q/3, 0.6)
    Com1_distribute_meat3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com1,Com1_meat_lunch_box_q/3, 0.1)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行556")
    print(Com1_distribute_vegetarian1,
    Com1_distribute_vegetarian2 ,
    Com1_distribute_vegetarian3,
    Com1_distribute_meat1,
    Com1_distribute_meat2,
    Com1_distribute_meat3)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    #電腦Com2    信譽最差
    Com2 = characters_behavior.computer_AI()
    Com2_vegetable_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com2,consumer_vegetarian1_total_demand, consumer_vegetarian2_total_demand,consumer_vegetarian3_total_demand,Com2_total_brand_value)
    Com2_meat_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com2,consumer_1_total_demand, consumer_2_total_demand,consumer_3_total_demand,Com2_total_brand_value)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行571")
    print(Com2_vegetable_lunch_box_q,
    Com2_meat_lunch_box_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    Com2_buy_firm_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_vegetable_lunch_box_q, 0, 5)   #素食要5單位
    Com2_buy_firm_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_vegetable_lunch_box_q, 0, 5)
    Com2_buy_firm_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_vegetable_lunch_box_q, 20, 5)
    Com2_buy_firm_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_vegetable_lunch_box_q, 80, 5)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行580")
    print(Com2_buy_firm_vegetable1_q,
    Com2_buy_firm_vegetable2_q,
    Com2_buy_firm_vegetable3_q,
    Com2_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    Com2_buy_firm_meat1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 20, 3)    #葷食要3單位
    Com2_buy_firm_meat2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 0, 3)
    Com2_buy_firm_meat3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 80, 3)
    Com2_buy_firm_meat4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 0, 3)
    Com2_buy_firm_meat_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 0, 3)   # 葷食要3單位菜
    Com2_buy_firm_meat_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 0, 3)
    Com2_buy_firm_meat_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 20, 3)
    Com2_buy_firm_meat_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com2, Com2_meat_lunch_box_q, 80, 3)


#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行593")
    print(Com2_buy_firm_meat1_q,
    Com2_buy_firm_meat2_q,
    Com2_buy_firm_meat3_q,
    Com2_buy_firm_meat4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10




    firm_meat1_total_supply -= Com2_buy_firm_meat1_q
    firm_vegetable1_total_supply -= Com2_buy_firm_vegetable1_q
    firm_vegetable1_total_supply -= Com2_buy_firm_meat_vegetable1_q
    firm_meat2_total_supply -= Com2_buy_firm_meat2_q
    firm_vegetable2_total_supply -= Com2_buy_firm_vegetable2_q
    firm_vegetable2_total_supply -= Com2_buy_firm_meat_vegetable2_q
    firm_meat3_total_supply -= Com2_buy_firm_meat3_q
    firm_vegetable3_total_supply -= Com2_buy_firm_vegetable3_q
    firm_vegetable3_total_supply -= Com2_buy_firm_meat_vegetable3_q
    firm_meat4_total_supply -= Com2_buy_firm_meat4_q
    firm_vegetable4_total_supply -= Com2_buy_firm_vegetable4_q
    firm_vegetable4_total_supply -= Com2_buy_firm_meat_vegetable4_q

#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行612")
    print(firm_meat1_total_supply, Com2_buy_firm_meat1_q, firm_vegetable1_total_supply,Com2_buy_firm_vegetable1_q,firm_meat2_total_supply,Com2_buy_firm_meat2_q,firm_vegetable2_total_supply, Com2_buy_firm_vegetable2_q,firm_meat3_total_supply,Com2_buy_firm_meat3_q, firm_vegetable3_total_supply, Com2_buy_firm_vegetable3_q,
    firm_meat4_total_supply,Com2_buy_firm_meat4_q,
    firm_vegetable4_total_supply, Com2_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    Com2_vegetable_cost = Com2_buy_firm_vegetable1_q*firm_vegetable1_price + Com2_buy_firm_vegetable2_q*firm_vegetable2_price + Com2_buy_firm_vegetable3_q*firm_vegetable3_price + Com2_buy_firm_vegetable4_q*firm_vegetable4_price
    Com2_meat_vegetable_cost =Com2_buy_firm_meat_vegetable1_q*firm_vegetable1_price + Com2_buy_firm_meat_vegetable2_q*firm_vegetable2_price + Com2_buy_firm_meat_vegetable3_q*firm_vegetable3_price + Com2_buy_firm_meat_vegetable4_q*firm_vegetable4_price
    Com2_meat_cost = Com2_buy_firm_meat1_q*firm_meat1_price + Com2_buy_firm_meat2_q*firm_meat2_price +Com2_buy_firm_meat3_q*firm_meat3_price +Com2_buy_firm_meat4_q*firm_meat4_price
    Com2_total_cost = Com2_meat_cost + Com2_vegetable_cost + Com2_meat_vegetable_cost
    Com2_total_money -= Com2_total_cost
    Com2_vegetable_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com2,Com2_vegetable_cost,6.6,Com2_vegetable_lunch_box_q)
    Com2_meat_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com2,Com2_meat_vegetable_cost+Com2_meat_cost,5.7,Com2_meat_lunch_box_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行626")
    print(Com2_vegetable_cost,
    Com2_meat_cost,
    Com2_total_cost,
    Com2_total_money,
    Com2_vegetable_price,
    Com2_meat_price)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10



    #Com2賣給各區塊的便當數量之分配
    Com2_distribute_vegetarian1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_vegetable_lunch_box_q/3, 0.1)
    Com2_distribute_vegetarian2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_vegetable_lunch_box_q/3, 0.7)
    Com2_distribute_vegetarian3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_vegetable_lunch_box_q/3, 0.2)
    Com2_distribute_meat1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_meat_lunch_box_q/3, 0.3)
    Com2_distribute_meat2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_meat_lunch_box_q/3, 0.4)
    Com2_distribute_meat3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com2,Com2_meat_lunch_box_q/3, 0.3)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行645")
    print(Com2_distribute_vegetarian1,
    Com2_distribute_vegetarian2,
    Com2_distribute_vegetarian3 ,
    Com2_distribute_meat1,
    Com2_distribute_meat2,
    Com2_distribute_meat3)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    #電腦Com3   信譽最好
    Com3 = characters_behavior.computer_AI()
    Com3_vegetable_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com3,consumer_vegetarian1_total_demand, consumer_vegetarian2_total_demand,consumer_vegetarian3_total_demand,Com3_total_brand_value)
    Com3_meat_lunch_box_q = characters_behavior.computer_AI.AI_lunch_box_q_decision(Com3,consumer_1_total_demand, consumer_2_total_demand,consumer_3_total_demand,Com3_total_brand_value)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行660")
    print(Com3_vegetable_lunch_box_q,
    Com3_meat_lunch_box_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    Com3_buy_firm_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_vegetable_lunch_box_q, 60, 5)   #素食要5單位
    Com3_buy_firm_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_vegetable_lunch_box_q, 40, 5)
    Com3_buy_firm_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_vegetable_lunch_box_q, 0, 5)
    Com3_buy_firm_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_vegetable_lunch_box_q, 0, 5)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行671")
    print(Com3_buy_firm_vegetable1_q,
    Com3_buy_firm_vegetable2_q,
    Com3_buy_firm_vegetable3_q,
    Com3_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10


    Com3_buy_firm_meat1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 0, 3)    #葷食要3單位
    Com3_buy_firm_meat2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 60, 3)
    Com3_buy_firm_meat3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 0, 3)
    Com3_buy_firm_meat4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 40, 3)
    Com3_buy_firm_meat_vegetable1_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 60, 3)   #葷食要3單位菜
    Com3_buy_firm_meat_vegetable2_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 40, 3)
    Com3_buy_firm_meat_vegetable3_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 0, 3)
    Com3_buy_firm_meat_vegetable4_q = characters_behavior.computer_AI.AI_buy_food_amounts(Com3, Com3_meat_lunch_box_q, 0, 3)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行684")
    print(Com3_buy_firm_meat1_q,
    Com3_buy_firm_meat2_q,
    Com3_buy_firm_meat3_q,
    Com3_buy_firm_meat4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10



    firm_meat1_total_supply -= Com3_buy_firm_meat1_q
    firm_vegetable1_total_supply -= Com3_buy_firm_vegetable1_q
    firm_vegetable1_total_supply -= Com3_buy_firm_meat_vegetable1_q
    firm_meat2_total_supply -= Com3_buy_firm_meat2_q
    firm_vegetable2_total_supply -= Com3_buy_firm_vegetable2_q
    firm_vegetable2_total_supply -= Com3_buy_firm_meat_vegetable2_q
    firm_meat3_total_supply -= Com3_buy_firm_meat3_q
    firm_vegetable3_total_supply -= Com3_buy_firm_vegetable3_q
    firm_vegetable3_total_supply -= Com3_buy_firm_meat_vegetable3_q
    firm_meat4_total_supply -= Com3_buy_firm_meat4_q
    firm_vegetable4_total_supply -= Com3_buy_firm_vegetable4_q
    firm_vegetable4_total_supply -= Com3_buy_firm_meat_vegetable4_q


#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行702")
    print(firm_meat1_total_supply,Com3_buy_firm_meat1_q,
    firm_vegetable1_total_supply, Com3_buy_firm_vegetable1_q,
    firm_meat2_total_supply,Com3_buy_firm_meat2_q,
    firm_vegetable2_total_supply, Com3_buy_firm_vegetable2_q,
    firm_meat3_total_supply, Com3_buy_firm_meat3_q,
    firm_vegetable3_total_supply, Com3_buy_firm_vegetable3_q,
    firm_meat4_total_supply, Com3_buy_firm_meat4_q,
    firm_vegetable4_total_supply, Com3_buy_firm_vegetable4_q)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10

    Com3_vegetable_cost = Com3_buy_firm_vegetable1_q*firm_vegetable1_price + Com3_buy_firm_vegetable2_q*firm_vegetable2_price + Com3_buy_firm_vegetable3_q*firm_vegetable3_price + Com3_buy_firm_vegetable4_q*firm_vegetable4_price
    Com3_meat_vegetable_cost = Com3_buy_firm_meat_vegetable1_q*firm_vegetable1_price+Com3_buy_firm_meat_vegetable2_q*firm_vegetable2_price+Com3_buy_firm_meat_vegetable3_q*firm_vegetable3_price+Com3_buy_firm_meat_vegetable4_q*firm_vegetable4_price
    Com3_meat_cost = Com3_buy_firm_meat1_q*firm_meat1_price + Com3_buy_firm_meat2_q*firm_meat2_price +Com3_buy_firm_meat3_q*firm_meat3_price +Com3_buy_firm_meat4_q*firm_meat4_price
    Com3_total_cost = Com3_meat_cost + Com3_vegetable_cost + Com3_meat_vegetable_cost
    Com3_total_money -= Com3_total_cost
    Com3_vegetable_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com3,Com3_vegetable_cost,4.2,Com3_vegetable_lunch_box_q)
    Com3_meat_price = characters_behavior.computer_AI.AI_lunch_box_price_decision(Com3,Com3_meat_vegetable_cost+Com2_meat_cost,5.3,Com3_meat_lunch_box_q)

#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行720")
    print(Com3_vegetable_cost,
    Com3_meat_cost,
    Com3_total_cost,
    Com3_total_money,
    Com3_vegetable_price,
    Com3_meat_price)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10

    #Com3賣給各區塊的便當數量之分配
    Com3_distribute_vegetarian1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_vegetable_lunch_box_q/3, 0.2)
    Com3_distribute_vegetarian2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_vegetable_lunch_box_q/3, 0.5)
    Com3_distribute_vegetarian3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_vegetable_lunch_box_q/3, 0.3)
    Com3_distribute_meat1 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_meat_lunch_box_q/3, 0.5)
    Com3_distribute_meat2 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_meat_lunch_box_q/3, 0.4)
    Com3_distribute_meat3 = characters_behavior.computer_AI.AI_distribute_lunch_box_q(Com3,Com3_meat_lunch_box_q/3, 0.1)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    print("行737")
    print(Com3_distribute_vegetarian1,
    Com3_distribute_vegetarian2,
    Com3_distribute_vegetarian3 ,
    Com3_distribute_meat1,
    Com3_distribute_meat2,
    Com3_distribute_meat3)
#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10#檢查點10
    #===================================================================================================================
    #各消費者區塊對player,Com123的需求量
    vegetarian1_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian1_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    print("行783")
    print("檢查: vegetarian1_demand: ")
    print(vegetarian1_demand)



    Com1_vegetarian1_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian1_total_demand,Com1_vegetable_price,Com1_total_brand_value)
    Com2_vegetarian1_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian1_total_demand,Com2_vegetable_price,Com2_total_brand_value)
    Com3_vegetarian1_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian1_total_demand,Com3_vegetable_price,Com3_total_brand_value)
    vegetarian2_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian2_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    Com1_vegetarian2_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian2_total_demand,Com1_vegetable_price,Com1_total_brand_value)
    Com2_vegetarian2_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian2_total_demand,Com2_vegetable_price,Com2_total_brand_value)
    Com3_vegetarian2_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian2_total_demand,Com3_vegetable_price,Com3_total_brand_value)
    vegetarian3_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian3_total_demand,vegetable_lunch_box_price,Eric_Chao_brand_value)
    Com1_vegetarian3_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian3_total_demand,Com1_vegetable_price,Com1_total_brand_value)
    Com2_vegetarian3_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian3_total_demand,Com2_vegetable_price,Com2_total_brand_value)
    Com3_vegetarian3_demand = situtation_environment.preference_restaurant_demand(consumer_vegetarian3_total_demand,Com3_vegetable_price,Com3_total_brand_value)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11
    print("行760")
    print(vegetarian1_demand,
    Com1_vegetarian1_demand,
    Com2_vegetarian1_demand,
    Com3_vegetarian1_demand,
    vegetarian2_demand,
    Com1_vegetarian2_demand,
    Com2_vegetarian2_demand,
    Com3_vegetarian2_demand,
    vegetarian3_demand,
    Com1_vegetarian3_demand,
    Com2_vegetarian3_demand,
    Com3_vegetarian3_demand)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11


    meat1_demand = situtation_environment.preference_restaurant_demand(consumer_1_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    Com1_meat1_demand = situtation_environment.preference_restaurant_demand(consumer_1_total_demand,Com1_meat_price,Com1_total_brand_value)
    Com2_meat1_demand = situtation_environment.preference_restaurant_demand(consumer_1_total_demand,Com2_meat_price,Com2_total_brand_value)
    Com3_meat1_demand = situtation_environment.preference_restaurant_demand(consumer_1_total_demand,Com3_meat_price,Com3_total_brand_value)
    meat2_demand = situtation_environment.preference_restaurant_demand(consumer_2_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    Com1_meat2_demand = situtation_environment.preference_restaurant_demand(consumer_2_total_demand,Com1_meat_price,Com1_total_brand_value)
    Com2_meat2_demand = situtation_environment.preference_restaurant_demand(consumer_2_total_demand,Com2_meat_price,Com2_total_brand_value)
    Com3_meat2_demand = situtation_environment.preference_restaurant_demand(consumer_2_total_demand,Com3_meat_price,Com3_total_brand_value)
    meat3_demand = situtation_environment.preference_restaurant_demand(consumer_3_total_demand,meat_lunch_box_price,Eric_Chao_brand_value)
    Com1_meat3_demand = situtation_environment.preference_restaurant_demand(consumer_3_total_demand,Com1_meat_price,Com1_total_brand_value)
    Com2_meat3_demand = situtation_environment.preference_restaurant_demand(consumer_3_total_demand,Com2_meat_price,Com2_total_brand_value)
    Com3_meat3_demand = situtation_environment.preference_restaurant_demand(consumer_3_total_demand,Com3_meat_price,Com3_total_brand_value)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11
    print("行789")
    print(meat1_demand,
    Com1_meat1_demand,
    Com2_meat1_demand,
    Com3_meat1_demand,
    meat2_demand,
    Com1_meat2_demand,
    Com2_meat2_demand,
    Com3_meat2_demand,
    meat3_demand,
    Com1_meat3_demand,
    Com2_meat3_demand,
    Com3_meat3_demand)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11

    vlb_q = str(vegetable_lunch_box_q)
    mlb_q = str(meat_lunch_box_q)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11
    print("行807")
    print(vlb_q,mlb_q)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11

    print("目前可以賣的素食便當的量: "+ vlb_q)
    eric_input1 = situtation_environment.distribute_lunch_box_q("素食者1區塊")
    eric_input2 = situtation_environment.distribute_lunch_box_q("素食者2區塊")
    eric_input3 = situtation_environment.distribute_lunch_box_q("素食者3區塊")
    print("目前可以賣的葷食便當的量: "+ mlb_q)
    eric_input4 = situtation_environment.distribute_lunch_box_q("一般消費者1區塊")
    eric_input5 = situtation_environment.distribute_lunch_box_q("一般消費者2區塊")
    eric_input6 = situtation_environment.distribute_lunch_box_q("一般消費者3區塊")
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11
    print("行820")
    print(eric_input1,
    eric_input2,
    eric_input3,
    eric_input4,
    eric_input5,
    eric_input6)
#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11#檢查點11

    #===================================================================================================================
    #本回合小結
    vegetable1_earned = situtation_environment.segment_revenue_situated(eric_input1,vegetarian1_demand,vegetable_lunch_box_price )
    vegetable2_earned = situtation_environment.segment_revenue_situated(eric_input2,vegetarian2_demand,vegetable_lunch_box_price )
    vegetable3_earned = situtation_environment.segment_revenue_situated(eric_input3,vegetarian3_demand,vegetable_lunch_box_price )
    meat1_earned = situtation_environment.segment_revenue_situated(eric_input4,meat1_demand,meat_lunch_box_price )
    meat2_earned = situtation_environment.segment_revenue_situated(eric_input5,meat2_demand,meat_lunch_box_price )
    meat3_earned = situtation_environment.segment_revenue_situated(eric_input6,meat3_demand,meat_lunch_box_price )
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("行838")
    print(vegetable1_earned,
    vegetable2_earned,
    vegetable3_earned,
    meat1_earned,
    meat2_earned,
    meat3_earned)

    print(vegetarian1_demand,vegetable_lunch_box_price,vegetarian2_demand,vegetable_lunch_box_price,vegetarian3_demand,vegetable_lunch_box_price,meat1_demand,meat_lunch_box_price,meat2_demand,meat_lunch_box_price,meat3_demand,meat_lunch_box_price)



#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12


    player_revenue = vegetable1_earned + vegetable2_earned + vegetable3_earned + meat1_earned + meat2_earned + meat3_earned - player_total_cost  #player本回合總收益
    Eric_Chao_total_money += player_revenue    #player本回合的總資金
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("行851")
    print(player_revenue, Eric_Chao_total_money)
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("本回合player總收益: ")
    print(player_revenue)
    print("本回合player的總資金: ")
    print(Eric_Chao_total_money)
    print("本回合player的商譽: ")
    print(Eric_Chao_brand_value)


    Com1_vegetable1_earned = situtation_environment.segment_revenue_situated(Com1_distribute_vegetarian1,Com1_vegetarian1_demand,Com1_vegetable_price)
    Com1_vegetable2_earned = situtation_environment.segment_revenue_situated(Com1_distribute_vegetarian2,Com1_vegetarian2_demand,Com1_vegetable_price)
    Com1_vegetable3_earned = situtation_environment.segment_revenue_situated(Com1_distribute_vegetarian3,Com1_vegetarian3_demand,Com1_vegetable_price)
    Com1_meat1_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat1,Com1_meat1_demand,Com1_meat_price)
    Com1_meat2_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat2,Com1_meat2_demand,Com1_meat_price)
    Com1_meat3_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat3,Com1_meat3_demand,Com1_meat_price)
    Com1_revenue = Com1_vegetable1_earned + Com1_vegetable2_earned + Com1_vegetable3_earned + Com1_meat1_earned + Com1_meat2_earned +Com1_meat3_earned - Com1_total_cost  #Com1本回合總收益
    Com1_total_money += Com1_revenue    #Com1本回合的總資金
    Com1_vegetable_total_sale_q = situtation_environment.segment_q_situated((Com1_distribute_vegetarian1+Com1_distribute_vegetarian2+Com1_distribute_vegetarian3),(Com1_vegetarian1_demand+Com1_vegetarian2_demand+Com1_vegetarian3_demand))
    Com1_meat_total_sale_q = situtation_environment.segment_q_situated((Com1_distribute_meat1+Com1_distribute_meat2+Com1_distribute_meat3),(Com1_meat1_demand+Com1_meat2_demand+Com1_meat3_demand))
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("行873")
    print(Com1_vegetable1_earned,
    Com1_vegetable2_earned,
    Com1_vegetable3_earned,
    Com1_meat1_earned,
    Com1_meat2_earned,
    Com1_meat3_earned,
    Com1_revenue,
    Com1_total_money,
    Com1_revenue,
    Com1_vegetable_total_sale_q,
    Com1_meat_total_sale_q)
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12




    print("本回合Com1的素食便當銷售量: ")
    print(Com1_vegetable_total_sale_q)
    print("本回合Com1的素食便當定價: ")
    print(Com1_vegetable_price)
    print("本回合Com1的葷食便當銷售量: ")
    print(Com1_meat_total_sale_q)
    print("本回合Com1的葷食便當定價: ")
    print(Com1_meat_price)
    print("本回合Com1總收益: ")
    print(Com1_revenue)
    print("本回合Com1的總資金: ")
    print(Com1_total_money)
    print("本回合Com1的商譽: ")
    print(Com1_total_brand_value)

    Com2_vegetable1_earned = situtation_environment.segment_revenue_situated(Com2_distribute_vegetarian1,Com2_vegetarian1_demand,Com2_vegetable_price)
    Com2_vegetable2_earned = situtation_environment.segment_revenue_situated(Com2_distribute_vegetarian2,Com2_vegetarian2_demand,Com2_vegetable_price)
    Com2_vegetable3_earned = situtation_environment.segment_revenue_situated(Com2_distribute_vegetarian3,Com2_vegetarian3_demand,Com2_vegetable_price)
    Com2_meat1_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat1,Com1_meat1_demand,Com2_meat_price)
    Com2_meat2_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat2,Com1_meat2_demand,Com2_meat_price)
    Com2_meat3_earned = situtation_environment.segment_revenue_situated(Com1_distribute_meat3,Com1_meat3_demand,Com2_meat_price)
    Com2_revenue = Com2_vegetable1_earned + Com2_vegetable2_earned + Com2_vegetable3_earned + Com2_meat1_earned + Com2_meat2_earned +Com2_meat3_earned - Com2_total_cost  #Com2本回合總收益
    Com2_total_money += Com2_revenue    #Com2本回合的總資金
    Com2_vegetable_total_sale_q = situtation_environment.segment_q_situated((Com2_distribute_vegetarian1+Com2_distribute_vegetarian2+Com2_distribute_vegetarian3),(Com2_vegetarian1_demand+Com2_vegetarian2_demand+Com2_vegetarian3_demand))
    Com2_meat_total_sale_q = situtation_environment.segment_q_situated((Com2_distribute_meat1+Com2_distribute_meat2+Com2_distribute_meat3),(Com2_meat1_demand+Com2_meat2_demand+Com2_meat3_demand))
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("行916")
    print(Com2_vegetable1_earned,
    Com2_vegetable2_earned,
    Com2_vegetable3_earned,
    Com2_meat1_earned,
    Com2_meat2_earned,
    Com2_meat3_earned,
    Com2_revenue,
    Com2_total_money,
    Com2_revenue,
    Com2_vegetable_total_sale_q,
    Com2_meat_total_sale_q)
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12



    print("本回合Com2的素食便當銷售量: ")
    print(Com2_vegetable_total_sale_q)
    print("本回合Com2的素食便當定價: ")
    print(Com2_vegetable_price)
    print("本回合Com2的葷食便當銷售量: ")
    print(Com2_vegetable_total_sale_q)
    print("本回合Com2的葷食便當定價: ")
    print(Com2_meat_price)
    print("本回合Com2總收益: ")
    print(Com2_revenue)
    print("本回合Com2的總資金: ")
    print(Com2_total_money)
    print("本回合Com2的商譽: ")
    print(Com2_total_brand_value)

    Com3_vegetable1_earned = situtation_environment.segment_revenue_situated(Com3_distribute_vegetarian1,Com3_vegetarian1_demand,Com3_vegetable_price)
    Com3_vegetable2_earned = situtation_environment.segment_revenue_situated(Com3_distribute_vegetarian2,Com3_vegetarian2_demand,Com3_vegetable_price)
    Com3_vegetable3_earned = situtation_environment.segment_revenue_situated(Com3_distribute_vegetarian3,Com3_vegetarian3_demand,Com3_vegetable_price)
    Com3_meat1_earned = situtation_environment.segment_revenue_situated(Com3_distribute_meat1,Com3_meat1_demand,Com3_meat_price)
    Com3_meat2_earned = situtation_environment.segment_revenue_situated(Com3_distribute_meat2,Com3_meat2_demand,Com3_meat_price)
    Com3_meat3_earned = situtation_environment.segment_revenue_situated(Com3_distribute_meat3,Com3_meat3_demand,Com3_meat_price)
    Com3_revenue = Com3_vegetable1_earned + Com3_vegetable2_earned + Com3_vegetable3_earned + Com3_meat1_earned + Com3_meat2_earned +Com3_meat3_earned - Com3_total_cost  #Com3本回合總收益
    Com3_total_money += Com3_revenue    #Com3本回合的總資金
    Com3_vegetable_total_sale_q = situtation_environment.segment_q_situated((Com3_distribute_vegetarian1+Com3_distribute_vegetarian2+Com3_distribute_vegetarian3),(Com3_vegetarian1_demand+Com3_vegetarian2_demand+Com3_vegetarian3_demand))
    Com3_meat_total_sale_q = situtation_environment.segment_q_situated((Com3_distribute_meat1+Com3_distribute_meat2+Com3_distribute_meat3),(Com3_meat1_demand+Com3_meat2_demand+Com3_meat3_demand))
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12
    print("行958")
    print(Com3_vegetable1_earned,
    Com3_vegetable2_earned,
    Com3_vegetable3_earned,
    Com3_meat1_earned,
    Com3_meat2_earned,
    Com3_meat3_earned,
    Com3_revenue,
    Com3_total_money,
    Com3_revenue,
    Com3_vegetable_total_sale_q,
    Com3_meat_total_sale_q)
#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12#檢查點12


    print("本回合Com3的素食便當銷售量: ")
    print(Com3_vegetable_total_sale_q)
    print("本回合Com3的素食便當定價: ")
    print(Com3_vegetable_price)
    print("本回合Com3的葷食便當銷售量: ")
    print(Com3_meat_total_sale_q)
    print("本回合Com3的葷食便當定價: ")
    print(Com3_meat_price)
    print("本回合Com3總收益: ")
    print(Com3_revenue)
    print("本回合Com3的總資金: ")
    print(Com3_total_money)
    print("本回合Com3的商譽: ")
    print(Com3_total_brand_value)
    print("=================================================================================================")

"""
    vd1 = str(vegetarian1_demand)
    print("consumer_vegetarian1對我的需求量為: "+vd1)
    vd2 = str(vegetarian2_demand)
    print("consumer_vegetarian2對我的需求量為: "+vd2)
    vd3 = str(vegetarian3_demand)
    print("consumer_vegetarian3對我的需求量為: "+vd3)
    md1 = str(meat1_demand)
    print("consumer_1對我的需求量為: "+md1)
    md2 = str(meat2_demand)
    print("consumer_2對我的需求量為: "+md2)
    md3 = str(meat3_demand)
    print("consumer_3對我的需求量為: "+md3)












    #===================================================================================================================
    #廠商中標專區
    Compensation_parameters = random.randint(100,10000)
    which_firm_get = []
    firm_meat1_bad_news = situtation_environment.get_bad_news(what_event2,"1", firm_meat1_brand_value, 'e')
    if firm_meat1_bad_news != 'no':
        which_firm_get.append(firm_meat1_bad_news)
    firm_meat2_bad_news = situtation_environment.get_bad_news(what_event2,"2", firm_meat2_brand_value, 'e')
    if firm_meat2_bad_news != 'no':
        which_firm_get.append(firm_meat2_bad_news)
    firm_meat3_bad_news = situtation_environment.get_bad_news(what_event2,"3", firm_meat3_brand_value, 'e')
    if firm_meat3_bad_news != 'no':
        which_firm_get.append(firm_meat3_bad_news)
    firm_meat4_bad_news = situtation_environment.get_bad_news(what_event2,"4", firm_meat4_brand_value, 'e')
    if firm_meat4_bad_news != 'no':
        which_firm_get.append(firm_meat4_bad_news)
    firm_vegetable1_bad_news = situtation_environment.get_bad_news(what_event2,"5", firm_vegetable1_brand_value, 'd')
    if firm_vegetable1_bad_news != 'no':
        which_firm_get.append(firm_vegetable1_bad_news)
    firm_vegetable2_bad_news = situtation_environment.get_bad_news(what_event2,"6", firm_vegetable2_brand_value, 'd')
    if firm_vegetable2_bad_news != 'no':
        which_firm_get.append(firm_vegetable2_bad_news)
    firm_vegetable3_bad_news = situtation_environment.get_bad_news(what_event2,"7", firm_vegetable3_brand_value, 'd')
    if firm_vegetable3_bad_news != 'no':
        which_firm_get.append(firm_vegetable3_bad_news)
    firm_vegetable4_bad_news = situtation_environment.get_bad_news(what_event2,"8", firm_vegetable4_brand_value, 'd')
    if firm_vegetable4_bad_news != 'no':
        which_firm_get.append(firm_vegetable4_bad_news)
    #判斷player和Com123是否有中鏢及賠償和商譽減損
    player_get_bad_news = situtation_environment.are_you_got_it(order_record_set, which_firm_get)
    Com1_get_bad_news = situtation_environment.are_you_got_it(Com1_order_record_set, which_firm_get)
    Com2_get_bad_news = situtation_environment.are_you_got_it(Com2_order_record_set, which_firm_get)
    Com3_get_bad_news = situtation_environment.are_you_got_it(Com3_order_record_set, which_firm_get)
    if player_get_bad_news == 'get':
        Eric_Chao_total_money -= 100*Compensation_parameters
        Eric_Chao_brand_value -= 3000
    else:
        Eric_Chao_brand_value += 4000
    if Com1_get_bad_news == 'get':
        Com1_total_money -= 150*Compensation_parameters
        Com1_total_brand_value -= 2000
    else:
        Com1_total_brand_value += 4000
    if Com2_get_bad_news == 'get':
        Com2_total_money -= 80*Compensation_parameters
        Com2_total_brand_value -= 800
    else:
        Com2_total_brand_value += 4000
    if Com3_get_bad_news == 'get':
        Com3_total_money -= 200*Compensation_parameters
        Com3_total_brand_value -= 3000
    else:
        Com3_total_brand_value += 4000




"""